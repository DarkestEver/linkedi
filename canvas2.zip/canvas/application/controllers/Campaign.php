<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Campaign extends CI_Controller {
    public function __construct()
    {
       parent::__construct();
       $this->load->model('Log_model');
       
    }
	public function index()
	{
        $setting['title'] = "Create Campaign";
        if ($this->input->post()){
            $postData = $this->input->post();
            if (!isset($postData["emailname"]) || empty($postData["emailname"])) { $emailname = ""; } else { $emailname = $this->db->escape(strip_tags($postData["emailname"]));}
            if (!isset($postData["categoryName"]) || empty($postData["categoryName"])) { $categoryName = ""; } else { $categoryName = $this->db->escape(strip_tags($postData["categoryName"]));}
            if (!isset($postData["vertical"]) || empty($postData["vertical"])) { $vertical = ""; } else { $vertical = $this->db->escape(strip_tags($postData["vertical"]));}
            if (!isset($postData["wheel"]) || empty($postData["wheel"])) { $wheel = ""; } else { $wheel = $this->db->escape(strip_tags($postData["wheel"]));}

            $market = "";//$postData["countries"];
            $this->load->model('Campaign_model');
            $category_id = $this->Campaign_model->createCampaign($emailname,$categoryName,$vertical,$market,$wheel);
            if ($category_id != False) {
                $this->load->helper('url');
                redirect('edm/create/campaign/'.$category_id);
            }
            else
            {
                $setting['error_message'] = 'Campaign name already exists';
                $setting['error_type'] = 'warning';
            }

        }

        $setting['css'] = "";
        $setting['js'] = "createCampaign";

		$this->load->model('Campaign_model');
        $data['wheels'] = $this->Campaign_model->getAllWheels();
        $data['verticals'] = $this->Campaign_model->getAllVertical();
        $data['category'] = $this->Campaign_model->getAllCategory();
        $data['countries'] = $this->Campaign_model->getCountries();
        $this->load->view('header',$setting);
        $this->load->view('campaign/view_campaign', $data);
        $this->load->view('footer');

	}

    public function lists()
    {
        $setting['css'] = "";
        $setting['js'] = "view_campaign_list";
        $setting['title'] = "Campaign List";
        $this->load->model('Campaign_model');
        $data['wheels'] = $this->Campaign_model->getAllWheels();
        $data['verticals'] = $this->Campaign_model->getAllVertical();
        $data['category'] = $this->Campaign_model->getAllCategory();
        $data['countries'] = $this->Campaign_model->getCountries();
        $this->load->view('header',$setting);
        $this->load->view('campaign/view_campaign_lists', $data);
        $this->load->view('footer',$setting);

    }

    public function ajax_searchCamaign()
    {
        if ($this->input->post()){
            $postData = $this->input->post();
            $draw = $postData['draw'];
            $start = $postData['start'];
            $length = $postData['length'];

            if (!isset($postData["emailname"]) || empty($postData["emailname"])) { $emailname = ""; } else { $emailname = strip_tags($postData["emailname"]);}
            if (!isset($postData["categoryName"]) || empty($postData["categoryName"])) { $categoryName = ""; } else { $categoryName = $this->db->escape(strip_tags($postData["categoryName"]));}
            if (!isset($postData["vertical"]) || empty($postData["vertical"])) { $vertical = ""; } else { $vertical = $this->db->escape(strip_tags($postData["vertical"]));}
            if (!isset($postData["wheel"]) || empty($postData["wheel"])) { $wheel = ""; } else { $wheel = $this->db->escape(strip_tags($postData["wheel"]));}
            $this->load->model('Campaign_model');
            //echo $wheel . $vertical . $categoryName; die;
            $getCampaignCount = $this->Campaign_model->getCampaignCount();
            $result = $this->Campaign_model->searchCampaign($emailname,$categoryName,$vertical,$wheel,$start,$length );
            $response = array(
              "draw" => intval($draw),
              "iTotalRecords" => $getCampaignCount,
              "iTotalDisplayRecords" =>  $result['count'],
              "aaData" => $result['data']
            );
            echo json_encode($response);
        }
    }
}