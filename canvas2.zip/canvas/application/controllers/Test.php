<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends CI_Controller {
     public function __construct() {
        parent::__construct();
        $this->load->helper('url', 'form');
    }

	public function gindex()
	{

       if(!empty($_FILES['csv_file']['name']))
       {    
            $postData = $this->input->post();
            if (isset($postData["modal_country_code"])  && isset($postData["modal_edm_id"]) && isset($postData["modal_campaign_id"]) && isset($postData["modal_language_code"]) )
            {
                if (!empty($item["modal_country_code"])) {$modal_country_code = $this->db->escape(strip_tags($item["modal_country_code"]));}else{$modal_country_code = "NULL";};
                if (!empty($item["modal_edm_id"])) {$modal_edm_id = $this->db->escape(strip_tags($item["modal_edm_id"]));}else{$modal_edm_id = "NULL";};
                if (!empty($item["modal_campaign_id"])) {$modal_campaign_id = $this->db->escape(strip_tags($item["modal_campaign_id"]));}else{$modal_campaign_id ="NULL";};
                if (!empty($item["modal_language_code"])) {$modal_language_code = $this->db->escape(strip_tags($item["modal_language_code"]));}else{$modal_language_code = "NULL";};
                $this->do_csv_de_upload($modal_campaign_id,$modal_edm_id,$modal_country_code,$modal_language_code );
            }
            else
            {
                echo 'error';
            }
       }
       else
       {
            echo 'no csv file';
       }
       //echo "posted";
        $this->load->view('header');
        $this->load->view('test/view_test');
        $this->load->view('footer');
	}

	public function do_csv_de_upload($campaign_id,$edm_id,$country_code,$language_code) {
        $this->load->helper('status');
        $config['upload_path'] = "./resources/uploads/de_upload";
        $config['allowed_types'] = 'csv';
        $this->load->library('upload',$config);
        if($this->upload->do_upload('csv_file')) {
            $this->load->model('Edms_saved_inputs_model');
            $data = $this->upload->data();
            $file_path = $data['full_path'];
            $file = fopen($file_path, 'r');
            while (($line = fgetcsv($file)) !== FALSE) {
                 $key_value = $line[3];
                 $col_name = $line[2];
                 $key_id = $line[0];
                 $col_name = edm_input_col_name($col_name);
                 //echo $key_id . " " . $col_name. " ". $key_value . " </br>";
                 $error = $this->Edms_saved_inputs_model->file_upload_update($campaign_id,$edm_id,$country_code,$language_code, $key_id, $col_name, $key_value);
                 echo $error;
            }
            fclose($file);
            
        }
        else
        {
             echo $this->upload->display_errors();
             
        }
        
    }
}
