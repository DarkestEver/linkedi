%%[
SET @sending_de = "sending_de";
SET @translation_de = "automation_translation_de";
SET @config_de = "config_de";
SET @edm_id = '94';
SET @campaign_id = '1';
SET @country_code = "sg";
SET @language_code = "en";
]%%


<!-- https://raw.githubusercontent.com/TedGoas/Cerberus/master/cerberus-fluid.html -->
<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
    <meta charset="utf-8"> <!-- utf-8 works for most cases -->
    <meta name="viewport" content="width=device-width"> <!-- Forcing initial-scale shouldn't be necessary -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Use the latest (edge) version of IE rendering engine -->
    <meta name="x-apple-disable-message-reformatting">  <!-- Disable auto-scale in iOS 10 Mail entirely -->
    <meta name="format-detection" content="telephone=no,address=no,email=no,date=no,url=no"> <!-- Tell iOS not to automatically link certain text strings. -->
    <title>__subject__</title> <!-- The title tag shows in email notifications, like Android 4.4. -->

    <!-- Web Font / @font-face : BEGIN -->
    <!-- NOTE: If web fonts are not required, lines 10 - 27 can be safely removed. -->

    <!-- Desktop Outlook chokes on web font references and defaults to Times New Roman, so we force a safe fallback font. -->
    <!--[if mso]>
        <style>
            * {
                font-family: sans-serif !important;
            }
        </style>
    <![endif]-->

    <!-- All other clients get the webfont reference; some will render the font and others will silently fail to the fallbacks. More on that here: http://stylecampaign.com/blog/2015/02/webfont-support-in-email/ -->
    <!--[if !mso]><!-->
    <!-- insert web font reference, eg: <link href='https://fonts.googleapis.com/css?family=Roboto:400,700' rel='stylesheet' type='text/css'> -->
    <!--<![endif]-->

    <!-- Web Font / @font-face : END -->

    <!-- CSS Reset : BEGIN -->
    <style>

        /* What it does: Remove spaces around the email design added by some email clients. */
        /* Beware: It can remove the padding / margin and add a background color to the compose a reply window. */
        html,
        body {
            margin: 0 auto !important;
            padding: 0 !important;
            height: 100% !important;
            width: 100% !important;
        }

        /* What it does: Stops email clients resizing small text. */
        * {
            -ms-text-size-adjust: 100%;
            -webkit-text-size-adjust: 100%;
        }

        /* What it does: Centers email on Android 4.4 */
        div[style*="margin: 16px 0"] {
            margin: 0 !important;
        }

        /* What it does: forces Samsung Android mail clients to use the entire viewport */
        #MessageViewBody, #MessageWebViewDiv{
            width: 100% !important;
        }

        /* What it does: Stops Outlook from adding extra spacing to tables. */
        table,
        td {
            mso-table-lspace: 0pt !important;
            mso-table-rspace: 0pt !important;
        }

        /* What it does: Fixes webkit padding issue. */
        table {
            border-spacing: 0 !important;
            border-collapse: collapse !important;
            table-layout: fixed !important;
            margin: 0 auto !important;
        }

        /* What it does: Uses a better rendering method when resizing images in IE. */
        img {
            -ms-interpolation-mode:bicubic;
        }

        /* What it does: Prevents Windows 10 Mail from underlining links despite inline CSS. Styles for underlined links should be inline. */
        a {
            text-decoration: none;
        }

        /* What it does: A work-around for email clients meddling in triggered links. */
        a[x-apple-data-detectors],  /* iOS */
        .unstyle-auto-detected-links a,
        .aBn {
            border-bottom: 0 !important;
            cursor: default !important;
            color: inherit !important;
            text-decoration: none !important;
            font-size: inherit !important;
            font-family: inherit !important;
            font-weight: inherit !important;
            line-height: inherit !important;
        }

        /* What it does: Prevents Gmail from displaying a download button on large, non-linked images. */
        .a6S {
            display: none !important;
            opacity: 0.01 !important;
        }

        /* What it does: Prevents Gmail from changing the text color in conversation threads. */
        .im {
            color: inherit !important;
        }

        /* If the above doesn't work, add a .g-img class to any image in question. */
        img.g-img + div {
            display: none !important;
        }

        /* What it does: Removes right gutter in Gmail iOS app: https://github.com/TedGoas/Cerberus/issues/89  */
        /* Create one of these media queries for each additional viewport size you'd like to fix */

        /* iPhone 4, 4S, 5, 5S, 5C, and 5SE */
        @media only screen and (min-device-width: 320px) and (max-device-width: 374px) {
            u ~ div .email-container {
                min-width: 320px !important;
            }
        }
        /* iPhone 6, 6S, 7, 8, and X */
        @media only screen and (min-device-width: 375px) and (max-device-width: 413px) {
            u ~ div .email-container {
                min-width: 375px !important;
            }
        }
        /* iPhone 6+, 7+, and 8+ */
        @media only screen and (min-device-width: 414px) {
            u ~ div .email-container {
                min-width: 414px !important;
            }
        }

    </style>

    <!-- What it does: Makes background images in 72ppi Outlook render at correct size. -->
    <!--[if gte mso 9]>
    <xml>
        <o:OfficeDocumentSettings>
            <o:AllowPNG/>
            <o:PixelsPerInch>96</o:PixelsPerInch>
        </o:OfficeDocumentSettings>
    </xml>
    <![endif]-->

    <!-- CSS Reset : END -->

    <!-- Progressive Enhancements : BEGIN -->
    <style>

	    /* What it does: Hover styles for buttons */
	    .button-td,
	    .button-a {
	        transition: all 100ms ease-in;
	    }
	    .button-td-primary:hover,
	    .button-a-primary:hover {
	        background: #555555 !important;
	        border-color: #555555 !important;
	    }

	    /* Media Queries */
	    @media screen and (max-width: 600px) {

	        /* What it does: Adjust typography on small screens to improve readability */
	        .email-container p {
	            font-size: 17px !important;
	        }

	    }

    </style>
    <!-- Progressive Enhancements : END -->

</head><!--
	The email background color (#222222) is defined in three places:
	1. body tag: for most email clients
	2. center tag: for Gmail and Inbox mobile apps and web versions of Gmail, GSuite, Inbox, Yahoo, AOL, Libero, Comcast, freenet, Mail.ru, Orange.fr
	3. mso conditional: For Windows 10 Mail
-->
<body width="100%" style="margin: 0; padding: 0 !important; mso-line-height-rule: exactly; background-color: #222222;">
	<center style="width: 100%; background-color: #222222;">
    <!--[if mso | IE]>
    <table role="presentation" border="0" cellpadding="0" cellspacing="0" width="100%" style="background-color: #222222;">
    <tr>
    <td>
    <![endif]-->

        <!-- Visually Hidden Preheader Text : BEGIN -->
        <div style="display: none; font-size: 1px; line-height: 1px; max-height: 0px; max-width: 0px; opacity: 0; overflow: hidden; mso-hide: all; font-family: sans-serif;">__preheader__
        </div>
        <!-- Visually Hidden Preheader Text : END -->

        <!-- Create white space after the desired preview text so email clients don’t pull other distracting text into the inbox preview. Extend as necessary. -->
        <!-- Preview Text Spacing Hack : BEGIN -->
        <div style="display: none; font-size: 1px; line-height: 1px; max-height: 0px; max-width: 0px; opacity: 0; overflow: hidden; mso-hide: all; font-family: sans-serif;">
	        &zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;
        </div>
        <!-- Preview Text Spacing Hack : END -->

        <!--
            Set the email width. Defined in two places:
            1. max-width for all clients except Desktop Windows Outlook, allowing the email to squish on narrow but never go wider than 600px.
            2. MSO tags for Desktop Windows Outlook enforce a 600px width.
        -->
        <div style="max-width: 600px; margin: 0 auto;" class="email-container">
            <!--[if mso]>
            <table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="600">
            <tr>
            <td>
            <![endif]-->

	        <!-- Email Body : BEGIN --></pre>

/* -------------------start Herobanner  : module number - 1---------------------*/
%%[SET @module_visibility = "true";
SET @module_variation = "540" 
]%%

%%[if  @module_visibility == "true" then 
SET @Herobanner_468_image_title = LOOKUP(@translation_de, 'value', 'key_name','Herobanner_468_image_title','campaign_id', @campaign_id,'edm_id', @edm_id, 'variation_id',@module_variation, 'country_code',@country_code, 'language_code', @language_code)
SET @Herobanner_468_image_href = LOOKUP(@translation_de, 'value', 'key_name','Herobanner_468_image_href','campaign_id', @campaign_id,'edm_id', @edm_id, 'variation_id',@module_variation, 'country_code',@country_code, 'language_code', @language_code)
]%%
<table cellpadding="0" cellspacing="0" width="100%" style="min-width: 100%; " class="stylingblock-content-wrapper"><tbody><tr><td class="stylingblock-content-wrapper camarker-inner"><table align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" class="templateContainer" width="600">
	
		<tbody><tr>
			<td align="left" valign="top">
				<table border="0" cellpadding="0" cellspacing="0" class="templateColumn" width="100%">
					
						<tbody><tr>
							<td valign="top">
								<table border="0" cellpadding="0" cellspacing="0" width="100%">
									
										<tbody><tr>
											<td class="mcnCaptionBlockInner">
												<table align="center" border="0" cellpadding="0" cellspacing="0" id="Herobanner_468_image" data-editable= "image_withoutlink">
													
														<tbody><tr>
															<td align="center" valign="top">
																<a href="%%=v(Herobanner_468_image_link)=%%" target="_blank" title="%%=v(Herobanner_468_image_title)=%%"><img  class="resizeImage img-no-link" data-assetid="2049"  alt="%%=v(Herobanner_468_image_title)=%%" src="%%=v(Herobanner_468_image_href)=%%"  style="width: 600px;" width="600"></a></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table>

%%[ Endif ]%%
/* -------------------end Herobanner---------------------*/
 

/* -------------------start paragraph  : module number - 2---------------------*/
%%[SET @module_visibility = "true";
SET @module_variation = "541" 
]%%

%%[if  @module_visibility == "true" then 
SET @paragraph_469_paragraph_title = LOOKUP(@translation_de, 'value', 'key_name','paragraph_469_paragraph_title','campaign_id', @campaign_id,'edm_id', @edm_id, 'variation_id',@module_variation, 'country_code',@country_code, 'language_code', @language_code)
]%%
<table cellpadding="0" cellspacing="0" width="100%" style="min-width: 100%; " class="stylingblock-content-wrapper"><tbody><tr><td class="stylingblock-content-wrapper camarker-inner"> <!--1C TxtBx Padding Starts--><table align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" class="templateContainer" width="600">
	
		<tbody><tr>
			<td align="left" class="columnsContainer" valign="middle" width="100%">
				<table bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" class="templateColumn templateColumns" style="background:#ffffff;" width="100%">
					
						<tbody><tr>
							<td style="padding:0 24px ;" valign="middle">
								<table bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" width="100%" >
									
										<tbody><tr>
											<td align="left">
												<p data-editable = "paragraph" id="paragraph_469_paragraph" style="padding:0; margin:0; font-family: 'Open Sans', 'Helvetica Neue', 'Helvetica', 'Arial', 'sans-serif'; font-size: 14px; color: #666666; line-height: 20px;">%%=v(paragraph_469_paragraph_title)=%%</p></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table><!--1C TxtBx Padding Ends--> </td></tr></tbody></table>

%%[ Endif ]%%
/* -------------------end paragraph---------------------*/
 

/* -------------------start Herobanner  : module number - 3---------------------*/
%%[SET @module_visibility = "true";
SET @module_variation = "483" 
SET @module_visibility = "true";
if AttributeValue("") > "" then 
SET @module_variation = "490" Endif 
]%%

%%[if  @module_visibility == "true" then 
SET @Herobanner_407_image_title = LOOKUP(@translation_de, 'value', 'key_name','Herobanner_407_image_title','campaign_id', @campaign_id,'edm_id', @edm_id, 'variation_id',@module_variation, 'country_code',@country_code, 'language_code', @language_code)
SET @Herobanner_407_image_href = LOOKUP(@translation_de, 'value', 'key_name','Herobanner_407_image_href','campaign_id', @campaign_id,'edm_id', @edm_id, 'variation_id',@module_variation, 'country_code',@country_code, 'language_code', @language_code)
]%%
<table cellpadding="0" cellspacing="0" width="100%" style="min-width: 100%; " class="stylingblock-content-wrapper"><tbody><tr><td class="stylingblock-content-wrapper camarker-inner"><table align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" class="templateContainer" width="600">
	
		<tbody><tr>
			<td align="left" valign="top">
				<table border="0" cellpadding="0" cellspacing="0" class="templateColumn" width="100%">
					
						<tbody><tr>
							<td valign="top">
								<table border="0" cellpadding="0" cellspacing="0" width="100%">
									
										<tbody><tr>
											<td class="mcnCaptionBlockInner">
												<table align="center" border="0" cellpadding="0" cellspacing="0" id="Herobanner_407_image" data-editable= "image_withoutlink">
													
														<tbody><tr>
															<td align="center" valign="top">
																<a href="%%=v(Herobanner_407_image_link)=%%" target="_blank" title="%%=v(Herobanner_407_image_title)=%%"><img  class="resizeImage img-no-link" data-assetid="2049"  alt="%%=v(Herobanner_407_image_title)=%%" src="%%=v(Herobanner_407_image_href)=%%"  style="width: 600px;" width="600"></a></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table>

%%[ Endif ]%%
/* -------------------end Herobanner---------------------*/
 

/* -------------------start heading  : module number - 4---------------------*/
%%[SET @module_visibility = "true";
SET @module_variation = "482" 
]%%

%%[if  @module_visibility == "true" then 
SET @heading_406_heading_title = LOOKUP(@translation_de, 'value', 'key_name','heading_406_heading_title','campaign_id', @campaign_id,'edm_id', @edm_id, 'variation_id',@module_variation, 'country_code',@country_code, 'language_code', @language_code)
]%%
<table cellpadding="0" cellspacing="0" width="100%" style="min-width: 100%; " class="stylingblock-content-wrapper"><tbody><tr><td class="stylingblock-content-wrapper camarker-inner"><table align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" class="templateContainer" width="600">
 
  <tbody><tr>
   <td align="left" class="columnsContainer" valign="middle" width="100%">
    <table bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" class="templateColumn templateColumns" style="background:#ffffff;" width="100%">
     
      <tbody><tr>
       <td style="padding:24px;padding-bottom: 15px;" valign="middle">
        <table bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" width="100%" >
         
          <tbody><tr>
           <td align="left">
            <h1 data-editable = "paragraph" id="heading_406_heading" style="padding:0; margin:0; font-family: 'Open Sans', 'Helvetica Neue', 'Helvetica', 'Arial', 'sans-serif'; font-size: 22px; color: #00b14f; font-weight: bold; line-height: 26px;">%%=v(heading_406_heading_title)=%%</h1></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table>

%%[ Endif ]%%
/* -------------------end heading---------------------*/
 

/* -------------------start paragraph  : module number - 5---------------------*/
%%[SET @module_visibility = "true";
SET @module_variation = "484" 
]%%

%%[if  @module_visibility == "true" then 
SET @paragraph_408_paragraph_title = LOOKUP(@translation_de, 'value', 'key_name','paragraph_408_paragraph_title','campaign_id', @campaign_id,'edm_id', @edm_id, 'variation_id',@module_variation, 'country_code',@country_code, 'language_code', @language_code)
]%%
<table cellpadding="0" cellspacing="0" width="100%" style="min-width: 100%; " class="stylingblock-content-wrapper"><tbody><tr><td class="stylingblock-content-wrapper camarker-inner"> <!--1C TxtBx Padding Starts--><table align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" class="templateContainer" width="600">
	
		<tbody><tr>
			<td align="left" class="columnsContainer" valign="middle" width="100%">
				<table bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" class="templateColumn templateColumns" style="background:#ffffff;" width="100%">
					
						<tbody><tr>
							<td style="padding:0 24px ;" valign="middle">
								<table bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" width="100%" >
									
										<tbody><tr>
											<td align="left">
												<p data-editable = "paragraph" id="paragraph_408_paragraph" style="padding:0; margin:0; font-family: 'Open Sans', 'Helvetica Neue', 'Helvetica', 'Arial', 'sans-serif'; font-size: 14px; color: #666666; line-height: 20px;">%%=v(paragraph_408_paragraph_title)=%%</p></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table><!--1C TxtBx Padding Ends--> </td></tr></tbody></table>

%%[ Endif ]%%
/* -------------------end paragraph---------------------*/
 

/* -------------------start cta  : module number - 6---------------------*/
%%[SET @module_visibility = "true";
SET @module_variation = "485" 
]%%

%%[if  @module_visibility == "true" then 
SET @cta_409_cta_title = LOOKUP(@translation_de, 'value', 'key_name','cta_409_cta_title','campaign_id', @campaign_id,'edm_id', @edm_id, 'variation_id',@module_variation, 'country_code',@country_code, 'language_code', @language_code)
SET @cta_409_cta_alias = LOOKUP(@translation_de, 'value', 'key_name','cta_409_cta_alias','campaign_id', @campaign_id,'edm_id', @edm_id, 'variation_id',@module_variation, 'country_code',@country_code, 'language_code', @language_code)
SET @cta_409_cta_href = LOOKUP(@translation_de, 'value', 'key_name','cta_409_cta_href','campaign_id', @campaign_id,'edm_id', @edm_id, 'variation_id',@module_variation, 'country_code',@country_code, 'language_code', @language_code)
]%%
			<table align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" class="templateContainer" width="600" id>
					<tbody><tr>
						<td align="left" class="columnsContainer" valign="middle" width="100%">
							<table bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" class="templateColumn templateColumns" style="background:#ffffff;" width="100%" data-editable = "cta" id="cta_409_cta">
								<tbody><tr>
									<td align="center" class="mob_pb0" valign="middle">
										<table align="center" border="0" cellpadding="0" cellspacing="0">
											<tbody><tr>
												<td align="center" style="padding:15px;padding-top:0px;padding-bottom:15px" valign="top">
													<table align="center" border="0" cellpadding="0" cellspacing="0" width="auto">
														<tbody><tr>
															<td align="center" bgcolor="#00b14f" style="font-family: 'Open Sans', 'Helvetica Neue', 'Helvetica', 'Arial', 'sans-serif'; font-size:13px; font-weight: bold; color:#ffffff; text-decoration:none; line-height:18px;">
																<a alias="%%=v(cta_409_cta_alias)=%%" title="%%=v(cta_409_cta_title)=%%" href="%%=v(cta_409_cta_href)=%%" class="mob-btn-fnt" style="font-family: 'Open Sans', 'Helvetica Neue', 'Helvetica', 'Arial', 'sans-serif'; font-size:14px; font-weight: bold; color:#ffffff; text-decoration:none; padding:10px 15px; border:2px solid #00b14f; display:inline-block;" >%%=v(cta_409_cta_title)=%%</a></td>
														</tr>
													</tbody></table>
												</td>
											</tr>
										</tbody></table>
									</td>
								</tr>
							</tbody></table>
						</td>
					</tr>
				</tbody></table>

%%[ Endif ]%%
/* -------------------end cta---------------------*/
 

/* -------------------start heading  : module number - 7---------------------*/
%%[SET @module_visibility = "true";
SET @module_variation = "489" 
]%%

%%[if  @module_visibility == "true" then 
SET @heading_413_heading_title = LOOKUP(@translation_de, 'value', 'key_name','heading_413_heading_title','campaign_id', @campaign_id,'edm_id', @edm_id, 'variation_id',@module_variation, 'country_code',@country_code, 'language_code', @language_code)
]%%
<table cellpadding="0" cellspacing="0" width="100%" style="min-width: 100%; " class="stylingblock-content-wrapper"><tbody><tr><td class="stylingblock-content-wrapper camarker-inner"><table align="center" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" class="templateContainer" width="600">
 
  <tbody><tr>
   <td align="left" class="columnsContainer" valign="middle" width="100%">
    <table bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" class="templateColumn templateColumns" style="background:#ffffff;" width="100%">
     
      <tbody><tr>
       <td style="padding:24px;padding-bottom: 15px;" valign="middle">
        <table bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" width="100%" >
         
          <tbody><tr>
           <td align="left">
            <h1 data-editable = "paragraph" id="heading_413_heading" style="padding:0; margin:0; font-family: 'Open Sans', 'Helvetica Neue', 'Helvetica', 'Arial', 'sans-serif'; font-size: 22px; color: #00b14f; font-weight: bold; line-height: 26px;">%%=v(heading_413_heading_title)=%%</h1></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table></td></tr></tbody></table>

%%[ Endif ]%%
/* -------------------end heading---------------------*/
 


            <!--[if mso]>
            </td>
            </tr>
            </table>
            <![endif]-->
        </div>


    <!--[if mso | IE]>
    </td>
    </tr>
    </table>
    <![endif]-->
    </center>
</body>
</html>