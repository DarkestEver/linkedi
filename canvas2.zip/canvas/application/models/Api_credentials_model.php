<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api_credentials_model extends CI_Model {

        public function __construct()
        {
                parent::__construct();
                // Your own constructor code
        }

        public function getAllAPIs()
        {
            $sql = "SELECT * FROM api_credentials ;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function getAllAPIByName($api_name)
        {
            $sql = "SELECT * FROM api_credentials where api_name = ". $api_name .";";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }


        public function getAllAPIsById($api_id)
        {
            $sql = "SELECT * FROM api_credentials where id = ". $api_id .";";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }
        public function updateApi($postData=null, $action=null) {
            if ($action == "save") {
               // var_dump($postData); die;
                $error = 0;
                if (!isset($postData["api_name"]) || empty($postData["api_name"])) { $api_name = ""; } else { $api_name = $this->db->escape(strip_tags($postData["api_name"]));}
                if (!isset($postData["client_id"]) || empty($postData["client_id"])) { $client_id = ""; } else { $client_id = $this->db->escape(strip_tags($postData["client_id"]));}
                if (!isset($postData["client_secret"]) || empty($postData["client_secret"])) { $client_secret = ""; } else { $client_secret = $this->db->escape(strip_tags($postData["client_secret"]));}
                if (!isset($postData["auth_url"]) || empty($postData["auth_url"])) { $auth_url = ""; } else { $auth_url = $this->db->escape(strip_tags($postData["auth_url"]));}
                if (!isset($postData["rest_url"]) || empty($postData["rest_url"])) { $rest_url = ""; } else { $rest_url = $this->db->escape(strip_tags($postData["rest_url"]));}

                 $sql = "SELECT * FROM api_credentials WHERE api_name = ".$api_name; 
                        $query = $this->db->query($sql);
                        if ($query->num_rows() > 0) {
                            return False;
                        }
                        else {
                                $sql2 = "INSERT INTO api_credentials (api_name,client_id,client_secret,auth_url,rest_url) VALUES ($api_name,$client_id,$client_secret,$auth_url,$rest_url)";
                                $this->db->query($sql2);
                                return TRUE;   
                        }
            }
            if ($action == "edit") {
                 $error = 0;
                if (!isset($postData["api_name"]) || empty($postData["api_name"])) { $api_name = ""; } else { $api_name = $this->db->escape(strip_tags($postData["api_name"]));}
                if (!isset($postData["client_id"]) || empty($postData["client_id"])) { $client_id = ""; } else { $client_id = $this->db->escape(strip_tags($postData["client_id"]));}
                if (!isset($postData["client_secret"]) || empty($postData["client_secret"])) { $client_secret = ""; } else { $client_secret = $this->db->escape(strip_tags($postData["client_secret"]));}
                if (!isset($postData["auth_url"]) || empty($postData["auth_url"])) { $auth_url = ""; } else { $auth_url = $this->db->escape(strip_tags($postData["auth_url"]));}
                if (!isset($postData["rest_url"]) || empty($postData["rest_url"])) { $rest_url = ""; } else { $rest_url = $this->db->escape(strip_tags($postData["rest_url"]));}

                 $sql = "SELECT * FROM api_credentials WHERE api_name = ".$api_name; 
                        $query = $this->db->query($sql);
                        if ($query->num_rows() > 0) {
                            $sql2 = "update api_credentials set client_id = $client_id,client_secret = $client_secret,auth_url = $auth_url ,rest_url = $rest_url where api_name =".$api_name." ;";
                            $this->db->query($sql2);
                            return TRUE;   
                        }
                        else
                        {
                            return False;
                        }
                        
            }
            if ($action == "delete") {
                $error = 0;
                if (!isset($postData["api_name"]) || empty($postData["api_name"])) { $api_name = ""; } else { $api_name = $this->db->escape(strip_tags($postData["api_name"]));}

                $sql = "delete FROM api_credentials WHERE api_name = ".$api_name;
                $query = $this->db->query($sql);
                return true;
            }


        }

}