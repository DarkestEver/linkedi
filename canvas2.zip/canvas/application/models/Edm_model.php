<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Edm_model extends CI_Model {

        public function __construct()
        {
                parent::__construct();
                // Your own constructor code
        }

        public function createEDM($campaign_id="", $emailname="",$market=""){
            $sql2 = "INSERT INTO edms (`campaign_id`,`email_name`) VALUES (".$campaign_id.",".$emailname . ");";
            $this->db->query($sql2);
            $edm_id =  $this->db->insert_id();
            foreach ($market as $key => $value) {
                $sql = "insert into edm_countries (edm_id, country_id) values ('".$edm_id."','".$value."');";
                $this->db->query($sql);
            }
            return $edm_id;
        }
/*
        public function createEDM($emailname="",$categoryName="",$vertical="",$market="",$wheel=""){
            $sql2 = "INSERT INTO edms (`email_name`,`category_name`,`vertical_name`,`market_name`,`wheels`) VALUES (".$emailname . "," . $categoryName . "," . $vertical . ",''," . $wheel.");";
            $this->db->query($sql2);
            $edm_id =  $this->db->insert_id();
            foreach ($market as $key => $value) {
                $sql = "insert into edm_countries (edm_id, country_id) values ('".$edm_id."','".$value."');";
                $this->db->query($sql);
            }
            return $edm_id;
        }
  */      
        public function createEDMCopy($emailname,$categoryName,$vertical,$market,$wheel, $id)
        {
            $edm_id = $this->createEDM($emailname,$categoryName,$vertical,$market,$wheel);
            $sql = "SELECT * FROM templates  where edm_id = ". $id;
            $query = $this->db->query($sql);
            if ($query->num_rows() > 0) {
                $template =  $query->result_array();
                foreach ($template as $key => $tvalue) {
                    $sql2 = 'INSERT INTO templates (`edm_id` ,`module_key` ,`module_position` ,`createdby` ) VALUES ('.$edm_id. ',"' . $tvalue['module_key'] . '","' . $tvalue['module_position'] . '", NULL);';
                    $this->db->query($sql2);
                    $new_t_id =  $this->db->insert_id();
                    $old_t_id = $tvalue['id'];

                    $sql_t_variation = "select * from  template_variations where t_id = ". $old_t_id;
                    $sql_t_variation_query = $this->db->query($sql_t_variation);
                    $template_variation =  $sql_t_variation_query->result_array();
                    foreach ($template_variation as $key => $tv_value) {
                        $sql_insert_variation = 'INSERT INTO Template_variations (`name` ,`show_or_hide` ,`variable_name` ,`conditions`, `t_id`, `hide_show_value` ) VALUES ( "'.$tv_value['name'].'", "'.$tv_value['show_or_hide'].'" ,"'.$tv_value['variable_name'].'","'.$tv_value['conditions'].'",' . $new_t_id. ',"'.$tv_value['hide_show_value'].'");';
                        $q_query = $this->db->query($sql_insert_variation);//->result_array();
                        $new_v_id  = $this->db->insert_id();
                        $old_v_id = $tv_value['id'];
                        foreach ($market as $key => $country_id) {
                            $sql_esi =  "select * from edms_saved_inputs esi inner join countries c  on c.country_code =esi.country_code and esi.language_code = c.language_code where template_id = ". $old_t_id ." and variation_id =  ".$old_v_id." and c.id = '".$country_id."';"; 
                                $sql_esi_query = $this->db->query($sql_esi);
                                if ($sql_esi_query->num_rows() > 0) {
                                    $sql_esi_query_data = $sql_esi_query->result_array();
                                    
                                   //    iiiiiiiiiiii
                                    //var_dump($sql_esi_query_data[0]);
                                    $sql_insert_esi ="INSERT INTO edms_saved_inputs(edm_id ,module_position, module_id, element_id ,key_name , title ,alias, href ,editable_type,country_code ,language_code, link ,template_id,variation_id  ) select ".$edm_id." ,esi.module_position,esi.module_id, esi.element_id ,CONCAT('".$new_t_id."' ,'_',right(esi.key_name
                                    , LENGTH(esi.key_name) - LOCATE('_', esi.key_name)) ) , esi.title ,esi.alias, esi.href ,esi.editable_type,esi.country_code ,esi.language_code, esi.link ,'".$new_t_id."','".$new_v_id."' from edms_saved_inputs esi where template_id = ". $old_t_id ." and variation_id =  ".$old_v_id." and country_code = '".$v_country_code."' and language_code = '".$v_language_code."';";
                                    $this->db->query($sql_insert_esi);
                                }
                        }

                    }
                }
            }
            return $edm_id;
        }

        public function getEDMDByID($campaign_id, $emd_id)
        {
            $sql = "SELECT campaigns.campaign_name,campaigns.category_name, campaigns.vertical_name,campaigns.market_name, campaigns.wheels  , email_name, campaigns.id as campaign_id, edms.id as id  FROM edms inner join campaigns on edms.campaign_id = campaigns.id where edms.id = ". $emd_id ." and edms.campaign_id = ".$campaign_id ;
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function getAllEDMD()
        {
            $sql = "SELECT * FROM edms order by createddate desc";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }
        
        public function updateStatus($edm_id, $status)
        {
            $sql = "update edms set status = " . $status . " where id = " . $edm_id. ";";
                    $query = $this->db->query($sql);
                    return true;
                    /*if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }*/
        }

        public function getEDMDByIDStatus($value,$campaign_id)
        {
            $sql = "SELECT status FROM edms  where id = ". $value . " and campaign_id = " .$campaign_id ;
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        $query =  $query->result_array();
                        return $query[0]['status'];
                    } else {
                        return array();
                    }
        }
        
        public function getEDMDCount()
        {
            $sql = "SELECT count(1) as count FROM edms  ";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        $query =  $query->result_array();
                        return $query[0]['count'];
                    } else {
                        return array();
                    }
        }

        public function searchEDM($campaign_id="")
        {
            $sql = "SELECT e.*, c.country_code,c.language_code, ec.localized_input_stutus FROM `edms` e inner JOIN edm_countries ec on ec.edm_id = e.id inner JOIN countries c on c.id = ec.country_id where e.campaign_id = ".$campaign_id." order by createddate desc "; 
            $query = $this->db->query($sql);
            $result_array = [];
            if ($query->num_rows() > 0) {
                $query =  $query->result_array();
                return $query;
            } else {
                return array();
            }
        }
}