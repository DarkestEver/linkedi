<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Edms_saved_inputs_model extends CI_Model {

        public function __construct()
        {
                parent::__construct();
                // Your own constructor code
        }

        public function getSavedInputValues($campaign_id,$edm_id )
        {
            $sql = "SELECT esi.*, m.module_key FROM edms_saved_inputs   esi inner join  modules m on m.id = esi.module_id where esi.edm_id = " . $edm_id . " and esi.campaign_id = ".$campaign_id.";";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function getSavedInputValuesByEdmID($value)
        {
            $sql = "SELECT * FROM edms_saved_inputs where edm_id = '" . $value . "';";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function getSavedInputValuesCountByEdmID($value)
        {
            $sql = "SELECT count(1) as count FROM edms_saved_inputs where edm_id = '" . $value . "';";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }
        public function de_export($value)
        {
            $sql = "SELECT key_name,country_code,language_code,variation_id,title,alias,href,start_ampscript,end_ampscript,link FROM edms_saved_inputs where edm_id = '" . $value . "';";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function export_input($campaign_id,$edm_id,$country,$language)
        {
            $sql = "SELECT esi.id,m.module_name,m.module_name,esi.key_name,esi.country_code,esi.language_code,esi.variation_id,esi.title,esi.alias,esi.href,esi.start_ampscript,esi.end_ampscript,esi.link FROM edms_saved_inputs esi inner join  modules m on m.id = esi.module_id  where  country_code = '".$country."'and language_code = '".$language."'  and edm_id = '".$edm_id."' and campaign_id =".$campaign_id." ;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }
        public function getSavedInputValuesByTemplateID($value)
        {
            $sql = "SELECT * FROM edms_saved_inputs where template_id = '" . $value . "';";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function getSavedInputValuesByKey($value, $country_code,$language_code, $edm_id,$campaign_id)
        {
            $sql = "SELECT esi.* FROM edms_saved_inputs esi  where  esi.country_code = '".$country_code."' and esi.language_code = '".$language_code."' and esi.key_name = '" . $value . "' and esi.edm_id = '".$edm_id."' and esi.campaign_id =".$campaign_id." ;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

       public function getSavedInputValuesByVariation($variation_id,$key_name, $country_code,$language_code, $edm_id,$campaign_id)
        {
            $sql = "SELECT esi.* FROM edms_saved_inputs esi  where  esi.country_code = '".$country_code."' and esi.language_code = '".$language_code."' and esi.key_name = '" . $key_name . "' and esi.variation_id = '" . $variation_id . "' and esi.edm_id = '".$edm_id."' and esi.campaign_id =".$campaign_id." ;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }
        
        public function setSavedInputValuesByKey($start_ampscript ,$imagesrc,$title, $link , $alias ,$end_ampscript,$country_code,$language_code,$section_key,$variation_id,$edm_id, $campaign_id )
        {
            $sql2 = "update edms_saved_inputs set `href` =".$imagesrc." , `title` = ". $title . " , `alias` =".$alias. " , `link` = ". $link . " , `start_ampscript` = ". $start_ampscript . ", `end_ampscript` = ". $end_ampscript. "   where variation_id = ". $variation_id ." and key_name = ". $section_key ." and `country_code` = ".$country_code." and `language_code` = ".$language_code." and edm_id = ".$edm_id." and campaign_id = ".$campaign_id.";";
            $this->db->query($sql2);
            return true;
        
        }
        

        public function getByVaration_id($id,$country_code,$language_code,$edm_id)
        {
            $sql = "SELECT * FROM edms_saved_inputs where variation_id ='".$id."' and country_code = '".$country_code."' and language_code = '".$language_code. "' and edm_id = '".$edm_id."';";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function get_id($country_code,$language_code,$section_key,$variation_id, $edm_id, $campaign_id)
        {
            $sql2 = "SELECT * from edms_saved_inputs   where variation_id = ". $variation_id ." and key_name = ". $section_key ." and `country_code` = ".$country_code." and `language_code` = ".$language_code." and edm_id = ".$edm_id." and campaign_id = ".$campaign_id.";";
            $query =$this->db->query($sql2);
            if ($query->num_rows() > 0) {
                        return $query->result_array()[0]['id'];
                    } else {
                        return array();
                    }
        }

        public function file_upload_update($campaign_id,$edm_id,$country_code,$language_code, $id, $col, $value)
        {
            $sql2 = "SELECT * from edms_saved_inputs   where  id = ". $id ." and `country_code` = ".$country_code." and `language_code` = ".$language_code." and edm_id = ".$edm_id." and campaign_id = ".$campaign_id.";";
            $query =$this->db->query($sql2);
            if ($query->num_rows() > 0) {
                        $sql_update  = "update edms_saved_inputs set ".$col." = ". $value ." where id = ". $id." ;";
                        $this->db->query($sql_update);
                    } else {
                        return "no record found";
                    }
        }

}