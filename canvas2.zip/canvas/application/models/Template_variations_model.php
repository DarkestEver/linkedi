<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class template_variations_model extends CI_Model {

        public function __construct()
        {
                parent::__construct();
                // Your own constructor code
        }

        public function getById($id='')
        {
            $sql = "SELECT * FROM template_variations where id =".$id." ;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function getByTemplate_id($campaign_id,$edm_id,$id='')
        {
            $sql = "SELECT * FROM template_variations where t_id =".$id." and campaign_id = ".$campaign_id." and edm_id = ".$edm_id.";";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }
     

        
        
        public function save($name ,$show_or_hide   ,$variable_name ,$conditions   , $t_id,$t_hide_show_value,$edm_id,$campaign_id){
            $sql2 = 'INSERT INTO template_variations (`campaign_id`,`edm_id`, `name` ,`show_or_hide` ,`variable_name` ,`conditions`, `t_id`, `hide_show_value` ) VALUES ('.$campaign_id.','.$edm_id.','.$name . ',' . $show_or_hide . ',' . $variable_name . ',' . $conditions . ',' . $t_id. ',' . $t_hide_show_value . ');';
            $this->db->query($sql2);
            $variable_id =  $this->db->insert_id();
            $sql2 = "INSERT INTO edms_saved_inputs(campaign_id, edm_id ,module_position, module_id, element_id ,key_name , title ,alias, href ,editable_type,country_code ,language_code, link ,template_id,variation_id  ) select t.campaign_id, t.edm_id, t.module_position,m.id as module_id,eme.id,CONCAT(t.id ,'_',eme.elements ) as key_name, eme.title, eme.alias,eme.href,eme.editable_type,c.country_code,c.language_code, eme.link, t.id, ". $variable_id ." from templates t   inner join modules m on t.module_key = m.module_key inner join edms_module_elements eme on eme.module_id = m.id  inner join edm_countries ec on ec.edm_id = t.edm_id inner join countries c on ec.country_id = c.id where t.edm_id = ". $edm_id . " and t.id = " . $t_id . " and t.campaign_id = " . $campaign_id;
            $this->db->query($sql2);
            return $variable_id ;
        }

        public function deleteById($t_id='')
        {
            $sql = "DELETE FROM template_variations where t_id =".$t_id." ;";
                    $query = $this->db->query($sql);
                    return 1;
        }

        public function deleteifnotone($id='',$t_id='')
        {
           $sql = "select 1 from template_variations where t_id = ". $t_id;
           $query = $this->db->query($sql); 
           if ($query->num_rows() > 1) {
               $sql = "DELETE from template_variations where id = ". $id." ;";
               $this->db->query($sql);
               $sql = "DELETE from edms_saved_inputs where variation_id = ". $id." ;";
               $this->db->query($sql);
               return 1;
           }
           else
           {
            return 0;
           }

        }
        
}