<?php
defined('BASEPATH') OR exit('No direct script access allowed'); 
?><!-- DataTales Example -->
<div class="card shadow mb-4">
      <div class="card-body">
        <div>
            <div class="row">
                <form class="user">
                    <div class="form-group row">
                        <div class="col-sm-3" >
                            <input type="text" class="form-control" name="emailname" id="emailname" placeholder="Campaign Name">
                        </div>
                        <div class="col-sm-2" >
                            <select class="form-control" id="categoryName"  name="categoryName" placeholder="categoryName">
                               <option value=""></option>
                                <?php foreach ($category as $key => $value) {
                                    echo '<option value="'.$value['category_name'].'">'.$value['category_name'].'</option>';
                                } ?>
                            </select>
                        </div>
                        <div class="col-sm-2">
                            <select class="form-control" id="vertical" name="vertical" placeholder="vertical">
                             <option value=""></option>
                                <?php foreach ($verticals as $key => $value) {
                                    echo '<option value="'.$value['vertical_name'].'">'.$value['vertical_name'].'</option>';
                                } ?>
                            </select>
                        </div>
                        <div class="col-sm-2">
                            <select class="form-control" id="wheel" name="wheel" placeholder="wheel">
                               <option value=""></option>
                                <?php foreach ($wheels as $key => $value) {
                                    echo '<option value="'.$value['wheel_name'].'">'.$value['wheel_name'].'</option>';
                                } ?>
                            </select>
                        </div>
                        <div class="col-sm-2">
                            <a href="#" id="search" class="btn btn-primary">Search</a>
                        </div>
                </form>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Campaign Name</th>
                        <th>Category</th>
                        <th>Vertical</th>
                        <th>Wheels</th>
                        <th>Date Created</th>
                        <th>Status</th>
                        <th>Create EDM</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
</div>
