<?php
defined('BASEPATH') OR exit('No direct script access allowed'); 
?><form method="POST" action="#">
    <!-- Page Heading -->

    
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            
            <?php if (!isset($edm_action)   ) { ?>
            <div class="card-header py-3">
                 <h6 class="m-0 font-weight-bold text-primary">Create new EDM</h6>
            </div>
            <div class="card-body">
                <div >
                   
                    <input type="hidden" name="action" value="<?php  if (isset($action)) echo $action; ?>">
                    <input type="hidden" name="campaign_id" value="<?php  echo $campaign_id; ?>">
                    <div class="form-group row">
                        <div class="col-sm-3" >
                            <label for="male"  style="padding:.375rem .75rem" >Email Name</label>
                        </div>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="emailname" id="emailname" placeholder="Email Name">
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-3" >
                            <label for="male"  style="padding:.375rem .75rem" >Market Name</label>
                        </div>
                        <div class="col-sm-6">
                            <?php foreach ($countries as $key => $country) { ?>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" name="countries[]" id="<?php echo $country['id']; ?>" value="<?php echo $country['id']; ?>">
                                <label class="form-check-label" for="inlineCheckbox1"><?php echo $country['country_code']."_".$country['language_code']; ?></label>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-9">
                            <input type="submit" class="btn btn-primary" id="submit">
                        </div>
                    </div>
                </div>
            </div>
             <?php } elseif (isset($edm_action) && $edm_action="add") { ?>
                <div class="card-header py-3">
                 <h6 class="m-0 font-weight-bold text-primary">Add New Language</h6>
                </div>
               <div class="card-body">
                <div >
                    
                    <input type="hidden" name="action" value="<?php  if (isset($action)) echo $action; ?>">
                    <input type="hidden" name="edm_action" value="<?php  if (isset($edm_action)) echo $edm_action; ?>">
                    <input type="hidden" name="campaign_id" value="<?php  echo $campaign_id; ?>">
                    <input type="hidden" name="emailname" value="<?php echo $edm_name[0]['id']; ?>">
                    <div class="form-group row">
                        <div class="col-sm-3" >
                            <label for="male"  style="padding:.375rem .75rem" >Email Name</label>
                        </div>
                        <div class="col-sm-6">
                            <label><?php echo $edm_name[0]['email_name']; ?></label>
                           </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-3" >
                            <label for="male"  style="padding:.375rem .75rem" >Market Name</label>
                        </div>
                        <div class="col-sm-6">
                            <?php foreach ($countries as $key => $country) { ?>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" name="countries[]" id="<?php echo $country['id']; ?>" value="<?php echo $country['id']; ?>">
                                <label class="form-check-label" for="inlineCheckbox1"><?php echo $country['country_code']."_".$country['language_code']; ?></label>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-9">
                            <input type="submit" class="btn btn-primary" id="submit">
                        </div>
                    </div>
                </div>
            </div>
             <?php } ?>
        </div>
    </div>
   

</form>
<div class="row">
    <div class="col-lg-12">
        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">EDM List</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Country</th>
                                <th>EDM Name</th>
                                <th>Language</th>
                                <th>Status</th>
                                <th>Create Date</th>
                                <th>Input Link</th>
                                <th>Preview</th>
                                <th>Ampscript</th>
                                <th>API</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($edm_details as $key => $value) {?>
                            <tr>
                                <td>
                                    <?php  echo $value['email_name']  ?> : 
                                    <a target="_blank" href="<?php echo base_url(); ?>edm/getDraggableModules/<?php echo $campaign_id ; ?>/<?php  echo $value['id'] ; ?>">
                                          <?php  echo edm_status($value['status']) ; ?>
                                    </a> 
                                    <a href="<?php echo base_url(); ?>edm/create/campaign/<?php echo $campaign_id.'/add/'.$value['id'] ; ?>">
                                        <svg class="bi bi-plus" width="2em" height="2em" viewBox="0 0 20 20" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" d="M10 5.5a.5.5 0 01.5.5v4a.5.5 0 01-.5.5H6a.5.5 0 010-1h3.5V6a.5.5 0 01.5-.5z" clip-rule="evenodd"></path>
                                    <path fill-rule="evenodd" d="M9.5 10a.5.5 0 01.5-.5h4a.5.5 0 010 1h-3.5V14a.5.5 0 01-1 0v-4z" clip-rule="evenodd"></path>
                                    </svg> Add Language </a>
                                </td>
                                <td><?php  echo $value['country_code']  ?></td>
                                <td><?php  echo  $value['language_code']  ?></td>
                                <td> <?php  echo  edm_input_status($value['localized_input_stutus'])  ?> </td>
                                <td><?php  echo  $value['createddate']  ?></td>
                                <td>
                                    <?php if ($value['status'] != 0) { ?>
                                    <a target="_blank" href="<?php echo base_url(); ?>edm/localizedInputBriefInput/<?php echo $campaign_id ; ?>/<?php  echo $value['id']."/".$value['country_code']."/".$value['language_code'] ; ?>">Link</a>
                                    <?php } ?>
                                </td>
                                <td><a target="_blank" href="<?php echo base_url(); ?>edm/preview/<?php echo $campaign_id ; ?>/<?php  echo $value['id']."/".$value['country_code']."/".$value['language_code'] ; ?>">Preview</a></td>
                                <td><a target="_blank" href="<?php echo base_url().'edm/get_ampscript2/'.$campaign_id.'/'.$value['id']; ?>">Code</a></td>
                                 <td><a target="_blank" href="<?php echo base_url()?>edm/apicalls/">API</a></td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
