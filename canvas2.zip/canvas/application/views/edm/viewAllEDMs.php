<?php
defined('BASEPATH') OR exit('No direct script access allowed'); 
?>
 <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">EDM List</h1>
  <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Input brief localized version link</h6>
            </div>
            <div class="card-body">
              <div >
                <div class="row">
                  <form class="user">
                    <div class="form-group row">
                      <div class="col-sm-3" >
                        <input type="text" class="form-control" name="emailname" id="emailname" placeholder="Email Name">
                      </div>
                      <div class="col-sm-2" >
                            <select class="form-control" id="categoryName"  name="categoryName" placeholder="categoryName">
                          <option value="PAX">PAX</option>
                            <option value="DAX">DAX</option>
                            <option value="MEX">MEX</option>
                            <option value="Global">Global</option>
                          </select>
                        </div>
                        <div class="col-sm-2">
                          <select class="form-control" id="vertical" name="vertical" placeholder="vertical">
                          <option value="PAX">PAX</option>
                            <option value="DAX">DAX</option>
                            <option value="MEX">MEX</option>
                            <option value="Global">Global</option>
                          </select>
                        </div>
                        <div class="col-sm-2">
                          <select class="form-control" id="wheel" name="wheel" placeholder="wheel">
                          <option value="2W">2W</option>
                            <option value="3W">3W</option>
                            <option value="4W">4W</option>
                          </select>
                        </div>
                        <div class="col-sm-2">
                            <a href="#"  id="search" class="btn btn-primary"> Search</a>
                        </div>
                    </form>
                </div>
              </div>
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>EDM Name</th>
                      <th>Category</th>
                      <th>Vertical</th>
                      <th>Wheels</th>
                      <th>Date Created</th>
                      <th>Status</th>
                      <th>Input</th>
                      <th>Ampscript</th>
                      <th>DE</th>
                      <th>DE Upload</th>
                    </tr>
                  </thead>

                  <tbody>

                  </tbody>
                </table>
              </div>
            </div>
          </div>
