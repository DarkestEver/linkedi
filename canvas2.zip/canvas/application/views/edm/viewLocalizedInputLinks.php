<?php
defined('BASEPATH') OR exit('No direct script access allowed'); 
?><!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800"><?php echo $edm_details[0]['email_name']; ?></h1>
<p class="mb-4">
	Campaign : <?php echo $edm_details[0]['campaign_name']; ?>
	Category : <?php echo $edm_details[0]['category_name']; ?>
	Vetical : <?php echo $edm_details[0]['vertical_name']; ?>
	Market : <?php echo $edm_details[0]['market_name']; ?>
	Wheels : <?php echo $edm_details[0]['wheels']; ?>
</p>
<!-- DataTales Example -->
<div class="card shadow mb-4">
	<div class="card-header py-3">
		<h6 class="m-0 font-weight-bold text-primary">Input brief localized version link</h6>
	</div>
	<div class="card-body">
		<div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead>
					<tr>
						<th>Country</th>
						<th>Country Code</th>
						<th>Language Code</th>
						<th>Link</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($countries as $v) { ?>
					<tr>
						<td><?php echo $v['country_name'] ; ?></td>
						<td><?php echo $v['country_code'] ; ?></td>
						<td><?php echo $v['language_code'] ; ?></td>
						<td><a href="<?php echo site_url().'edm/localizedInputBriefInput/'.$edm_details[0]['campaign_id'].'/'.$edm_details[0]['id'].'/'.$v['country_code'] .'/'.$v['language_code']  ;?>">link </a></td>
					</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
