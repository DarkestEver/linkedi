  <?php
defined('BASEPATH') OR exit('No direct script access allowed'); 
$edm_id = $edm_details[0]['id'] ;
        $campaign_id = $edm_details[0]['campaign_id'] ?>

<div class="row">
    <!-- Draggable container -->
    <div class="col-lg-7">
        
        <div class="card shadow mb-9" style="min-height:400px;width:650px; padding-bottom: 10px ">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Email builder</h6>

            </div>
            <center>
            <table id="editable_modules" cellpadding="0" cellspacing ="0" style="background-color: #ffffff; filter: alpha(opacity=40); opacity: 0.95;border:1px #dedede solid;">
                <tr><td><img src="<?php echo site_url()."resources/img/grab_header.png";?>"></td></tr>
                <?php echo $html_str; ?>
                <tr><td><img src="<?php echo site_url()."resources/img/grab_footer.png";?>"></td></tr>
            </table>
            <center>
        </div>
        
    </div>
    <!-- Draggable component -->
    <div class="col-lg-4" >
        <div class="card shadow" style="position: fixed;width:400px" width="400px">
            <div class="card-header d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Custom Blocks</h6>
                <p id="section_lebel" class="m-0" style="display: none"></p>
                <div class="spinner-border text-primary ajax_loader" role="status">
                  <span class="sr-only">Loading...</span>
                </div>
                <div class="dropdown no-arrow">
                    <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                    </a>

                    <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink" x-placement="bottom-end" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(17px, 19px, 0px);">
                      <div class="dropdown-header">Options</div>
                      <a target="_blank" class="dropdown-item" href="<?php echo site_url().'edm/preview/'.$campaign_id."/".$edm_id."/".$country_code."/".$language_code ?>">Preview</a>
                      <a class="dropdown-item" href="<?php echo site_url().'edm/export_input_file/'.$campaign_id."/".$edm_id."/".$country_code."/".$language_code ?>"><span class="glyphicon glyphicon-cloud-download" aria-hidden="true"></span>Download Input Sheet</a>
                       <a class="dropdown-item" data-toggle="modal" data-target="#Modal_upload_csv" ><span class="glyphicon glyphicon-cloud-upload" aria-hidden="true"></span>Upload Input Sheet</a>
                       <a class="dropdown-item" href="<?php echo site_url().'edm/preview_download/'.$campaign_id."/".$edm_id."/".$country_code."/".$language_code ?>"><span class="glyphicon glyphicon-download-alt" aria-hidden="true"></span> Download HTML</a>
                       <a class="dropdown-item" href="<?php echo site_url().'edm/get_ampscript2/'.$campaign_id."/".$edm_id."/".$country_code."/".$language_code ?>"><span class="glyphicon glyphicon-download-alt" aria-hidden="true"></span> Download Ampscript</a>
                       <a class="dropdown-item" href="<?php echo site_url().'edm/export_translation_de/'.$campaign_id."/".$edm_id."/".$country_code."/".$language_code ?>"><span class="glyphicon glyphicon-download-alt" aria-hidden="true"></span> Download Translation DE</a>
                    </div>
                  </div>
            </div>
            <div class="card-body">
               
                <form  id="form"  class="user" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="section_key" id="section_key"/>
                    <input type="hidden" name="section_module_type" id="section_module_type"/>
                    <input type="hidden" name="hidden_country" id="hidden_country" value="<?php echo $country_code; ?>" >
                    <input type="hidden" name="hidden_language" id="hidden_language" value="<?php echo $language_code ?>" >
                    <input type="hidden" id="hidden_emd_id" name="hidden_emd_id" value="<?php echo $edm_id; ?>" >
                    <input type="hidden" id="hidden_campaign_id" name="hidden_campaign_id" value="<?php echo $campaign_id; ?>" >
                    <input type="hidden" name="variation_id" id="variation_id" >
                    <div class="row">
                        <div class="col-lg-12">
                            <div id="subject_line" name="subject_line"  >subject_line</div>
                            <div id="preheader" name="preheader"  >preheader</div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12" >
                            
                            <div class="form-group" id="editable_section">
                                <div class="row" id="variation_container"></div>
                                <div class="input-group mb-1">
                                 <input type="text" class="form-control char_count_input"  id="editable_section_start_ampscript" name="editable_section_start_ampscript" placeholder="Start Ampscript">
                                  <div class="input-group-append">
                                    <label class="btn btn-primary char_count" type="button">OK</label>
                                  </div>
                                </div>

                                <div class="input-group mb-1">
                                 <input type="text" class="form-control char_count_input" id="editable_section_title" name="editable_section_title" placeholder="Title">
                                  <div class="input-group-append">
                                    <label class="btn btn-primary char_count" type="button">OK</label>
                                  </div>
                                </div>

                                <div class="input-group mb-1">
                                <input type="text" class="form-control" id="editable_section_redirect_link" name="editable_section_redirect_link" placeholder="Rediect Link">
                                  <div class="input-group-append">
                                    <label class="btn btn-primary char_count" type="button">OK</label>
                                  </div>
                                </div>

                                 <div class="input-group mb-1">
                                <input type="text" class="form-control char_count_input" id="editable_section_alias" name="editable_section_alias" placeholder="alias">
                                  <div class="input-group-append">
                                    <label class="btn btn-primary char_count" type="button">OK</label>
                                  </div>
                                </div>

                                 <div class="input-group mb-1">
                                <input type="text" class="form-control char_count_input" id="editable_section_end_ampscript" name="editable_section_end_ampscript" placeholder="end Ampscript">
                                  <div class="input-group-append">
                                    <label class="btn btn-primary char_count" type="button">OK</label>
                                  </div>
                                </div>

                                <div class="input-group mb-1" id="editable_section_imagesrc_div">
                                    <input type="text" class="form-control" id="editable_section_imagesrc" name="editable_section_imagesrc" placeholder="Image Source">
                                    <label class="col-sm-12"> OR </label>
                                    <input type="file" name="file" id="file" accept=".gif,.jpg,.jpeg,.png,.svg">
                                </div>

                                <div class="col-sm-12">
                                    <center>
                                    <a class="btn btn-success btn-icon-split" id="ajax_save_element" >
                                        <span class="text" style="color:ffffff">Save</span>
                                    </a>
                                    <a class="btn btn-success btn-icon-split" id="close_highlighted" >
                                        <span class="text" style="color:ffffff">close</span>
                                    </a>
                                    </center>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

  <div class="modal" id="Modal_upload_csv" name="Modal_upload_csv">
    <div class="modal-dialog">
      <div class="modal-content">
       <form id="input_sheet_upload" method="post"   enctype="multipart/form-data">
         
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Import CSV</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
                <input type="hidden" name="modal_country_code" value="<?php echo $country_code; ?>"/>
                <input type="hidden" name="modal_edm_id" value="<?php echo $edm_id; ?>" />
                <input type="hidden" name="modal_campaign_id" value="<?php echo $campaign_id; ?>" />
                <input type="hidden" name="modal_language_code" value="<?php echo $language_code ?>"/>
                <input type="file" id="csv_file" name="csv_file" size="33" />
        </div>
        <!-- Modal footer -->
        <div class="modal-footer">
           <input type="submit" class="btn btn-danger" value="Upload" id="file_upload"/>
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        </form>
      </div>
    </div>
  </div>

<style type="text/css">
    
    .highlight_selected {
    font-weight: bold;
    -webkit-box-shadow: 0 0 0 99999px rgba(0, 0, 0, .8);
    box-shadow: 0 0 0 99999px rgba(0, 0, 0, .8);
  position: relative;
  z-index: 9999;
 
  transition: all 0.5s ease;
}
</style>