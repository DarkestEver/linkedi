<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
?>
					</div>
					<!-- /.container-fluid -->
				</div>
				<!-- End of Main Content -->
				<!-- Footer -->
				<footer class="sticky-footer bg-white">
					<div class="container my-auto">
						<div class="copyright text-center my-auto">
							<span>Copyright &copy; Your Website 2019</span>
						</div>
					</div>
				</footer>
				<!-- End of Footer -->
			</div>
		<!-- End of Content Wrapper -->
		</div>
		<!-- End of Page Wrapper -->
		<!-- Scroll to Top Button-->
		<a class="scroll-to-top rounded" href="#page-top">
			<i class="fas fa-angle-up"></i>
		</a>
		<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
		<!-- Bootstrap core JavaScript-->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
		<script src="<?=base_url()?>resources/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

		<!-- Core plugin JavaScript-->
		<script src="<?=base_url()?>resources/vendor/jquery-easing/jquery.easing.min.js"></script>
		<!-- Page level plugins -->
		<script src="<?=base_url()?>resources/vendor/datatables/jquery.dataTables.min.js"></script>
		<script src="<?=base_url()?>resources/vendor/datatables/dataTables.bootstrap4.min.js"></script>
		<!-- Custom scripts for all pages-->
		<script src="<?=base_url()?>resources/js/sb-admin-2.min.js"></script>
		
		<style type="text/css">
			.topbar{    height: 3rem;}
			.breadcrumb {
			    display: flex;
			    flex-wrap: wrap;
			    padding: 7px 0px 7px 17px ;
			    margin: -13px 24px 7px 24px;
			    list-style: none;
			    background-color: #eaecf4;
			    border-radius: .35rem;
			}
		</style>
		<script type="text/javascript">
			function alert_message(message,type) {
			 $('#error_message').append('<div class="alert alert-'+type+' alert-dismissible fade show"><strong>' + message + '<button type="button" class="close" data-dismiss="alert">&times;</button></div>'); 
			}

			$(document).ready(function() {
				$(".ajax_loader").hide();
			});
			$(document).ajaxStart(function() {
		        // show loader on start
		        $(".ajax_loader").css("display","block");
		    }).ajaxSuccess(function() {
		        // hide loader on success
		        $(".ajax_loader").css("display","none");
		    });
		</script>

		<?php
		if (isset($js) && !(empty($js)))
		{
			include 'resources/custom/js/'.$js.'.js.php';
		//echo '<script src="'.base_url().'resources/custom/js/'.$js.'.js"></script>';
		}
		?>
	</body>
</html>