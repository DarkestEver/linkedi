<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (!empty($result))
{
  $result = $result[0];
  $post_type = 'edit';
}
else
{
  $post_type = 'save';
}
?>
        <form method="POST" action="<?php echo base_url().'settings/apis' ?>"  >
            <input type="hidden" name="action" value="<?php echo $post_type;?>"> 
            <div class="form-group row">
              <label for="example-text-input" class="col-2 col-form-label">API Name</label>
              <div class="col-10">
                <input class="form-control" type="text" value="<?php echo (!empty($result))?$result['api_name'] :''   ;?>" placeholder="" name="api_name" <?php echo (!empty($result))?'readonly="readonly"':''   ;?> >
              </div>
            </div>
            <div class="form-group row">
              <label for="example-text-input" class="col-2 col-form-label">Cliet ID</label>
              <div class="col-10">
                <input class="form-control" type="text" value="<?php echo (!empty($result))?$result['client_id'] :''   ;?>" placeholder="" name="client_id">
              </div>
            </div>
            <div class="form-group row">
              <label for="example-text-input" class="col-2 col-form-label">Client Secret</label>
              <div class="col-10">
                <input class="form-control" type="text" value="<?php echo (!empty($result))?$result['client_secret'] :''   ;?>" placeholder="" name="client_secret">
              </div>
            </div>
            <div class="form-group row">
              <label for="example-text-input" class="col-2 col-form-label">Auth URL</label>
              <div class="col-10">
                <input class="form-control" type="text" value="<?php echo (!empty($result))?$result['auth_url'] :''   ;?>" placeholder="" name="auth_url">
              </div>
            </div>
            <div class="form-group row">
              <label for="example-text-input" class="col-2 col-form-label">Rest URL</label>
              <div class="col-10">
                <input class="form-control" type="text" value="<?php echo (!empty($result))?$result['rest_url'] :''   ;?>" placeholder="" name="rest_url">
              </div>
            </div>
            
            <div class="form-group row"> 
              <div class="col-10">
                <input type="submit" value="<?php echo ucfirst($post_type);?>" class="btn btn-primary">
                <?php if($post_type =="edit") {
                  echo '<input type="submit" name="action" value="delete" class="btn btn-primary">';
                } ?>
              </div>
            </div> 
            

        </form>
