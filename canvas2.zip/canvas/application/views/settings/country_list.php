<?php
defined('BASEPATH') OR exit('No direct script access allowed'); 
?>
<!-- Example Tables Card -->
            <div class="card mb-3">
                <div class="card-header">
                    <i class="fa fa-table"></i> API List <a href="<?=base_url()?>settings/countries/add"><button class="btn btn-primary">+</button></a>
                </div>
                <div class="card-block">
                    <div class="table-responsive">
                        <table class="table table-bordered" width="100%" id="dataTable" cellspacing="0">
                            <thead>
                                <tr>
                                    
                                    <th>Name</th> 
                                    <th>Client Id</th> 
                                    <th>Client Secret</th> 
                                    <th></th>
                                </tr>
                            </thead>
                            
                            <tbody>
                            <?php foreach ($groups as $v) { ?>
                                <tr>
                                    <td><?=$v["country_name"]?></td>
                                    <td><?=$v["country_code"]?></td>
                                    <td><?=$v["language_code"]?></td>

                                    <td><form method="POST" action="" style="display:inline;"><input type="hidden" name="id" value="<?=$v["id"]?>"></form> <a href="<?=base_url()?>settings/countries/edit/<?=$v["id"]?>"><button class="btn btn-primary">Edit</button></a> </td>
                                </tr>
                            <?php } ?> 
                            </tbody>
                        </table>
                    </div>
                </div> 
            </div>