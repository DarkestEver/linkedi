<style>

   
        #menu {
           # overflow: auto;
            position:fixed;
            z-index:2;
        }

        .parent-menu {
            background-color: #0c8fff;
            min-width:200px;
            float:left;
        }

        #menu ul
        {
            list-style-type:none;
        }

        #menu ul li a
        {
            padding:10px 15px;
            display:block;
            color:#fff;
            text-decoration:none;
        }

            #menu ul li a:hover
            {
                background-color:#007ee9;
            }

            #menu ul li:hover > ul {
                left: 200px;
                -webkit-transition: left 200ms ease-in;
                -moz-transition: left 200ms ease-in;
                -ms-transition: left 200ms ease-in;
                transition: left 200ms ease-in;
            }

            #menu ul li > ul {
                position: absolute;
                background-color: #333;
                top: 0;
                left: -2000px;
                min-width: 200px;
                z-index: -1;
                height: 450px;
                -webkit-transition: left 200ms ease-in;
                -moz-transition: left 200ms ease-in;
                -ms-transition: left 200ms ease-in;
                transition: left 200ms ease-in;
                overflow: scroll;
                overflow-x: hidden;
            }

            #menu ul li > ul li a:hover
            {
                background-color:#2e2e2e;
            }


    </style>
