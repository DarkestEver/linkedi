<script type="text/javascript">
function deletevariation() {
    $('.remove_variation').on('click', function(event){
        event.preventDefault();
        //var button = $(event.relatedTarget);
        var button_id = $(this).attr('id');
        var t_id = $('#t_id').val();
            $.ajax({
                type: "POST",
                cache:false,
                dataType: "text",
                url: "<?php echo site_url();?>edm/delete_variation/"+button_id+'/'+t_id,
                success: function (data) {
                    //console.log(data);
                    if (data == 0) {
                        alert('cannot delete last variation');
                    } else {
                        button_id =  button_id.replace( "remove_variation_","div_variation_row_");
                        $('#'+ button_id).remove();
                    }
                },
                error: function () {
                    alert('Error');
                }
            });
    });
}

function savevaraitionscondition()
{
    var t_condition = document.getElementsByName('t_condition[]');
    var t_sending_de_variable = document.getElementsByName('t_sending_de_variable[]');
    var t_hide_show_value = document.getElementsByName('t_hide_show_value[]');
    var t_condition_name = document.getElementsByName('t_condition_name[]');
    var t_hide_or_show = document.getElementsByName('t_hide_or_show[]');
    var variation_conditions = [];
    var data = {};
    for (var i = 0; i <t_sending_de_variable.length; i++) {
        var item = {};
        item['t_condition']=t_condition[i].value;
        item['t_sending_de_variable']=t_sending_de_variable[i].value;
        item['t_hide_show_value']=t_hide_show_value[i].value;
        item['t_condition_name'] = t_condition_name[i].value;
        item['t_hide_or_show'] = t_hide_or_show[i].value;
        item['t_id'] = $('#t_id').val();
        item['edm_id'] = $('#emd_id').val();
        item['campaign_id'] = $('#campaign_id').val();
        variation_conditions.push(item);
    }
    data['t_start_ampscript'] = $('#t_start_ampscript').val();
    data['t_background_color'] = $('#t_background_color').val();
    data['t_background_image_link'] = $('#t_background_image_link').val();
    data['t_end_ampscript'] = $('#t_end_ampscript').val();
    data['condition'] = variation_conditions;
    return data;
}

$("#btn_savevaraitionscondition").click(function() {
    var json_posted_data = savevaraitionscondition();
    if (json_posted_data != false) {
        $.ajax({
            type: "POST",
            cache:false,
            dataType: "text",
            url: "<?php echo site_url();?>/edm/saveTemplateVariation",
            data:{'data':json_posted_data},
            success: function (data) {
                var a = json_posted_data.condition[0];
                append_variation_model(a.t_condition_name, a.t_hide_or_show, a.t_sending_de_variable, a.t_condition,a.t_hide_show_value, a.t_id);
            },
            error: function () {
                alert('Error');
            }
        });
    }
});

function append_variation_model(name, show_hide, de_variable, condition,value, id) {
    var new_variation_div = $('#hidden_variation_block div.row').clone(true);
    new_variation_div.attr('id', 'div_variation_row_' + id)
    new_variation_div.find(".hidden_variation_block_name").html(name );
    new_variation_div.find(".hidden_variation_block_show_hide").html(show_hide );
    new_variation_div.find(".hidden_variation_block_de_variable").html(de_variable );
    new_variation_div.find(".hidden_variation_block_condition").html(condition );
    new_variation_div.find(".hidden_variation_block_value").html(value );
    new_variation_div.find(".remove_variation").attr('id','remove_variation_'+id );
    new_variation_div.appendTo('#variation_display_model');
}

$(document).ready(function() {
    $('#veriationModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget); // Button that triggered the modal
        var recipient = button.data('variation'); // Extract info from data-* attributes
        //alert(recipient);
        $("#t_id").val(recipient);
        var edm_id = $('#emd_id').val();
        var campaign_id = $('#campaign_id').val();
        $('#variation_display_model').empty();
        $.ajax({
            type: "POST",
            cache:false,
            dataType: "text",
            url: "<?php echo site_url();?>/edm/getTemplateVariationByTemplateId/" + campaign_id + "/" + edm_id + "/" + recipient,
            success: function (data) {
                data = JSON.parse(data);
                for (var i = 0; i < data.length ; i ++) {
                    append_variation_model(data[i]['name'], data[i]['m.show_or_hide'], data[i]['variable_name'], data[i]['conditions'],data[i]['hide_show_value'], data[i]['id']);
                }
            },
            error: function () {
                alert('Error');
            }
        });
    })
})

var output;
$(document).ready(function() {
    deletevariation();
    $(".draggable").draggable({
        revert: true,
        cursor: "move", cursorAt: { top: 56, left: 56 } ,
        scroll: true,
        scrollSensitivity: 100
    });
    $( "ul, li" ).disableSelection();
    $("#droppable").droppable({
        drop: function (event, ui) {
            if ( (typeof ui.draggable.attr("id") !== 'undefined' ) && (typeof ui.draggable.data("module") !== 'undefined' )){
                var emd_id = $('#emd_id').val();
                var campaign_id = $('#campaign_id').val();
                var dragged_mod = ui.draggable.data("module");
                ajax_gettemplatemoduleid(campaign_id,emd_id, dragged_mod);
            }
        }
    });

    function append_new_module(dragged_mod,li_new_id ) {
        var new_mod = ' li.' + dragged_mod;
        var new_module_added = $('#moduleshid' + new_mod ).clone(true);
        new_module_added.attr("id", li_new_id);
        $("html, body").animate({ scrollTop: $(document).height() }, 1500);
        $('#droppable').append(new_module_added);
        $("#" + li_new_id).append('<div   style="right: 0;position: absolute;top:0" class="delete_li btn btn-danger btn-sm" data-deleteli="'+li_new_id+'"><i class="fas fa-trash"></i></div>' );
        $("#" + li_new_id).append('<div class="addvariation" style="left: 0;right: auto;position: absolute;top:0"><button type="button" class="btn btn-primary btn-sm"  data-toggle="modal" data-target="#veriationModal" data-variation="'+li_new_id+'"><i class="fab fa-buffer"></i></button></div>' );
        delete_templatemod();
    }

    function ajax_gettemplatemoduleid(campaign_id, emd_id, mod_name) {
        var item = {};
        item["campaign_id"] = campaign_id;
        item['emd_id'] = emd_id;
        item["mod"] = mod_name;
        var objectDataString = JSON.stringify([item]);
        $.ajax({
            type: "POST",
            cache:false,
            dataType: "json",
            url: "<?php echo site_url();?>/edm/getDraggedModuleTemplateId",
            data:{
                'data':objectDataString
            },
            success: function (data) {
                output =  data[0].t_id;
                append_new_module(mod_name,output);
            },
            error: function () {
                alert('Error');
            }
        });
    }

    $( "#droppable" ).sortable({
        revert: "invalid",
    });

    function delete_templatemod() {
        $(".delete_li").click(function(e) {
            var delete_li = $(this).data('deleteli'); // Extract info from data-* attributes
            ajax_TemplateModuleDeleteById(delete_li);
        });
    }

    delete_templatemod();
});

function ajax_TemplateModuleDeleteById(id) {
    $.ajax({
        type: "POST",
        cache:false,
        dataType: "text",
        url: "<?php echo site_url();?>/edm/deleteById/" + id,
        success: function (data) {
            $("#" + id).remove();
        },
        error: function () {
            alert('Error');
        }
    });
}

function getModuleDetails() {
    var listItems = $("#droppable li");
    for (let li of listItems) {
        $(li).attr("data-positions",$(li).index());
    }

    var jsonObj = []
    var listItems = $("#droppable li");
    for (let li of listItems) {
        var mod_name = $(li).attr("class").toString();
        mod_name = mod_name.substr(0, mod_name.indexOf(' '));
        var emd_id = $('#emd_id').val();
        var campaign_id = $('#emd_id').val();
        var item = {}
        item["position"] = $(li).index();
        item['emd_id'] = emd_id;
        item["mod"] = mod_name;
        item["t_id"] = $(li).attr("id");
        item["campaign_id"]= campaign_id;
        jsonObj.push(item);
    }
    if (jsonObj.length == 0) {
        return false;
    }
    return  jsonObj ;
}

function ajax_savetemplate(json_posted_data) {
    var objectDataString = JSON.stringify(json_posted_data);
    $.ajax({
        type: "POST",
        cache:false,
        dataType: "text",
        url: "<?php echo site_url();?>/edm/saveTemplates",
        data:{
            'data':objectDataString
        },
        success: function (data) {
            window.location.href = "<?php echo site_url().'edm/create/campaign/'.$campaign_id ; ?>" ;
        },
        error: function () {
            alert('Error');
        }
    });
}

$(document).ready(function() {
    $("#saveTemplates").click(function() {
        var json_posted_data = getModuleDetails();
        if (json_posted_data != false) {
            ajax_savetemplate(json_posted_data);
        } else {
            alert('Please add modules');
        }
    });
});
</script>