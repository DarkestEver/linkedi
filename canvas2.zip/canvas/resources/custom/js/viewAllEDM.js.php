<script type="text/javascript">
$(document).ready(function(){
  var dataTable = $('#dataTable').DataTable({
    'processing': true,
    'serverSide': true,
    'serverMethod': 'post',
    'searching': false, // Remove default Search Control
    'ajax': {
       'url':'../ajax_searchEDM',
       'data': function(data){
          // Read values
          data.emailname = $('#emailname').val();
          data.categoryName = $('#categoryName').val();
          data.vertical = $('#vertical').val();
          data.wheel = $('#wheel').val();         
       }
    },
    'columns': [
       { data: 'email_name' }, 
       { data: 'category_name' },
       { data: 'vertical_name' },
       { data: 'wheels' },
       { data: 'createddate' },
       { data: 'status' },
       { data: 'id' },
       { data: 'id' },
       { data: 'id' },
       { data: 'id' }
    ],
    'columnDefs':
    [         {  
                'targets': 5,
                 render: function (data, type, row, meta) {  
                 return 'TBD';  
              }},
              {  
                'targets': 6,
                 render: function (data, type, row, meta) {  
                 return '<a target="_blank" href="<?php echo base_url()?>edm/viewLocalizedInputLinks/' + row["id"] + '">Link</a>'; 
              }},
              {  
                'targets': 7,
                 render: function (data, type, row, meta) {  
                 return '<a target="_blank" href="<?php echo base_url()?>edm/get_ampscript/' + row["id"] + '">Link</a>'; 
              }},
              {  
                'targets': 8,
                 render: function (data, type, row, meta) {  
                 return '<a target="_blank" href="<?php echo base_url()?>edm/export_translation_de/' + row["id"] + '">Link</a>'; 
              }},
              {  
                'targets': 9,
                 render: function (data, type, row, meta) {  
                 return '<a target="_blank" href="<?php echo base_url()?>edm/apicalls/' + row["id"] + '">API</a>'; 
              }}
           
    ]
  });

$('#search').click(function(){
    dataTable.draw();
  });
});

</script>