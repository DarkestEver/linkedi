<script type="text/javascript">
$(document).ready(function(){
  var dataTable = $('#dataTable').DataTable({
    'processing': true,
    'serverSide': true,
    'serverMethod': 'post',
    'searching': false, // Remove default Search Control
    'ajax': {
       'url':'<?php echo base_url()?>Campaign/ajax_searchCamaign',
       'data': function(data){
          // Read values
          data.emailname = $('#emailname').val();
          data.categoryName = $('#categoryName').val();
          data.vertical = $('#vertical').val();
          data.wheel = $('#wheel').val();         
       }
    },
    'columns': [
       { data: 'campaign_name' }, 
       { data: 'category_name' },
       { data: 'vertical_name' },
       { data: 'wheels' },
       { data: 'createddate' },
       { data: 'status' },
       { data: 'id' },
       { data: 'id' }
    ],
    'columnDefs':
    [         {  
                'targets': 5,
                 render: function (data, type, row, meta) {  
                 return 'TBD';  
              }},
              {  
                'targets': 6,
                 render: function (data, type, row, meta) {  
                 return '<a  href="<?php echo base_url()?>edm/create/campaign/' + row["id"] + '">Link</a>'; 
              }},
              {  
                'targets': 7,
                 render: function (data, type, row, meta) {  
                 return '<a  href="<?php echo base_url()?>Campaign/delete_edm/' + row["id"] + '">Link</a>'; 
              }}
           
    ]
  });

$('#search').click(function(){
    dataTable.draw();
  });
});
</script>