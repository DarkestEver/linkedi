<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Start extends CI_Controller {

	public function index()
	{
		if ($this->Admin_model->verifyUser()) {
            // Breadcrumb
            $crumb = new crumb();
            $crumb->label = 'Dashboard';
            $crumb->classname = 'title active';
            $crumb->url = '';
            $bc = new Breadcrumb();
            $bc->setCrumbs(array($crumb));
            $settings['breadcrumb'] = $bc; // $this->load->view('view_breadcrumb', NULL, TRUE);
		$settings['sidebar'] = 'Dashboard';

            $this->load->model('Dashboard_model');
            $data['getTotalCampaign'] = $this->Dashboard_model->getTotalCampaign();
            $data['getTotalEDMs'] = $this->Dashboard_model->getTotalEDMs();
            $data['getTotalLocalEDMs'] = $this->Dashboard_model->getTotalLocalEDMs();
            $data['getTotalUser'] = $this->Dashboard_model->getTotalUser();

            $this->load->view('header', $settings);
			$this->load->view('welcome_message',$data);
			$this->load->view('footer');
		}
	}
}
