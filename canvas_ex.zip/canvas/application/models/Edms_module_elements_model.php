<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Edms_module_elements_model extends CI_Model {

        public function __construct()
        {
                parent::__construct();
                // Your own constructor code
        }

        public function getModuleElementsById($id='')
        {
            $sql = "SELECT * FROM edms_module_elements where module_id =".$id." ;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }
        
}