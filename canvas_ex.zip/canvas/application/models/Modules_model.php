<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Modules_model extends CI_Model {

        public function __construct()
        {
                parent::__construct();
                // Your own constructor code
        }

        public function getDraggableModules($value='')
        {
            $sql = "SELECT * FROM modules where is_active = 1;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }
        public function getDraggableModulesbyKey($value)
        {
            $sql = "SELECT * FROM modules where module_key='".$value."';";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function getModulesCategory($value='')
        {
            $sql = "SELECT * FROM modules_category where is_deleted = 0;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }
}