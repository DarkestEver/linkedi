<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Template_model extends CI_Model {
  
        public function __construct()
        {
                parent::__construct();
                // Your own constructor code
        }

        public function saveTempate($campaign_id, $edm_id ,$module_key ,$module_position ,$createdby ='0'){
            $sql2 = 'INSERT INTO templates (`campaign_id`, `edm_id` ,`module_key` ,`module_position` ,`createdby` ) VALUES ('.$campaign_id . ','. $edm_id . ',' . $module_key . ',' . $module_position . ',' . $createdby . ');';
            
            $this->db->query($sql2);
            $t_id =  $this->db->insert_id();
            $variable_id = $this->default_save($campaign_id,$edm_id, $t_id);
            $this->edms_saved_inputs($edm_id, $t_id,$variable_id);
            return $t_id;
        }
        public function default_save($campaign_id,$edm_id,$t_id)
        {
            $sql2 = 'INSERT INTO template_variations (`name` ,`show_or_hide` ,`variable_name` ,`conditions`, `t_id`, `hide_show_value`,`campaign_id`, `edm_id` ) VALUES ( "default", 0 ,"","",' . $t_id. ',"",'.$campaign_id.','.$edm_id.');';
            $this->db->query($sql2);
            return $this->db->insert_id();
        }
        public function edms_saved_inputs($value, $t_id,$variable_id)
        {
            $sql2 = "INSERT INTO edms_saved_inputs(campaign_id, edm_id ,module_position, module_id, element_id ,key_name , title ,alias, href ,editable_type,country_code ,language_code, link ,template_id,variation_id  ) select t.campaign_id, t.edm_id, t.module_position,m.id as module_id,eme.id,CONCAT(t.id ,'_',eme.elements ) as key_name, eme.title, eme.alias,eme.href,eme.editable_type,c.country_code,c.language_code, eme.link, t.id, ". $variable_id ." from templates t   inner join modules m on t.module_key = m.module_key inner join edms_module_elements eme on eme.module_id = m.id inner join edm_countries ec on ec.edm_id = t.edm_id inner join countries c on ec.country_id = c.id where t.edm_id = ". $value . " and t.id = " . $t_id ;
            $this->db->query($sql2);
            return true;
        }

        public function updateTempate($campaign_id,$edm_id ,$module_key ,$module_position, $t_id  ,$createdby ='0'){
            $sql2 = "update templates set  module_key  = " .$module_key. ", module_position = " .$module_position . " where id = " . $t_id . " ;" ;
            $this->db->query($sql2);
            //return $this->db->insert_id();
        }

        public function getTemlateByID($campaign_id, $value)
        {
            $sql = "select esi.*, m.id as module_id,  m.content_block,m.display_html,m.module_name , m.module_html , m.module_key, esi.id as t_id from templates esi inner join modules m on esi.module_key = m.module_key where esi.edm_id = ". $value . " and esi.campaign_id = ".$campaign_id." order by esi.module_position asc,  esi.id asc ";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }
        
         public function getTemlatewithvariation($campaign_id, $value)
        {
            $sql = "select esi.*,tv.id as variation_id,  tv.name as variation_name, m.id as module_id,  m.content_block,m.display_html,m.module_name , m.module_html , m.module_key, esi.id as t_id from templates esi inner join modules m on esi.module_key = m.module_key inner join template_variations tv on tv.t_id = esi.id where esi.edm_id = ". $value . " and esi.campaign_id = ".$campaign_id." order by esi.module_position asc,  esi.id asc ";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }
        public function deleteById($id='')
        {
            $sql = "DELETE FROM templates where id =".$id." ;";
                    $query = $this->db->query($sql);
             $sql = "DELETE FROM edms_saved_inputs where template_id =".$id." ;";
                    $query = $this->db->query($sql);
                    return 1;
        }


        public function getComponentCountByEdmID($value)
        {
            $sql = "SELECT count(1) as count FROM templates where edm_id = '" . $value . "';";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }


}