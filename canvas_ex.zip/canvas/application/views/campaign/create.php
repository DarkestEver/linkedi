<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
?>
                <div class='panel panel-default'>
                    <div class='panel-heading'>
                        <i class='fas fa-cubes'></i>
                        New Campaign
                        <div class='panel-tools'>
                            <div class='btn-group'>
                                <a class='btn' data-toggle='toolbar-tooltip' href='#' title="Reload">
                                    <i class='fa fa-refresh'></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class='panel-body'>
                        <div class='row'>&nbsp;</div>
                        <div class='row'>
                            <form method="POST" action="#">
                                <div class="col-lg-12">
                                    <div >
                                        <div class="form-group row">
                                            <div class="col-sm-3" >
                                                <label for="male"  style="padding:.375rem .75rem" >Campaign Name</label>
                                            </div>
                                            <div class="col-sm-6">
                                                <input type="text" class="form-control" name="emailname" id="emailname" placeholder="Campaign Name">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-3" >
                                                <label for="male"  style="padding:.375rem .75rem" >Category Name</label>
                                            </div>
                                            <div class="col-sm-6">
                                                <select class="form-control" id="categoryName"  name="categoryName" placeholder="categoryName">
                                                    <?php foreach ($category as $key => $value) {
                                                        echo '<option value="'.$value['category_name'].'">'.$value['category_name'].'</option>';
                                                    } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-3" >
                                                <label for="male"  style="padding:.375rem .75rem" >Vertical Name</label>
                                            </div>
                                            <div class="col-sm-6">
                                                <select class="form-control" id="vertical" name="vertical" placeholder="vertical">
                                                    <?php foreach ($verticals as $key => $value) {
                                                        echo '<option value="'.$value['vertical_name'].'">'.$value['vertical_name'].'</option>';
                                                    } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group row" id="div_wheel">
                                            <div class="col-sm-3" >
                                                <label for="male"  style="padding:.375rem .75rem" >Wheels</label>
                                            </div>
                                            <input type="hidden" name="wheel" id="wheel">
                                            <div class="col-sm-6">
                                                <select class="form-control" id="dropdown_wheel"  placeholder="wheel">
                                                    <?php foreach ($wheels as $key => $value) {
                                                        echo '<option value="'.$value['wheel_name'].'">'.$value['wheel_name'].'</option>';
                                                    } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <!--
                                        <div class="form-group row">
                                            <div class="col-sm-3" >
                                                <label for="male"  style="padding:.375rem .75rem" >Market Name</label>
                                            </div>
                                            <div class="col-sm-6">
                                                <?php foreach ($countries as $key => $country) { ?>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="checkbox" name="countries[]" id="<?php echo $country['country_name']; ?>" value="<?php echo $country['id']; ?>">
                                                    <label class="form-check-label" for="inlineCheckbox1"><?php echo $country['country_code']."_".$country['language_code']; ?></label>
                                                </div>
                                                <?php } ?>
                                            </div>
                                        </div>
                                        -->
                                        <div class="row">
                                            <div class="col-sm-9">
                                                <input type="submit" class="btn btn-primary" value="Save">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- <div class='panel-footer'>
                        </div> -->
                    </div>
                </div>
