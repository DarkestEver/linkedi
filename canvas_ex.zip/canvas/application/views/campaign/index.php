<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
?>
    
<div class="row">
    <div class="col-md-2">
        <?php folder_tree(); ?>
    </div>
    <div class="col-md-10">
                <div class='panel panel-default'>
                  
                    <div class='panel-heading'>
                        <i class='fas fa-cubes'></i>
                        Campaigns
                        <div class='panel-tools'>
                            <div class='btn-group'>
                                <a class='btn' data-toggle='toolbar-tooltip' href="<?php echo site_url();?>campaign/create/" title="New Campaign">
                                    <i class='fa fa-plus'></i>
                                </a>
                                <a class='btn' data-toggle='toolbar-tooltip' href='#' title="Refresh Lists">
                                    <i class='fa fa-refresh'></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class='panel-body filters'>
                        
                        <div class='row'>
                        </div>
                        <div class='row'>
                            &nbsp;
                        </div>
                        <table class='table table-bordered' id="dataTable">
                            <thead>
                                <tr>
                                    <th>Email Name</th>
                                    <th>Country</th>
                                    <th>Language</th>
                                    <th>Date Created</th>
                                    <th>Status</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>

                    </div>
                </div>
    </div>           