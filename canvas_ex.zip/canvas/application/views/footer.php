<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
?>
			</div>
	    	<!-- Footer -->
	    	<section id="footer" style="display: none;">
	            <div data-toggle="tooltip" title="" data-original-title="">
	                <span>
	                    <img class="pull-left footer-logo" src="<?=base_url()?>resources/img/module_icon/canvas.png" alt="Canvas Logo" width="24" height="24">
	                </span>
	                <span class="pull-left">
	                    Copyright &copy; 2020.
	                </span>
	                <span class="pull-right">
	                    Version 1.0.8
	                </span>
	            </div>
	        </section>
			<!-- End of Footer -->
	    	<!-- Scroll to Top Button-->
			<a class="scroll-to-top rounded" href="#page-top" style="display: none;">
				<i class="fas fa-angle-up"></i>
			</a>
    	</div>
    	<!-- Javascripts -->
    	<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
		<!-- Bootstrap core JavaScript-->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
		<script src="//cdnjs.cloudflare.com/ajax/libs/modernizr/2.6.2/modernizr.min.js" type="text/javascript"></script>
		<script src="<?=base_url()?>resources/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
		<!-- Core plugin JavaScript-->
		<script src="<?=base_url()?>resources/vendor/jquery-easing/jquery.easing.min.js"></script>
		<!-- Page level plugins -->
		<script src="<?=base_url()?>resources/vendor/datatables/jquery.dataTables.min.js"></script>
		<script src="<?=base_url()?>resources/vendor/datatables/dataTables.bootstrap4.min.js"></script>
		<!-- Tree Folder Structure -->
		<script src="<?=base_url()?>resources/vendor/folderstructure/js/jquery-explr-1.4.js"></script>
		<!-- Tree Folder Structure -->
		<script src="<?=base_url()?>resources/vendor/contextMenu/dist/jquery.ui.position.js"></script>
		<script src="<?=base_url()?>resources/vendor/contextMenu/dist/jquery.contextMenu.js"></script>
		<!-- NOtification -->
		<script src="<?=base_url()?>resources/vendor/notify.min.js"></script>
		<!-- Custom scripts for all pages-->
		<script src="<?=base_url()?>resources/js/application.js"></script>

		<script type="text/javascript">
			function alert_message(message,class_name) {
			 	$.notify(message, 
			 		{
						  // whether to hide the notification on click
						  clickToHide: true,
						  // whether to auto-hide the notification
						  autoHide: true,
						  // if autoHide, hide after milliseconds
						  autoHideDelay: 5000,
						  // show the arrow pointing at the element
						  arrowShow: true,
						  // arrow size in pixels
						  arrowSize: 5,
						  // position defines the notification position though uses the defaults below
						  //position: 'left',
						  // default positions
						  elementPosition: 'bottom left',
						  globalPosition: 'top center',
						  // default style
						  style: 'bootstrap',
						  // default class (string or [string])
						  className: class_name,
						  // show animation
						  showAnimation: 'slideDown',
						  // show animation duration
						  showDuration: 400,
						  // hide animation
						  hideAnimation: 'slideUp',
						  // hide animation duration
						  hideDuration: 400,
						  // padding between element and notification
						  gap: 2
						}
			 		);
			}

			$(document).ready(function() {
				$(".ajax_loader").hide();

			});
			$(document).ajaxStart(function() {
		        // show loader on start
		        $(".ajax_loader").css("display","block");
		    }).ajaxSuccess(function() {
		        // hide loader on success
		        $(".ajax_loader").css("display","none");
		    });
		</script>

		<?php
		if (isset($js) && !(empty($js)))
		{
			include 'resources/custom/js/'.$js.'.js.php';
		}
		?>

		<?php
		if (isset($css) && !(empty($css))) {
			include 'resources/custom/css/'.$css.'.css.php';
		}
		?>
		<style type="text/css">
			.addvariation{display: none;}
		</style>
  	</body>
</html>
