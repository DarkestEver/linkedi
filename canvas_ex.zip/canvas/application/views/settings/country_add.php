<?php
defined('BASEPATH') OR exit('No direct script access allowed');
if (!empty($result))
{
  $result = $result[0];
  $post_type = 'edit';
}
else
{
  $post_type = 'save';
}
?>
            <form method="POST" action="#"  >
            <input type="hidden" name="action" value="<?php echo $post_type;?>">
            <div class="form-group row">
              <label for="example-text-input" class="col-2 col-form-label">Country Name</label>
              <div class="col-10">
                <input class="form-control" type="text" value="<?php echo (!empty($result))?$result['country_name'] :''   ;?>" placeholder="" name="country_name" <?php echo (!empty($result))?'readonly="readonly"':''   ;?> >
              </div>
            </div>
            <div class="form-group row">
              <label for="example-text-input" class="col-2 col-form-label">Country Code</label>
              <div class="col-10">
                <input class="form-control" type="text" value="<?php echo (!empty($result))?$result['country_code'] :''   ;?>" placeholder="" name="country_code" <?php echo (!empty($result))?'readonly="readonly"':''   ;?>>
              </div>
            </div>
            <div class="form-group row">
              <label for="example-text-input" class="col-2 col-form-label">Country Language</label>
              <div class="col-10">
                <input class="form-control" type="text" value="<?php echo (!empty($result))?$result['language_code'] :''   ;?>" placeholder="" name="language_code">
              </div>
            </div>

            <div class="form-group row">
              <div class="col-10">
                <input type="submit" value="<?php echo ucfirst($post_type);?>" class="btn btn-primary">
                <?php if($post_type =="edit") {
                  echo '<input type="submit" name="action" value="delete" class="btn btn-primary">';
                } ?>
              </div>
            </div>


        </form>
