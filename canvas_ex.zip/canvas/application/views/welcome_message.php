<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
?>
                <div class='panel panel-default'>
                    <div class='panel-heading'>
                        <i class='fas fa-tachometer-alt'></i>
                        Dashboard
                        <div class='panel-tools'>
                            <div class='btn-group'>
                                <a class='btn' data-toggle='toolbar-tooltip' href='#' title="Refresh Statistics">
                                    <i class='fa fa-refresh'></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class='panel-body'>
                        <!-- <div class='page-header'>
                            <h4>Progress</h4>
                        </div>
                        <div class='progress'>
                            <div class='progress-bar progress-bar-success' style='width: 35%'></div>
                            <div class='progress-bar progress-bar-warning' style='width: 20%'></div>
                            <div class='progress-bar progress-bar-danger' style='width: 10%'></div>
                        </div> -->
                        <div class='page-header'>
                            <h4>Components</h4>
                        </div>
                        <div class="row">&nbsp;</div>
                        <div class='row text-center'>
                            <div class='col-md-3'>
                                <input class='knob' data-bgcolor='#d4ecfd' data-fgcolor='#30a1ec' data-height='140' data-inputcolor='#333' data-thickness='.3' data-width='140' type='text' value='<?php echo $getTotalCampaign  ;?>'>
                                <h4>Campaigns</h4>
                            </div>
                            <div class='col-md-3'>
                                <input class='knob second' data-bgcolor='#c4e9aa' data-fgcolor='#8ac368' data-height='140' data-inputcolor='#333' data-thickness='.3' data-width='140' type='text' value='<?php echo $getTotalEDMs  ;?>'>
                                <h4>EDMs</h4>
                            </div>
                            <div class='col-md-3'>
                                <input class='knob second' data-bgcolor='#cef3f5' data-fgcolor='#5ba0a3' data-height='140' data-inputcolor='#333' data-thickness='.3' data-width='140' type='text' value='<?php echo $getTotalLocalEDMs  ;?>'>
                                <h4>EDM Languages</h4>
                            </div>
                            <div class='col-md-3'>
                                <input class='knob second' data-bgcolor='#f8d2e0' data-fgcolor='#b85e80' data-height='140' data-inputcolor='#333' data-thickness='.3' data-width='140' type='text' value='<?php echo $getTotalUser  ;?>'>
                                <h4>Users</h4>
                            </div>
                        </div>
                    </div>
                </div>
