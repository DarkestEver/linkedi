<script type="text/javascript">
    $(document).ready(function() {
      

    });

    jQuery.browser = {};
    (function () {
        jQuery.browser.msie = false;
        jQuery.browser.version = 0;
        if (navigator.userAgent.match(/MSIE ([0-9]+)\./)) {
            jQuery.browser.msie = true;
            jQuery.browser.version = RegExp.$1;
        }
    })();
    $(document).ready(function(){
        $("#tree").explr();
    });


    var selected_campaign ="";
    $('.campaign_selected').click(function(){
        selected_campaign = $(this).data("campaign_id");
       get_campaign_list(selected_campaign);
    });


function get_campaign_list(campaign_id)
{
    var dataTable = $('#dataTable').DataTable({
            'processing': true,
            'serverSide': true,
            'serverMethod': 'post',
            'searching': false, // Remove default Search Control
            searching: false, paging: false, info: false, "destroy": true,"bJQueryUI": true,
            'ajax': {
                'url':'<?php echo base_url()?>Campaign/ajax_campaign_selected/' + campaign_id  ,
                "type": "POST",
                'data': function(data){
                }
            },
            'columns': [
                { data: 'email_name' },
                { data: 'country_code' },
                { data: 'language_code' },
                { data: 'createddate' },
                { data: 'status' }
            ],
            'columnDefs': [
                {
                    'targets': 0,
                    render: function (data, type, row, meta) {
                        return  "<input type='hidden'   data-campaign='" + row['campaign_id'] + "' data-edm_id ='" + row['id'] + "' data-language_code='" + row['language_code'] + "' data-country_code ='" + row['country_code'] + "'  data-email_name = '" + row['email_name']+"'   /> " +  row['email_name'];
                    }
                },
                {
                    'targets': 4,
                    render: function (data, type, row, meta) {
                        return 'TBD';
                    }
                }
            ]
        });
}

$(function() {
    $.contextMenu({
            selector: '.context-menu-one', 
            callback: function(key, options) {
                var m = "clicked: " + key;
                window.console && console.log(m) || alert(m); 
            },
            items: {
                "edit": {name: "Edit", icon: "edit"},
                "cut": {name: "Cut", icon: "cut"},
               copy: {name: "Copy", icon: "copy"},
                "paste": {name: "Paste", icon: "paste"},
                "delete": {name: "Delete", icon: "delete"},
                "sep1": "---------",
                "quit": {name: "Quit", icon: function(){
                    return 'context-menu-icon context-menu-icon-quit';
                }}
            }
        });

        $('.context-menu-one').on('click', function(e){
            console.log('clicked', this);
        })
        
});
</script>

