<script type="text/javascript">
    $(document).ready(function() {
        var dataTable = $('#dataTable').DataTable({

            "language": {
                "infoFiltered": ""
              },
            'processing': true,
            'serverSide': true,
            'serverMethod': 'post',
            'searching': false, // Remove default Search Control
            'ajax': {
                'url':'<?php echo base_url()?>keywordsearch/search',
                'data': function(data) {
                    // Read values
                    data.keyword = $('#keyword').val();
                }
            },
            'columns': [
                { data: 'campaign_name' },
                { data: 'email_name' },
                { data: 'category_name' },
                { data: 'vertical_name' },
                { data: 'country_code' },
                { data: 'language_code' },
                { data: 'campaign_id' },
                { data: 'edm_id' }
            ],
            'columnDefs': [
                {
                    'targets': 0,
                    render: function (data, type, row, meta) {
                        return "<a href='<?php echo base_url()?>campaign/view/" + row["campaign_id"] + "' data-toggle='tooltip' title='" + row["campaign_name"] + "'>" + row["campaign_name"] + "</a>";
                    }
                },
                {
                    'targets': 1,
                    render: function (data, type, row, meta) {
                        return "<a href='<?php echo base_url()?>email/view/" + row["campaign_id"] + "/" + row["edm_id"] + "' data-toggle='tooltip' title='" + row["email_name"] + "'>" + row["email_name"] + "</a>";
                    }
                },
                {
                    'targets': 6,
                    render: function (data, type, row, meta) {
                        return 'TBA';
                    }
                },
                {
                    'targets': 7,
                    render: function (data, type, row, meta) {
                        return "<a  target='_blank' class='btn btn-warning' href='<?php echo base_url()?>email/desktoppreview/" + row["campaign_id"] + "/"+  row["edm_id"] + "/"+  row["country_code"] + "/"+  row["language_code"] + "' data-toggle='tooltip' title='Edit Campaign'><i class='fas fa-pencil-alt'></i></a>"
                    }
                }
            ]
        });

    var dataTable_promo = $('#dataTable_promo').DataTable({

            "language": {
                "infoFiltered": ""
              },
            'processing': true,
            'serverSide': true,
            'serverMethod': 'post',
            'searching': false, // Remove default Search Control
            'ajax': {
                'url':'<?php echo base_url()?>keywordsearch/search_promo',
                'data': function(data) {
                    // Read values
                    data.keyword = $('#keyword').val();
                }
            },
            'columns': [
                { data: 'campaign_name' },
                { data: 'email_name' },
                { data: 'category_name' },
                { data: 'vertical_name' },
                { data: 'country_code' },
                { data: 'language_code' },
                { data: 'promocode' },
                { data: 'startdate' },
                { data: 'enddate' },
                { data: 'campaign_id' },
                { data: 'edm_id' }
            ],
            'columnDefs': [
                {
                    'targets': 0,
                    render: function (data, type, row, meta) {
                        return "<a href='<?php echo base_url()?>campaign/view/" + row["campaign_id"] + "' data-toggle='tooltip' title='" + row["campaign_name"] + "'>" + row["campaign_name"] + "</a>";
                    }
                },
                {
                    'targets': 1,
                    render: function (data, type, row, meta) {
                        return "<a href='<?php echo base_url()?>email/view/" + row["campaign_id"] + "/" + row["edm_id"] + "' data-toggle='tooltip' title='" + row["email_name"] + "'>" + row["email_name"] + "</a>";
                    }
                },
                {
                    'targets': 9,
                    render: function (data, type, row, meta) {
                        return 'TBA';
                    }
                },
                {
                    'targets': 10,
                    render: function (data, type, row, meta) {
                        return "<a  target='_blank' class='btn btn-warning' href='<?php echo base_url()?>email/desktoppreview/" + row["campaign_id"] + "/"+  row["edm_id"] + "/"+  row["country_code"] + "/"+  row["language_code"] + "' data-toggle='tooltip' title='Edit Campaign'><i class='fas fa-pencil-alt'></i></a>"
                    }
                }
            ]
        });

        $('#search').click(function() {
              var radioValue = $("input[type=radio][name=search_radio]:checked").val();
            if (radioValue == 'p') {
                $('#div_dataTable').hide();
                $('#div_dataTable_promo').show();
                dataTable_promo.draw();
            }
            else if (radioValue == 's') {
                $('#div_dataTable').show();
                $('#div_dataTable_promo').hide();
                dataTable.draw();
            }       
            
        });

        $('input[type=radio][name=search_radio]').change(function() {
            if (this.value == 'p') {
                $('#div_dataTable').hide();
                $('#div_dataTable_promo').show();
                dataTable_promo.draw();
            }
            else if (this.value == 's') {
                $('#div_dataTable').show();
                $('#div_dataTable_promo').hide();
                dataTable.draw();
            }
        });
    });
</script>
