<script type="text/javascript">

    var language_code = $('#hidden_language').val();
    var country_code = $('#hidden_country').val();
    var campaign_id = $('#hidden_campaign_id').val();
    var edm_id =  $('#hidden_emd_id').val();
    
    $('#showTagpromocode').click(function() {
        $('#newEmail').modal();
    })

    $('#promocode_enddate').datepicker({ todayBtn: "linked",
    clearBtn: true,
    autoclose: true,
    todayHighlight: true,
    dateFormat: 'yy-mm-dd'
    });

    $('#promocode_startdate').datepicker({ todayBtn: "linked",
    clearBtn: true,
    autoclose: true,
    todayHighlight: true,
    dateFormat: 'yy-mm-dd'
    });

    function listofpromo()
    {
       var dataTable = $('#dataTable').DataTable({
             "ajax": "<?php echo site_url();?>email/getListOfTaggedPromocode/"+  country_code +'/' + language_code + "/"+edm_id,
             responsive: true,searching: false, paging: false, info: false, "destroy": true,
              columns: [
                { "data": "promocode" },
                { "data": "startdate" },
                { "data": "enddate" }
              ]
        });
    }

    $("#newEmail").on('show.bs.modal', function(){
        $('#promocode').val('');
        $('#promocode_startdate').val('');
        $('#promocode_enddate').val('');
        listofpromo();
            var tab_id = $("#variation_id").val().replace("tab_","");
            $.ajax({
                type: "POST",
                cache:false,
                dataType: "text",
                url: "<?php echo site_url();?>email/getTaggedPromocode/"+tab_id + '/' +  country_code +'/' + language_code + "/"+edm_id + "/" + campaign_id,
                // data:{'data':objectDataString},
                success: function (data) {
                    data = JSON.parse(data);
                    if (data.length > 0)
                    {
                        data = data[0];
                        $('#promocode').val(data['promocode']);
                        $('#promocode_startdate').val(data['startdate']);
                        $('#promocode_enddate').val(data['enddate']);
                        
                    }
                },
                error: function () {
                    alert('Error');
                }
            });
     });



    $('#btn_save_new_promocode').click(function() 
    {   
        var tab_id = $("#variation_id").val().replace("tab_","");  
        var promocode = $("#promocode").val(); 
        var promocode_startdate = $("#promocode_startdate").val(); 
        var promocode_enddate = $("#promocode_enddate").val(); 

        if (promocode == "" && promocode_startdate == "" && promocode_enddate == "")
        {
            alert_message("Please provide all required values","warn");
            return false;
        }

        $.ajax({
            url: '<?php echo site_url();?>email/setTaggedPromocode',
            dataType: 'json',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({"tab_id": tab_id, "country_code": country_code, "language_code":language_code, "edm_id":edm_id, "campaign_id":campaign_id , "promocode":promocode, "promocode_startdate":promocode_startdate,"promocode_enddate":promocode_enddate}),
            processData: false,
            success: function( data, textStatus, jQxhr ){
                alert_message("Promocode tagged successfully!","info");
            },
            error: function( jqXhr, textStatus, errorThrown ){
                alert_message("Something went wrong. Please contact support" + errorThrown,"error");
            }
        });
    });

    $( document ).ready(function() {
        $('#editable_section').hide();
        $('#showTagpromocode').hide();
        $('#alert_msg').hide();
        $("#editable_modules a").removeAttr('href');
    });
    function variation_tab() {
        $('.select_variation').click(function() {
            var tab_id = $(this).data('target').replace("#tab_","");
            $("#variation_id").val(tab_id);
            var edm_id =  $('#hidden_emd_id').val();
            $.ajax({
                type: "POST",
                cache:false,
                dataType: "text",
                url: "<?php echo site_url();?>email/getTemplateVariationByVariationId/"+tab_id + '/' +  country_code +'/' + language_code + "/"+edm_id + "/" + campaign_id,
                // data:{'data':objectDataString},
                success: function (data) {
                    data = JSON.parse(data);
                    vdata = data;
                    data = data[0];
                    $('#editable_section_start_ampscript').val(data['start_ampscript']);
                    $('#editable_section_imagesrc').val(data['href']);
                    $('#editable_section_title').val(data['title']);
                    $('#editable_section_redirect_link').val(data['link']);
                    $('#editable_section_alias').val(data['alias']);
                    $('#editable_section_end_ampscript').val(data['ampscript']);
                    try {
                        put_returned_html_data(vdata);
                    } catch(err) {
                        console.log(err.message);
                    }
                },
                error: function () {
                    alert('Error');
                }
            });
        });
    }

    function put_returned_html_data(vdata) {
        for (var i = 0; i < vdata.length ; i ++) {
            var module_type = vdata[i].editable_type;
            var ele_key_name = vdata[i].key_name;
            if (module_type == "cta") {
                $('#' + ele_key_name + ' a').html(vdata[i].title);
            }
            if (module_type == "image_withoutlink") {
                $('#' + ele_key_name + ' img').attr('src',vdata[i].href);
            }
            if (module_type == "image_withlink") {
                $('#' + ele_key_name + ' img').attr('src',vdata[i].href);
            }
            if (module_type == "paragraph") {
                $('#' + ele_key_name).text(vdata[i].title);
            }
            if (module_type == "heading") {
                $('#' + ele_key_name).text(vdata[i].title);
            }
            if (module_type == "link_withImageText") {
                $('#' + ele_key_name + ' p').text(vdata[i].title);
                $('#' + ele_key_name + ' img').attr('src',vdata[i].href);
            }
        }
    }

    $('#close_highlighted').click(function(){
        $('.highlight_selected').removeClass('highlight_selected');
        $('#editable_section').hide();
        $('#showTagpromocode').hide();
    });

    function all_editable_section_element_show(obj,module_type) {
        $('#editable_section').hide();
        $('#editable_section_start_ampscript').hide();
        $('#editable_section_imagesrc_div').show();
        $('#editable_section_title').show();
        $('#editable_section_redirect_link').show();
        $('#editable_section_alias').show();
        $('#editable_section_end_ampscript').hide();
        $('#editable_section_start_ampscript').val("");
        $('#editable_section_imagesrc_div').val("");
        $('#editable_section_imagesrc').val("");
        $('#editable_section_title').val("");
        $('#editable_section_redirect_link').val("");
        $('#editable_section_alias').val("");
        $('#editable_section_end_ampscript').val("");
        $('#editable_section_title').attr("placeholder", "Title");
        $('#section_module_type').val(module_type);
        var id = $(obj).attr('id');
        $('.highlight_selected').removeClass('highlight_selected');
        $(obj).addClass('highlight_selected');
        $('#section_key').val(id);
        $('#section_lebel').html(id);
        $('#showTagpromocode').show();
        ajax_getEmdKeyValues(id);
    }

    function all_editable_section_element_post() {
        jsonObj = [];
        item = {}
        item ["start_ampscript"] = $('#editable_section_start_ampscript').val();
        item ["imagesrc"] = $('#editable_section_imagesrc').val();
        item ["title"] = $('#editable_section_title').val();
        item ["link"] = $('#editable_section_redirect_link').val();
        item ["alias"] = $('#editable_section_alias').val();
        item ["end_ampscript"] = $('#editable_section_end_ampscript').val();
        item ["module_type"] = $('#section_module_type').val();
        item ["section_key"] = $('#section_key').val();
        item ["language_code"] = $('#hidden_language').val();
        item ["country_code"] = $('#hidden_country').val();
        item ["variation_id"] = $("#variation_id").val();
        jsonObj.push(item);
        return jsonObj;
    }

    $('[data-editable="link_withImageText"]').click(function() {
        all_editable_section_element_show(this,"link_withImageText");
       
    });

    $('[data-editable="image_withoutlink"]').click(function() {
        all_editable_section_element_show(this,"image_withoutlink");
        
    });

    $('[data-editable="image_withlink"]').click(function() {
        all_editable_section_element_show(this,"image_withlink");
       
    });

    $('[data-editable="cta"]').click(function() {
        all_editable_section_element_show(this,"cta");
        $('#editable_section_imagesrc_div').hide();
        
    });

    $('[data-editable="paragraph"]').click(function() {
       
        $('#editable_section_title').attr("placeholder", "Paragraph");
        all_editable_section_element_show(this,"paragraph");
        $('#editable_section_imagesrc_hide').hide();
        $('#editable_section_redirect_link').hide();
        $('#editable_section_alias').hide();
        $('#editable_section_imagesrc_div').hide();
    });

    $('[data-editable="heading"]').click(function() {
       
        $('#editable_section_title').attr("placeholder", "Heading");
        all_editable_section_element_show(this,"heading");
        $('#editable_section_imagesrc_hide').hide();
        $('#editable_section_redirect_link').hide();
        $('#editable_section_alias').hide();
        $('#editable_section_imagesrc_div').hide();
    });

    function ajax_getEmdKeyValues(posted_key) {
        var edm_id = $("#hidden_emd_id").val();
        $.ajax({
            type: "GET",
            cache:false,
            dataType: "json",
            url: "<?php echo site_url();?>email/getSavedInputValuesByKey/" + posted_key + "/"+country_code+"/" + language_code+"/"+edm_id+"/"+campaign_id,
            //data:{'data':objectDataString},
            success: function (data_r) {
                //var json = $.parseJSON(data);
                var data = data_r.data[0];
                var variations =  data_r.variation;
                //console.log(variations.length);
                var char_max_count = data['title_char_limit']; 
                $('#editable_section_start_ampscript').val(data['start_ampscript']);
                $('#editable_section_imagesrc').val(data['href']);
                $('#editable_section_title').val(data['title']);
                $('#editable_section_redirect_link').val(data['link']);
                $('#editable_section_alias').val(data['alias']);
                $('#editable_section_end_ampscript').val(data['ampscript']);
                $('#variation_container').empty();
                if (variations.length == 1) {
                    var tab_id = 'tab_' + variations[0]['id'];
                    $("#variation_id").val(tab_id);
                } else if (variations.length > 1 ) {
                    $('#editable_section').hide();
                    var str_tag = '<section class="container"><div class="row"><div class="col-md-12"><ul id="tabs" class="nav nav-tabs">';
                    var desc_txt = "", name_text = "";
                    for (var i = 0; i < variations.length ; i ++) {
                        var variations_name = variations[i]['name'];
                        var tab_id = 'tab_' + variations[i]['id'];
                        var show_or_hide = variations[i]['show_or_hide']==0?"hide":"show";
                        var sending_de_variable_name = variations[i]['variable_name'];
                        var varaiation_conditions = variations[i]['conditions'];
                        var varaiation_hide_show_value  = variations[i]['hide_show_value'];
                        name_text = name_text + '<li class="nav-item"><a href="" data-target="#'+tab_id+'" data-toggle="tab" class="nav-link small text-uppercase select_variation">'+variations_name+'</a></li>';
                        if (variations_name.toLowerCase()=="default") {
                            $("#variation_id").val(tab_id);
                            desc_txt = desc_txt + '<div id="'+tab_id+'" class="tab-pane fade"> Default visible </div>' ;
                        } else {
                            desc_txt = desc_txt + '<div id="'+tab_id+'" class="tab-pane fade">'  + show_or_hide + " on variable " + sending_de_variable_name + " " + varaiation_conditions + " value : " + varaiation_hide_show_value   + "</div>" ;
                        }
                    }
                    str_tag = str_tag + name_text + '</ul><div id="tabsContent" class="tab-content">' + desc_txt + '</div></div></div></section>';
                    $('#variation_container').append(str_tag);
                    variation_tab();
                    
                }
                
                $('#editable_section').show();
                char_count_input(char_max_count);

            },
            error: function () {
                alert('Error');
            }
        });
    }

    

    $('#ajax_save_element').click(function() {
        var element_id = $('#section_key').val();
        var module_type = $('#section_module_type').val();
        var error_message='';
        if (module_type == "cta") {
            if ($('#editable_section_title').val() == "" ) {
                error_message = 'no image input';
            }
        }
        if (module_type == "image_withoutlink") {
            if ($('#editable_section_imagesrc').val() == "" ) {
                error_message = 'no image input';
            }
        }
        if (module_type == "image_withlink") {
            if ($('#editable_section_imagesrc').val() == "" ) {
                error_message = 'no image input';
            }
        }
        if (module_type == "paragraph") {
            if ($('#editable_section_title').val() == "" ) {
                error_message = 'no image input';
            }
        }
        if (error_message == "") {
            let data = new FormData($("#form")[0]);
            $.ajax({
                url : '<?php echo site_url();?>email/edmsSavedInputValues',
                type: 'POST',
                data: data,
                processData: false,
                contentType: false,
                success: function(r) {
                    put_returned_html_data(JSON.parse(r));
                    $('#editable_section').hide();
                    $('.highlight_selected').removeClass('highlight_selected');
                },
                error: function(r) {    
                    //console.log('error', r);
                }
            });
        } else {
            alert(error_message);
        }
    });

    $('#file_upload').click(function(e) {
        if ($('#csv_file').get(0).files.length === 0) {
            console.log("No files selected.");
            e.preventDefault();
            return false;
        }
    });

$(document).ready(function(){
var char_max_count = 0;
var char_lenght = 0;
var ele_char_count;
   $('.char_count').hide();
   $('.char_count_input').on('keyup', function() {
         ele_char_count = $( this).parent('.input-group').find(".char_count"); 
         ele_char_count.show();
         char_lenght = this.value.length;
         ele_char_count.text( char_lenght);
         /*
         if (char_max_count <  char_lenght )
         {
            ele_char_count.removeClass('btn-primary');
            ele_char_count.addClass('btn-danger');
         }
         else
         {
            ele_char_count.removeClass('btn-danger');
            ele_char_count.addClass('btn-primary');
         }
         */
    });
});

function char_count_input(char_max_count_ajax)
{   char_max_count = char_max_count_ajax;
    $('.char_count').hide();
    $('.char_count').text("");
    $( ".char_count_input" ).each(function( index ) {
      if ($(this).is(":visible"))
      {
          ele_char_count = $( this).parent('.input-group').find(".char_count"); 
          ele_char_count.show();
          char_lenght = this.value.length;
          ele_char_count.text( char_lenght);
         /* if (char_max_count <  char_lenght )
             {
                ele_char_count.removeClass('btn-primary');
                ele_char_count.addClass('btn-danger');
             }
             else
             {
                ele_char_count.removeClass('btn-danger');
                ele_char_count.addClass('btn-primary');
             }
           */
      }
    });
}
</script>