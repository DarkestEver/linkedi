<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Settings extends CI_Controller {

	public function __construct()
    {
       parent::__construct();
	   $this->load->model('Log_model');
    }
	public function index()
	{
		if ($this->Admin_model->verifyUser()) {
			redirect(base_url(), 'auto');
		}
	}

	public function breadcrum()
	{
		return   array(
			"Dashboard" => site_url(),
            "Country" => site_url()."/settings/countries",
            "Users"=> site_url()."settings/admins/",
            "Groups"=> site_url()."settings/groups/",
            "APIs"=> site_url()."settings/apis/",
            "Vertical" => site_url()."settings/Vertical"
        );
	}

	public function admins($page=null, $adminid=0) {
		if ($this->Admin_model->verifyUser()) {
			if ($this->input->post()) {
				$postData = $this->input->post();
				$this->Admin_model->updateAdmins($postData, $postData["action"]);
			}
			if ($page == "add") {
				$data["admin_groups"] = $this->Admin_model->getAdminGroups();
				$setting['breadcrumb']  = $this->breadcrum();
				$this->load->view('header',$setting );
				$this->load->view('settings/admins_add', $data);
				$this->load->view('footer');
			} elseif ($page == "edit") {
				if ($adminid == null) { redirect(base_url(), 'auto'); }
				$data["admin_groups"] = $this->Admin_model->getAdminGroups();
				$data["result"] = $this->Admin_model->getAdminInfo($adminid);
				$setting['breadcrumb']  = $this->breadcrum();
				$this->load->view('header',$setting );
				$this->load->view('settings/admins_edit', $data);
				$this->load->view('footer');
			} else {
				$data["admins"] = $this->Admin_model->getAdmins();
				$setting['breadcrumb']  = $this->breadcrum();
				$this->load->view('header',$setting );
				$this->load->view('settings/admins', $data);
				$this->load->view('footer');
			}
		}
	}

	public function groups($page=null, $groupid=0) {
		if ($this->Admin_model->verifyUser()) {
			if ($this->input->post()) {
				$postData = $this->input->post();
				$this->Admin_model->updateGroups($postData, $postData["action"]);
			}
			if ($page == "add") {
				$setting['breadcrumb']  = $this->breadcrum();
				$this->load->view('header',$setting );
				$this->load->view('settings/admingroups_add');
				$this->load->view('footer');
			} elseif ($page == "edit") {
				$data["result"] = $this->Admin_model->getAdminGroups($groupid);
				$setting['breadcrumb']  = $this->breadcrum();
				$this->load->view('header',$setting );
				$this->load->view('settings/admingroups_edit', $data);
				$this->load->view('footer');
			} else {
				$data["groups"] = $this->Admin_model->getAdminGroups();
				$setting['breadcrumb']  = $this->breadcrum();
				$this->load->view('header',$setting );
				$this->load->view('settings/groups', $data);
				$this->load->view('footer');
			}
		}
	}

	public function apis($page=null, $groupid=0) {
		$this->load->model('Api_credentials_model');
		if ($this->Admin_model->verifyUser()) {
			if ($this->input->post()) {
				$postData = $this->input->post();
				$this->Api_credentials_model->updateApi($postData, $postData["action"]);
			}
			if ($page == "add") {
				$setting['breadcrumb']  = $this->breadcrum();
				$this->load->view('header',$setting );
				$this->load->view('settings/api_add');
				$this->load->view('footer');
			} elseif ($page == "edit") {
				if ($groupid == null) { redirect(base_url(), 'auto'); }
				$data["result"] = $this->Api_credentials_model->getAllAPIsById($groupid);
				if (empty($data["result"])) { redirect(base_url(), 'auto'); }
				$data["post_type"] = 'edit';
				$setting['breadcrumb']  = $this->breadcrum();
				$this->load->view('header',$setting );
				$this->load->view('settings/api_add', $data);
				$this->load->view('footer');
			} else {
				$data["groups"] = $this->Api_credentials_model->getAllAPIs();
				$setting['breadcrumb']  = $this->breadcrum();
				$this->load->view('header',$setting );
				$this->load->view('settings/api_list', $data);
				$this->load->view('footer');
			}
		}
	}

	public function countries($page=null, $groupid=0) {
		if ($this->Admin_model->verifyUser()) {
			$this->load->model('Country_model');
			if ($this->input->post()) {
				$postData = $this->input->post();
				$this->Country_model->updateCountry($postData, $postData["action"]);
			}
			if ($page == "add") {
				$setting['breadcrumb']  = $this->breadcrum();
				$this->load->view('header',$setting );
				$this->load->view('settings/country_add');
				$this->load->view('footer');
			} elseif ($page == "edit") {
				if ($groupid == null) { redirect(base_url(), 'auto'); }
				$groupid = $this->db->escape(strip_tags($groupid));
				$data["result"] = $this->Country_model->getCountriesByID($groupid);
				if (empty($data["result"])) { redirect(base_url(), 'auto'); }
				$data["post_type"] = 'edit';
				$setting['breadcrumb']  = $this->breadcrum();
				$this->load->view('header',$setting );
				$this->load->view('settings/country_add', $data);
				$this->load->view('footer');
			} else {
				$data["groups"] = $this->Country_model->getCountries();
				$setting['breadcrumb']  = $this->breadcrum();
				$this->load->view('header',$setting );
				$this->load->view('settings/country_list', $data);
				$this->load->view('footer');
			}
		}
	}

	public function Vertical($page=null, $groupid=0) {
		if ($this->Admin_model->verifyUser()) {
			$this->load->model('Vertical_model');
			if ($this->input->post()) {
				$postData = $this->input->post();
				$this->Vertical_model->update($postData, $postData["action"]);
			}
			if ($page == "add") {
				$setting['breadcrumb']  = $this->breadcrum();
				$this->load->view('header',$setting );
				$this->load->view('settings/vertical_add');
				$this->load->view('footer');
			} elseif ($page == "edit") {
				if ($groupid == null) { redirect(base_url(), 'auto'); }
				$groupid = $this->db->escape(strip_tags($groupid));
				$data["result"] = $this->Vertical_model->getByID($groupid);
				if (empty($data["result"])) { redirect(base_url(), 'auto'); }
				$data["post_type"] = 'edit';
				$setting['breadcrumb']  = $this->breadcrum();
				$this->load->view('header',$setting );
				$this->load->view('settings/vertical_add', $data);
				$this->load->view('footer');
			} else {
				$data["groups"] = $this->Vertical_model->getAll();
				$setting['breadcrumb']  = $this->breadcrum();
				$this->load->view('header',$setting );
				$this->load->view('settings/vertical_list', $data);
				$this->load->view('footer');
			}
		}
	}
}
