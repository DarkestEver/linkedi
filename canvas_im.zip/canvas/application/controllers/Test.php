<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends CI_Controller {
     public function __construct() {
        parent::__construct();
        
    }

    public function index($value='')
    {
        $setting["js"] = "test_index";
        $this->load->helper('folderstructure');
        $this->load->view('header');
        $this->load->view('test/view_test');
        $this->load->view('footer', $setting);   
    }
}
