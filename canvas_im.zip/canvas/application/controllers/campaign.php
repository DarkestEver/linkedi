<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class campaign extends CI_Controller {

    public function __construct() {
       parent::__construct();
       $this->load->model('Log_model');
       $this->Admin_model->verifyUser();
    }

    public function index() {
        $this->load->helper('folderstructure');
        $this->load->model('Campaign_model');
        $data['wheels'] = $this->Campaign_model->getAllWheels();
        $data['verticals'] = $this->Campaign_model->getAllVertical();
        $data['category'] = $this->Campaign_model->getAllCategory();
        $data['countries'] = $this->Campaign_model->getCountries();

        // Breadcrumb
        $bc = new Breadcrumb();
        $bc->addCrumbs(true, 'Dashboard', '', site_url() .'start/');
        $bc->addCrumbs(false, 'Campaign', 'title active', site_url() . 'campaign/');
        $settings['breadcrumb'] = $bc;
        $settings['sidebar'] = 'Campaign';
        $settings['css'] = "campaign_index";
        $settings['js'] = "campaign_index";
        $settings['title'] = "Campaign List";

        $this->load->model('Campaign_model');
        $data['wheels'] = $this->Campaign_model->getAllWheels();
        $data['verticals'] = $this->Campaign_model->getAllVertical();
        $data['category'] = $this->Campaign_model->getAllCategory();
        $data['countries'] = $this->Campaign_model->getCountries();

        $this->load->view('header', $settings);
        $this->load->view('campaign/index', $data);
        $this->load->view('footer');
    }

	public function create() {
        if ($this->input->post()) {
            $postData = $this->input->post();
            if (!isset($postData["emailname"]) || empty($postData["emailname"])) {
                $emailname = "";
            } else {
                $emailname = $this->db->escape(strip_tags($postData["emailname"]));
            }

            if (!isset($postData["categoryName"]) || empty($postData["categoryName"])) {
                $categoryName = "";
            } else {
                $categoryName = $this->db->escape(strip_tags($postData["categoryName"]));
            }

            if (!isset($postData["vertical"]) || empty($postData["vertical"])) {
                $vertical = "";
            } else {
                $vertical = $this->db->escape(strip_tags($postData["vertical"]));
            }

            if (!isset($postData["wheel"]) || empty($postData["wheel"])) {
                $wheel = "";
            } else {
                $wheel = $this->db->escape(strip_tags($postData["wheel"]));
            }

            $market = "";//$postData["countries"];
            $this->load->model('Campaign_model');
            $category_id = $this->Campaign_model->createCampaign($emailname,$categoryName,$vertical,$market,$wheel);
            if ($category_id != False) {
                $this->load->helper('url');
                redirect('edm/create/campaign/' . $category_id);
            } else {
                $setting['error_message'] = 'Campaign name already exists';
                $setting['error_type'] = 'warning';
            }
        }

        // Breadcrumb
        $bc = new Breadcrumb();
        $bc->addCrumbs(true, 'Dashboard', '', site_url() .'start/');
        $bc->addCrumbs(false, 'Campaign', '', site_url() . 'campaign/');
        $bc->addCrumbs(false, 'New Campaign', 'title active', site_url() . 'campaign/create/');
        $settings['breadcrumb'] = $bc;
        $settings['sidebar'] = 'Campaign';
        $settings['css'] = "";
        $settings['js'] = "campaign_create";
        $settings['title'] = "Create Campaign";

		$this->load->model('Campaign_model');
        $data['wheels'] = $this->Campaign_model->getAllWheels();
        $data['verticals'] = $this->Campaign_model->getAllVertical();
        $data['category'] = $this->Campaign_model->getAllCategory();
        $data['countries'] = $this->Campaign_model->getCountries();
        $this->load->view('header', $settings);
        $this->load->view('campaign/create', $data);
        $this->load->view('footer');
	}

    public function view($cid = NULL) {
        if (isset($cid)) {
            $campaign_id = $cid;
            $id = $this->db->escape(strip_tags($campaign_id));
            $this->load->model('Campaign_model');
            $campaign_details = $this->Campaign_model->getCampaignsByID($id);
            if (sizeof($campaign_details) > 0) {
                $data['campaign_details'] = $campaign_details;

                $this->load->helper('status');

                // Breadcrumb
                $bc = new Breadcrumb();
                $bc->addCrumbs(true, 'Dashboard', '', site_url() .'start/');
                $bc->addCrumbs(false, 'Campaign', '', site_url() . 'campaign/');
                $bc->addCrumbs(false, $campaign_details[0]['campaign_name'], 'title active', site_url() . 'campaign/view/' . $campaign_details[0]['id'] .'/');
                $settings['breadcrumb'] = $bc;
                $settings['sidebar'] = 'Campaign';
                $settings['title'] = "Campaign : " . $campaign_details[0]['campaign_name'];
                $settings['js'] = "";
                $data['campaign_id'] = $campaign_details[0]['id'];
                $this->load->view('header', $settings);
                $this->load->view('campaign/view', $data);
                $this->load->view('footer');
            } else {
                redirect('campaign/');
            }
        }
    }

    public function delete($cid = NULL) {
        if (isset($cid)) {
            $campaign_id = $cid;
            $id = $this->db->escape(strip_tags($campaign_id));
            $this->load->model('Campaign_model');
            $campaign_details = $this->Campaign_model->getCampaignsByID($id);
            if (sizeof($campaign_details) > 0) {
                $data['campaign_details'] = $campaign_details;

                $this->load->helper('status');

                // Breadcrumb
                $bc = new Breadcrumb();
                $bc->addCrumbs(true, 'Dashboard', '', site_url() .'start/');
                $bc->addCrumbs(false, 'Campaign', '', site_url() . 'campaign/');
                $bc->addCrumbs(false, $campaign_details[0]['campaign_name'], 'title active', site_url() . 'campaign/view/' . $campaign_details[0]['id'] .'/');
                $settings['breadcrumb'] = $bc;
                $settings['sidebar'] = 'Campaign';
                $settings['title'] = "Campaign : " . $campaign_details[0]['campaign_name'];
                $settings['js'] = "";
                $data['campaign_id'] = $campaign_details[0]['id'];
                $this->load->view('header', $settings);
                $this->load->view('campaign/delete', $data);
                $this->load->view('footer');
            } else {
                redirect('campaign/');
            }
        }
    }

    public function ajax_searchCamaign() {
        if ($this->input->post()) {
            $postData = $this->input->post();
            $draw = $postData['draw'];
            $start = $postData['start'];
            $length = $postData['length'];

            if (!isset($postData["emailname"]) || empty($postData["emailname"])) {
                $emailname = "";
            } else {
                $emailname = strip_tags($postData["emailname"]);
            }

            if (!isset($postData["categoryName"]) || empty($postData["categoryName"])) {
                $categoryName = "";
            } else {
                $categoryName = $this->db->escape(strip_tags($postData["categoryName"]));
            }

            if (!isset($postData["vertical"]) || empty($postData["vertical"])) {
                $vertical = "";
            } else {
                $vertical = $this->db->escape(strip_tags($postData["vertical"]));
            }

            if (!isset($postData["wheel"]) || empty($postData["wheel"])) {
                $wheel = "";
            } else {
                $wheel = $this->db->escape(strip_tags($postData["wheel"]));
            }

            $this->load->model('Campaign_model');
            //echo $wheel . $vertical . $categoryName; die;
            $getCampaignCount = $this->Campaign_model->getCampaignCount();
            $result = $this->Campaign_model->searchCampaign($emailname,$categoryName,$vertical,$wheel,$start,$length );
            $response = array(
                "draw" => intval($draw),
                "iTotalRecords" => $getCampaignCount,
                "iTotalDisplayRecords" =>  $result['count'],
                "aaData" => $result['data']
            );
            echo json_encode($response);
        }
    }


    public function ajax_campaign_selected($campaign_id="") {
        if ($this->input->post()) {
            $postData = $this->input->post();
            $draw = $postData['draw'];
            $start = $postData['start'];
            $length = $postData['length'];
            $campaign_id = strip_tags($campaign_id);
            $this->load->model('Campaign_model');
            $result = $this->Campaign_model->getAllEMDByCampaignID($campaign_id,$start,$length );
            $response = array(
                "draw" => intval($draw),
                "iTotalRecords" =>  $result['count'],
                "iTotalDisplayRecords" =>  $result['count'],
                "aaData" => $result['data']
            );
            echo json_encode($response);
        }
    }
}
