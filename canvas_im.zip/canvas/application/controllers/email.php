<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class email extends CI_Controller {

    public function __construct() {
       parent::__construct();
       $this->load->model('Log_model');
       $this->load->helper('alert_message');
       $this->Admin_model->verifyUser();
           
        
    }

    // Views
    public function index() {
        // if ($this->Admin_model->verifyUser()) {
        //     redirect(base_url(), 'auto');
        // }

        $this->load->model('Edm_model');
        $data['edms'] = $this->Edm_model->getAllEmails();

        // Breadcrumb
        $bc = new Breadcrumb();
        $bc->addCrumbs(true, 'Dashboard', '', site_url() .'start/');
        $bc->addCrumbs(false, 'Email', 'title active', site_url() . 'email/');
        $settings['breadcrumb'] = $bc;
        $settings['sidebar'] = 'Email';
        $settings['css'] = '';
        $settings['js'] = 'email_index';
        $settings['title'] = 'Email List';
        //$setting['css'] = "viewAllEDM";

        $this->load->view('header', $settings);
        $this->load->view('email/index', $data);
        $this->load->view('footer');
    }

    public function view($cid=NULL, $eid=NULL) {
        $this->load->model('Edm_model');
        $data['edm_details'] = $this->Edm_model->getEmailByID($cid, $eid);

        // Breadcrumb
        $bc = new Breadcrumb();
        $bc->addCrumbs(true, 'Dashboard', '', site_url() .'start/');
        $bc->addCrumbs(false, 'Email', '', site_url() . 'email/');
        $bc->addCrumbs(false, $data['edm_details'][0]['email_name'], 'title active', site_url() . 'email/view/' . $cid . '/' . $eid);
        $settings['breadcrumb'] = $bc;
        $settings['sidebar'] = 'Email';
        $settings['css'] = '';
        $settings['js'] = '';
        $settings['title'] = 'Email View';

        $this->load->view('header', $settings);
        $this->load->view('email/view', $data);
        $this->load->view('footer');
    }

    public function create($page="", $id="", $edm_action="", $edm_id="") {
        if ($this->input->post()) {
            $postData = $this->input->post();
            if (isset($postData["action"]) && $postData["action"] == "campaign" && isset($postData["campaign_id"])) {
                $market = $postData["marketName"];

                $action_post = $postData["action"];
                $campaign_id_post = $postData["campaign_id"];
                if (!isset($postData["emailname"]) || empty($postData["emailname"])) {
                    $emailname = "";
                } else {
                    $emailname = $this->db->escape(strip_tags($postData["emailname"]));
                }
                $action = $this->db->escape(strip_tags($postData["action"]));
                $campaign_id = $this->db->escape(strip_tags($postData["campaign_id"]));
                if (!isset($postData["edm_action"]) && !isset($postData["edm_id"])) {
                    $this->load->model('Edm_model');
                    $chk = $this->Edm_model->createEDM($campaign_id, $emailname, $market);
                } elseif (isset($postData["edm_action"]) && isset($postData["emailname"]) && $postData["edm_action"]=="add" && $emailname !="") {
                    foreach ($market as $key => $value) {
                        $this->load->model('Country_model');
                        $value = $this->db->escape(strip_tags($value));
                        $this->Country_model->insert_countries($campaign_id, $emailname, $value);
                    }
                }
                redirect('email/create/' . $action_post . "/" . $campaign_id_post);
            }
        }

        if (isset($page) && isset($id) && $page=="campaign" && $id != "") {
            $data['campaign_id'] = $id;
            $id = $this->db->escape(strip_tags($id));
            $this->load->model('Campaign_model');
            $campaign_details = $this->Campaign_model->getCampaignsByID($id);
            if (sizeof($campaign_details) > 0) {
                $data['campaign_details'] = $campaign_details;
                $data['action'] = $page;
                $this->load->model('Edm_model');
                $data['edm_details'] = $this->Edm_model->searchEDM($id);
                $this->load->model('Country_model');
                $data['countries'] = $this->Country_model->getCountries();
            } else {
                redirect('campaign');
            }
        } else {
            redirect('campaign');
        }

        if (isset($edm_action) &&  isset($edm_id) && $edm_action=="add" && $edm_id != "") {
            $data['edm_action'] = "add";
            $data['edm_id'] = $edm_id;
            //$this->load->model('Country_model');
            $data['countries'] = $this->Country_model->getEDMRemainingCountries($edm_id);
            $data['edm_name'] = $this->Edm_model->getEmailByID($id, $edm_id);
        }

        $this->load->helper('status');

        // Breadcrumb
        $bc = new Breadcrumb();
        $bc->addCrumbs(true, 'Dashboard', '', site_url() .'start/');
        $bc->addCrumbs(false, 'Campaign', '', site_url() . 'campaign/');
        $bc->addCrumbs(false, $campaign_details[0]['campaign_name'], 'title active', site_url() . 'email/create/campaign/' . $campaign_details[0]['id'] .'/');
        $settings['breadcrumb'] = $bc;
        $settings['sidebar'] = 'Campaign';
        $settings['title'] = $campaign_details[0]['campaign_name'] . " : " . $campaign_details[0]['category_name']  . " : ".$campaign_details[0]['vertical_name'] . " : ". $campaign_details[0]['market_name'] . " : " . $campaign_details[0]['wheels'];
        $settings['js'] = "email_create";
        $this->load->view('header', $settings);
        $this->load->view('email/create', $data);
        $this->load->view('footer');
    }

    public function template($campaign_id, $emd_id) {
        if ($emd_id=="") {
            return false;
        }
        $data['emd_id'] = $emd_id;
        $data['campaign_id'] = $campaign_id;
        $campaign_id = $this->db->escape(strip_tags($campaign_id));
        $emd_id = $this->db->escape(strip_tags($emd_id));
        $this->load->model('Edm_model');
        $edm_details = $this->Edm_model->getEmailByID($campaign_id, $emd_id);
        $data['edm_details'] = $edm_details;
        $this->load->model('Modules_model');
        $data["modules"] = $this->Modules_model->getDraggableModules();
        $data["modules_category"] = $this->Modules_model->getModulesCategory();
        $this->load->model('Template_model');
        $data['existing_modules']= $this->Template_model->getTemlateByID($campaign_id, $emd_id);
        $settings['title'] = $edm_details[0]['email_name'] . " : " . $edm_details[0]['campaign_name'] . " : " . $edm_details[0]['category_name']  . " : ".$edm_details[0]['vertical_name'] . " : ". $edm_details[0]['market_name'] . " : " . $edm_details[0]['wheels'];
        $settings['js'] = "template";
        $settings['css'] = "template";
        $campaign_name= $edm_details[0]['campaign_name'];

        // Breadcrumb
        $bc = new Breadcrumb();
        $bc->addCrumbs(true, 'Dashboard', '', site_url() .'start/');
        $bc->addCrumbs(false, 'Campaign', '', site_url() . 'campaign/');
        $bc->addCrumbs(false, $edm_details[0]['campaign_name'], '', site_url() . 'email/create/campaign/' . $data['campaign_id'] .'/');
        $bc->addCrumbs(false, 'Email', '', site_url() . 'email/viewAllEDM/');
        $bc->addCrumbs(false, $edm_details[0]['email_name'], 'title active', site_url() . 'email/create/campaign/' . $data['campaign_id'] .'/');
        $settings['breadcrumb'] = $bc;
        $settings['sidebar'] = 'Email';

        $this->load->view('header', $settings);
        $this->load->view('email/template', $data);
        $this->load->view('footer', $settings);
    }

    // Functions
    public function search_email() {
        if ($this->input->post()) {
            $postData = $this->input->post();
            $draw = $postData['draw'];
            $start = $postData['start'];
            $length = $postData['length'];

            if (!isset($postData["emailname"]) || empty($postData["emailname"])) {
                $emailname = "";
            } else {
                $emailname = strip_tags($postData["emailname"]);
            }

            if (!isset($postData["categoryName"]) || empty($postData["categoryName"])) {
                $categoryName = "";
            } else {
                $categoryName = $this->db->escape(strip_tags($postData["categoryName"]));
            }

            if (!isset($postData["vertical"]) || empty($postData["vertical"])) {
                $vertical = "";
            } else {
                $vertical = $this->db->escape(strip_tags($postData["vertical"]));
            }

            if (!isset($postData["wheel"]) || empty($postData["wheel"])) {
                $wheel = "";
            } else {
                $wheel = $this->db->escape(strip_tags($postData["wheel"]));
            }

            $this->load->model('Edm_model');
            $totalEmails = $this->Edm_model->getTotalCount();
            $result = $this->Edm_model->searchAllEmail(); //$emailname, $categoryName, $vertical, $wheel, $start, $length);

            $response = array(
                "draw" => intval($draw),
                "iTotalRecords" => $totalEmails,
                "iTotalDisplayRecords" => count($result),
                "aaData" => $result
            );
            echo json_encode($response);
        }
    }

    public function getDraggableModulesbyKey($value='') {
        $this->load->model('Modules_model');
        $data["modules"] = $this->Modules_model->getDraggableModulesbyKey($value);

        //print_r($data["modules"]);
        //$this->load->view('email/draggablemodules', $data);
    }

    public function saveTemplates() {
        $this->load->model('Template_model');
        $input = $this->input->post('data');
        $template_mods = json_decode($input, TRUE);
        $emd_id = "";
        foreach($template_mods as $item) {
            $mods = [];
            $position = $this->db->escape(strip_tags($item["position"]));
            $emd_id =  $this->db->escape(strip_tags($item["emd_id"]));
            $mod = $this->db->escape(strip_tags($item["mod"]));
            $t_id = $this->db->escape(strip_tags($item["t_id"]));
            $campaign_id = $this->db->escape(strip_tags($item["campaign_id"]));
            $this->Template_model->updateTempate($campaign_id, $emd_id, $mod, $position, $t_id);
        }
        //$this->Template_model->edms_saved_inputs($emd_id);
        $this->load->model('Edm_model');
        $this->Edm_model->updateStatus($emd_id, '1'); # 1 saved template #null for blank
    }

    public function saveTemplateVariation() {
        $this->load->model('Template_variations_model');
        $input = $this->input->post('data');
        $template_mods = $input['condition'];
        foreach($template_mods as $item) {
            if (!empty($item["t_condition_name"])) {
                $name = $this->db->escape(strip_tags($item["t_condition_name"]));
            } else {
                $name = "";
            }

            if (!empty($item["show_or_hide"])) {
                $show_or_hide = $this->db->escape(strip_tags($item["show_or_hide"]));
            } else {
                $show_or_hide = "''";
            }

            if (!empty($item["t_sending_de_variable"])) {
                $variable_name = $this->db->escape(strip_tags($item["t_sending_de_variable"]));
            } else {
                $variable_name = "''";
            }

            if (!empty($item["t_condition"])) {
                $conditions = $this->db->escape(strip_tags($item["t_condition"]));
            } else {
                $conditions = "''";
            }

            if (!empty($item["t_id"])) {
                $t_id = $this->db->escape(strip_tags($item["t_id"]));
            } else {
                $t_id = "''";
            }

            if (!empty($item["t_hide_show_value"])) {
                $t_hide_show_value = $this->db->escape(strip_tags($item["t_hide_show_value"]));
            } else {
                $t_hide_show_value = "''";
            }

            if (!empty($item["edm_id"])) {
                $edm_id = $this->db->escape(strip_tags($item["edm_id"]));
            } else {
                $edm_id = "''";
            }

            if (!empty($item["campaign_id"])) {
                $campaign_id = $this->db->escape(strip_tags($item["campaign_id"]));
            } else {
                $campaign_id = "''";
            }

            if ($name != "") {
                $id = $this->Template_variations_model->save($name, $show_or_hide, $variable_name, $conditions, $t_id, $t_hide_show_value, $edm_id, $campaign_id);
                return $id;
            } else {
                return "error";
            }
        }
    }

    public function viewLocalizedInputLinks($campaign_id, $emd_id) {
        $this->load->model('Edm_model');
        $status = $this->Edm_model->getEDMDByIDStatus($emd_id, $campaign_id);
        if ($status != "1") {
            return false;
        }
        $this->load->model('Country_model');
        $data['countries'] = $this->Country_model->getEDMCountries($emd_id, $campaign_id);
        $this->load->model('Edm_model');
        $data['edm_details'] = $this->Edm_model->getEmailByID($campaign_id, $emd_id);
        $setting['title'] = "EDM Listing";
        //$setting['js'] = "";
        $this->load->view('header');
        $this->load->view('email/viewLocalizedInputLinks', $data);
        $this->load->view('footer');
    }

    public function edit($campaign_id, $edm_id, $country, $language) {
        if (!empty($_FILES['csv_file']['name']) && $this->input->post()) {
            $postData = $this->input->post();

            if (isset($postData["modal_country_code"]) && isset($postData["modal_edm_id"]) && isset($postData["modal_campaign_id"]) && isset($postData["modal_language_code"])) {
                if (!empty($postData["modal_country_code"])) {
                    $modal_country_code = $this->db->escape(strip_tags($postData["modal_country_code"]));
                } else {
                    $modal_country_code = "NULL";
                }

                if (!empty($postData["modal_edm_id"])) {
                    $modal_edm_id = $this->db->escape(strip_tags($postData["modal_edm_id"]));
                } else {
                    $modal_edm_id = "NULL";
                }

                if (!empty($postData["modal_campaign_id"])) {
                    $modal_campaign_id = $this->db->escape(strip_tags($postData["modal_campaign_id"]));
                } else {
                    $modal_campaign_id ="NULL";
                }

                if (!empty($postData["modal_language_code"])) {
                    $modal_language_code = $this->db->escape(strip_tags($postData["modal_language_code"]));
                } else {
                    $modal_language_code = "NULL";
                }

                $this->do_csv_de_upload($modal_campaign_id, $modal_edm_id, $modal_country_code, $modal_language_code);
            } else {
                echo 'error';
            }
        }

        $this->load->model('Edm_model');
        $status = $this->Edm_model->getEDMDByIDStatus($edm_id, $campaign_id);
        if ($status != "1") {
            return false;
        }

        $view_data['language_code'] = $language;
        $view_data['country_code'] = $country;
        $edm_details = $this->Edm_model->getEmailByID($campaign_id, $edm_id);
        $view_data['edm_details'] =$edm_details;
        $this->load->model('Edms_saved_inputs_model');
        $this->load->model('Edms_module_elements_model');
        $this->load->model('Template_model');
        $html_str = "";
        $modules = $this->Template_model->getTemlateByID($campaign_id, $edm_id);
        //var_dump($modules); die;

        foreach ($modules as $key => $value) {
            $section_module_key = $value['t_id'];
            $text =  $value['module_html'];
            $text = str_replace("__dynamicid__", $section_module_key. "_", $text);
            $elements = $this->Edms_module_elements_model->getModuleElementsById($value['module_id']);
            foreach ($elements as $ele => $ele_value) {
               $section_module = $section_module_key. "_" .$ele_value['elements'];
               $data = $this->Edms_saved_inputs_model->getSavedInputValuesByKey($section_module, $country, $language, $edm_id, $campaign_id);
               if (count($data) > 0) {
                   $title = $data[0]['title'];
                   $alias = $data[0]['alias'];
                   $link = $data[0]['link'];
                   $href = $data[0]['href'];

                   $text = str_replace($section_module. "_" ."alias", $alias, $text);
                   $text = str_replace($section_module. "_" ."title", $title, $text);
                   $text = str_replace($section_module. "_" ."link", $link, $text);
                   $text = str_replace($section_module. "_" ."href", $href, $text);
                }
            }
            $html_str = $html_str .$text;
        }

        $view_data['html_str'] = $html_str;
        $settings['title'] = $edm_details[0]['email_name'] . " : " . $edm_details[0]['campaign_name'] . " : " . $edm_details[0]['category_name']  . " : ".$edm_details[0]['vertical_name'] . " : ". $edm_details[0]['market_name'] . " : " . $edm_details[0]['wheels'];
        $settings['js'] = "viewlocalizedInputBriefInput";

        // Breadcrumb
        $bc = new Breadcrumb();
        $bc->addCrumbs(true, 'Dashboard', '', site_url() .'start/');
        $bc->addCrumbs(false, 'Campaign', '', site_url() . 'campaign/');
        $bc->addCrumbs(false, $edm_details[0]['campaign_name'], '', site_url() . 'email/create/campaign/' . $edm_details[0]['campaign_id'] .'/');
        $bc->addCrumbs(false, 'Email', '', site_url() . 'email/viewAllEDM/');
        $bc->addCrumbs(false, $edm_details[0]['email_name'], 'title active', site_url() . 'email/create/campaign/' . $edm_details[0]['campaign_id'] .'/');
        $settings['breadcrumb'] = $bc;
        $settings['sidebar'] = 'Email';
        $this->load->view('header', $settings);
        $this->load->view('email/edit', $view_data);
        $this->load->view('footer');
    }

    public function getSavedInputValuesByKey($section_module, $country, $language, $edm_id, $campaign_id) {
        $view_data = [];
        $this->load->model('Edms_saved_inputs_model');
        $data = $this->Edms_saved_inputs_model->getSavedInputValuesByKey($section_module, $country, $language, $edm_id, $campaign_id);
        $template_id  = $data[0]['template_id'];
        $this->load->model('Template_variations_model');
        $variation = $this->Template_variations_model->getByTemplate_id($campaign_id, $edm_id, $template_id);
        $view_data['data'] = $data;
        $view_data['variation'] = $variation;
        echo json_encode($view_data);
    }

    public function getTemplateVariationByTemplateId($campaign_id, $edm_id, $id) {
        $this->load->model('Template_variations_model');
        $data = $this->Template_variations_model->getByTemplate_id($campaign_id, $edm_id, $id);
        echo json_encode($data);
    }

    public function getTemplateVariationByVariationId($value, $country_code, $language_code, $edm_id) {
        $this->load->model('Edms_saved_inputs_model');
        $data = $this->Edms_saved_inputs_model->getByVaration_id($value, $country_code, $language_code, $edm_id);
        echo json_encode($data);
    }

    public function getDraggedModuleTemplateId() {
        if ($this->input->post()) {
            $input = $this->input->post('data');
            $item = json_decode($input, TRUE);
            $this->load->model('Template_model');
            $edm_id = $this->db->escape(strip_tags($item[0]["emd_id"]));
            $mod = $this->db->escape(strip_tags($item[0]["mod"]));
            $campaign_id = $this->db->escape(strip_tags($item[0]["campaign_id"]));
            $data['t_id'] =  $this->Template_model->saveTempate($campaign_id, $edm_id, $mod, '0', '0');
            echo json_encode([$data]);
        }
    }

    public function deleteById($id) {
        //echo $id;
        $this->load->model('Template_model');
        $this->Template_model->deleteById($id);
        $this->load->model('Template_variations_model');
        $this->Template_variations_model->deleteById($id);
        return 1;
    }

    public function json_api_put_data2($campaign_id,$edm_id)
    {
        $this->load->model('Edms_saved_inputs_model');
        $data = $this->Edms_saved_inputs_model->getSavedInputValues($campaign_id,$edm_id );
        $aaa = array();
        foreach ($data as $key => $value) {
            $item = [];
            
            $items["country_code"] = $value['country_code'];
            $items["language_code"] = $value['language_code'];
            $items["variation_id"] = $value['variation_id'];
            $items["edm_id"] = $value['edm_id'];
            $items["campaign_id"] = $value['campaign_id'];
            $module_type = $value['editable_type'];
            $key_prefix = $value['module_key'] ."_". $value['key_name'];
            if ($module_type == "cta") {
                $items["key_name"] = $key_prefix."_alias";
                $items["value"] = $value['alias']; $aaa[] =  $items;
                $items["key_name"] = $key_prefix."_href";
                $items["value"] = $value['href']; $aaa[] =  $items;
                $items["key_name"] = $key_prefix."_title";
                $items["value"] = $value['title']; $aaa[] =  $items;
            }
            elseif ($module_type == "image_withoutlink") {
                $items["key_name"] = $key_prefix."_alias";
                $items["value"] = $value['alias']; $aaa[] =  $items;
                $items["key_name"] = $key_prefix."_href";
                $items["value"] = $value['href']; $aaa[] =  $items;
                $items["key_name"] = $key_prefix."_title";
                $items["value"] = $value['title']; $aaa[] =  $items;
            }
            elseif ($module_type == "image_withlink") {
                $items["key_name"] = $key_prefix."_links";
                $items["value"] = $value['link']; $aaa[] =  $items;
                $items["key_name"] = $key_prefix."_alias";
                $items["value"] = $value['alias']; $aaa[] =  $items;
                $items["key_name"] = $key_prefix."_href";
                $items["value"] = $value['href']; $aaa[] =  $items;
                $items["key_name"] = $key_prefix."_title";
                $items["value"] = $value['title']; $aaa[] =  $items;
            }
            elseif ($module_type == "paragraph") {
                $items["key_name"] = $key_prefix."_title";
                $items["value"] = $value['title']; $aaa[] =  $items;
            }
            elseif ($module_type == "heading") {
                $items["key_name"] = $key_prefix."_title";
                $items["value"] = $value['title']; $aaa[] =  $items;
            }   
        }
        $marks = array( 'items'=> $aaa);
        return json_encode($marks);
    }
    
    
    public function export_translation_de($campaign_id,$edm_id)
    {
        $file_name = 'Translation_DE_'.date('Ymd').'.csv';
        header("Content-Description: File Transfer");
        header("Content-Disposition: attachment; filename=$file_name");
        header("Content-Type: application/csv;");
        $file = fopen('php://output', 'w');
        $rows = json_decode($this->json_api_put_data2($campaign_id,$edm_id));
        $rows = $rows->items;
        $header = array("campaign_id","edm_id","key_name","country_code","language_code","variation_id","value");
        fputcsv($file, $header);

        foreach ($rows as $key => $row) {
            $arr = [];
            $arr[] = $row->campaign_id;
            $arr[] = $row->edm_id;
            $arr[] = $row->key_name;
            $arr[] = $row->country_code;
            $arr[] = $row->language_code;
            $arr[] = $row->variation_id;
            $arr[] = $row->value;

            fputcsv($file, $arr);
        }
        fclose($file);
    }

    public function delete_variation($id='', $t_id='') {
        $id = str_replace('remove_variation_', "", $id);
        $this->load->model('Template_variations_model');
        $rows = $this->Template_variations_model->deleteifnotone($id, $t_id);
        echo $rows;
    }

    public function apicalls($value) {
        $url ="https://mcq-d6ssppp0-v0w04t7bqbnf7r8.auth.marketingcloudapis.com/v2/token";
        // set post fields
        $post = [
            "grant_type" => "client_credentials",
            "client_id" => "b1lw680ysudeu3wtlwckyc0v",
            "client_secret" => "eMBc9vSnPlsNO0EMN3UUYQfZ"
        ];
        $result = $this->salesforceAPI($url, $post, 0, 1, 'POST');
        $decode_result = json_decode($result);
        $token = $decode_result->access_token;
        $expire = $decode_result->expires_in;

        $data_url = 'https://mcq-d6ssppp0-v0w04t7bqbnf7r8.rest.marketingcloudapis.com/data/v1/async/dataextensions/key:automation_translation_de_external_key/rows';

        $json_input_data = $this->json_api_put_data($value);

        $data_result = $this->salesforceAPI($data_url, $json_input_data, 1, $token, 'PUT');

        echo $data_result;
    }

    function salesforceAPI($url, $fields_string, $flg, $token, $method) {
        $ch = curl_init();
        if ($flg == 1) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'Authorization: Bearer ' . $token));
            curl_setopt($ch, CURLOPT_HEADER, 0);
        }
        curl_setopt($ch, CURLOPT_URL, $url);
        //curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        $result = curl_exec($ch);
        $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);

        curl_close($ch);

        return $result;
    }

    public function json_api_put_data($value = '') {
        $this->load->model('Edms_saved_inputs_model');
        $data = $this->Edms_saved_inputs_model->getSavedInputValuesByEdmID($value);
        $aaa = array();
        foreach ($data as $key => $value) {
            $item = [];
            $items["key_name"] = $value['key_name'];
            $items["country_code"] = $value['country_code'];
            $items["language_code"] = $value['language_code'];
            $items["variation_id"] = $value['variation_id'];
            $items["alias"] = $value['alias'];
            $items["href"] = $value['href'];
            $items["start_ampscript"] = $value['start_ampscript'];
            $items["end_ampscript"] = $value['end_ampscript'];
            $items["link"] = $value['link'];
            $items["title"] = $value['title'];
            $items["edm_id"] = $value['edm_id'];
            $aaa[] =  $items;
        }
        $marks = array('items'=> $aaa);
        return json_encode($marks);
    }

    public function upload_to_sfmc($emd_id) {
        $this->load->model('Edm_model');
        $this->load->model('Edms_saved_inputs_model');
        $this->load->model('Template_model');
        $data['edm_details'] =$this->Edm_model->getEmailByID($emd_id);
        $data['keys_count'] = $this->Edms_saved_inputs_model->getSavedInputValuesCountByEdmID($emd_id)[0]['count'];
        $data['component_count'] = $this->Template_model->getComponentCountByEdmID($emd_id)[0]['count'];
        $this->load->view('header');
        $this->load->view('email/viewUploadToSfmc', $data);
        $this->load->view('footer');
    }

    public function getVariationById($id) {
        $this->load->model('Template_variations_model');
        $data = $this->Template_variations_model->getById($id);
    }

    public function do_upload($country_code, $language_code, $section_key, $variation_id, $edm_id, $campaign_id) {
        $is_upload_sfmc = True;
        if (!empty($_FILES["file"]['name'])) {
            $config['upload_path']="./resources/uploads/";
            $config['allowed_types']='gif|jpg|png|jpeg';
            $this->load->library('upload', $config);

            if ($this->upload->do_upload("file")) {
                $data_save = array();
                $data =  $this->upload->data();
                if ($is_upload_sfmc) {
                    $this->load->model('Asset_model');
                    $file_ext = ltrim($data['file_ext'], '.');
                    //echo json_encode($data);
                    $asset_type_id = $this->Asset_model->getAssestIDByFileExt($file_ext);
                    $image_base64 = base64_encode(file_get_contents($_FILES["file"]["tmp_name"]));
                    $image_name ="xyz";
                    $sfmc_uploaded_image =  $this->apicalls_uploadimage($image_base64, $image_name, $file_ext, $asset_type_id, 2089156);
                    $url =  (array)($sfmc_uploaded_image->fileProperties);

                    $this->load->model('Edms_saved_inputs_model');
                    $data_save['key_id'] = $this->Edms_saved_inputs_model->get_id($country_code, $language_code, $section_key, $variation_id, $edm_id, $campaign_id);
                    $data_save['file_name'] = $data['file_name'];
                    $data_save['file_type'] = $data['file_type'];
                    $data_save['file_path'] = $data['file_path'];
                    $data_save['full_path'] = $data['full_path'];
                    $data_save['raw_name'] = $data['raw_name'];
                    $data_save['orig_name'] = $data['orig_name'];
                    $data_save['client_name'] = $data['client_name'];
                    $data_save['file_ext'] = $data['file_ext'];
                    $data_save['file_size'] = $data['file_size'];
                    $data_save['image_width'] = $data['image_width'];
                    $data_save['image_height'] = $data['image_height'];
                    $data_save['image_type'] = $data['image_type'];
                    //$data_save['sfmc_CustomerKey'] =
                    $data_save['sfmc_publishedURL'] =$url['publishedURL'];
                    $data_save['local_url'] = site_url().'resources/uploads/'.$data['raw_name'].$data['file_ext'];

                    $this->Asset_model->insert($data_save);
                }

                return "'". site_url().'resources/uploads/'.$data['raw_name'].$data['file_ext']."'";
            } else {
                $this->upload->display_errors();
                return False;
            }
        } else {
            return False;
        }
    }

    function get_string_between($string, $start, $end) {
        $string = ' ' . $string;
        $ini = strpos($string, $start);
        if ($ini == 0) return '';
        $ini += strlen($start);
        $len = strpos($string, $end, $ini) - $ini;
        return substr($string, $ini, $len);
    }

    public function edmsSavedInputValues() {
        $postData = $this->input->post();

        if (!isset($postData["section_key"]) || empty($postData["section_key"])) {
            $section_key = "NULL";
        } else {
            $section_key = $this->db->escape(strip_tags($postData["section_key"]));
        }

        if (!isset($postData["section_module_type"]) || empty($postData["section_module_type"])) {
            $module_type = "NULL";
        } else {
            $module_type = $this->db->escape(strip_tags($postData["section_module_type"]));
        }

        if (!isset($postData["hidden_country"]) || empty($postData["hidden_country"])) {
            $country_code = "NULL";
        } else {
            $country_code = $this->db->escape(strip_tags($postData["hidden_country"]));
        }

        if (!isset($postData["hidden_language"]) || empty($postData["hidden_language"])) {
            $language_code = "NULL";
        } else {
            $language_code = $this->db->escape(strip_tags($postData["hidden_language"]));
        }

        if (!isset($postData["variation_id"]) || empty($postData["variation_id"])) {
            $variation_id = "NULL";
        } else {
            $variation_id = $this->db->escape(strip_tags($postData["variation_id"]));
        }

        $variation_id = str_replace("tab_", "", $variation_id);
        if (!isset($postData["editable_section_start_ampscript"]) || empty($postData["editable_section_start_ampscript"])) {
            $start_ampscript = "NULL";
        } else {
            $start_ampscript = $this->db->escape(strip_tags($postData["editable_section_start_ampscript"]));
        }

        if (!isset($postData["editable_section_title"]) || empty($postData["editable_section_title"])) {
            $title = "NULL";
        } else {
            $title = $this->db->escape(strip_tags($postData["editable_section_title"]));
        }

        if (!isset($postData["editable_section_redirect_link"]) || empty($postData["editable_section_redirect_link"])) {
            $link = "NULL";
        } else {
            $link = $this->db->escape(strip_tags($postData["editable_section_redirect_link"]));
        }

        if (!isset($postData["editable_section_alias"]) || empty($postData["editable_section_alias"])) {
            $alias = "NULL";
        } else {
            $alias = $this->db->escape(strip_tags($postData["editable_section_alias"]));
        }

        if (!isset($postData["editable_section_end_ampscript"]) || empty($postData["editable_section_end_ampscript"])) {
            $end_ampscript = "NULL";
        } else {
            $end_ampscript = $this->db->escape(strip_tags($postData["editable_section_end_ampscript"]));
        }

        if (!isset($postData["hidden_emd_id"]) || empty($postData["hidden_emd_id"])) {
            $edm_id = "NULL";
        } else {
            $edm_id = $this->db->escape(strip_tags($postData["hidden_emd_id"]));
        }

        if (!isset($postData["hidden_campaign_id"]) || empty($postData["hidden_campaign_id"])) {
            $campaign_id = "NULL";
        } else {
            $campaign_id = $this->db->escape(strip_tags($postData["hidden_campaign_id"]));
        }

        $this->load->model('Edms_saved_inputs_model');

        if (! empty($_FILES["file"]['name'])) {
            $imagesrc = $this->do_upload($country_code, $language_code, $section_key, $variation_id, $edm_id, $campaign_id);
        } elseif (isset($postData["editable_section_imagesrc"]) && !empty($postData["editable_section_imagesrc"]))  {
            $imagesrc = $this->db->escape(strip_tags($postData["editable_section_imagesrc"]));
            $key_id = $this->Edms_saved_inputs_model->get_id($country_code, $language_code, $section_key, $variation_id, $edm_id, $campaign_id);
            $this->load->model('Asset_model');
            $this->Asset_model->updateNotUse($key_id, $imagesrc);
            //echo $imagesrc; die;
        } else {
            $imagesrc = "NULL";
        }
        //$this->load->model('Edms_saved_inputs_model');
        $this->Edms_saved_inputs_model->setSavedInputValuesByKey($start_ampscript, $imagesrc, $title, $link, $alias, $end_ampscript, $country_code, $language_code, $section_key, $variation_id, $edm_id, $campaign_id);

        $data["key_name"] =  str_replace("'", "", $section_key);
        $data["editable_type"] = str_replace("'", "", $module_type);
        $data["title"] = str_replace("'", "", $title);
        $data["href"] = str_replace("'", "", $imagesrc);
        $data["editable_type"] = str_replace("'", "", $module_type);
        echo json_encode([$data]);
    }

    public function apicalls_uploadimage($image_base64, $image_name, $asset_type_name, $asset_type_id, $category_id = 2089156) {
        $url ="https://mcq-d6ssppp0-v0w04t7bqbnf7r8.auth.marketingcloudapis.com/v2/token";
        // set post fields
        $post = [
            "grant_type" => "client_credentials",
            "client_id" => "b1lw680ysudeu3wtlwckyc0v",
            "client_secret" => "eMBc9vSnPlsNO0EMN3UUYQfZ"
        ];
        $result = $this->salesforceAPI($url, $post, 0, 1, 'POST');
        $decode_result = json_decode($result);
        $token = $decode_result->access_token;
        $expire = $decode_result->expires_in;

        $data_url = 'https://mcq-d6ssppp0-v0w04t7bqbnf7r8.rest.marketingcloudapis.com/asset/v1/content/assets';

        $items = [];
        $now = DateTime::createFromFormat('U.u', microtime(true));
        $items["Name"] = "api_".$now->format("m_d_Y_H_i_s_u");;
        $items["CustomerKey"] = "api_".$now->format("m_d_Y_H_i_s_u");;
        $items["assetType"] = array("name"=>$asset_type_name, "id"=> $asset_type_id);
        $items["category"] = array("id" => $category_id);
        $items["file"] = $image_base64;
        $json_input_data = json_encode($items);

        $json_data =  $this->salesforceAPI($data_url, $json_input_data, 1, $token, 'POST');
        return json_decode($json_data);
    }

    public function desktopPreview($campaign_id, $edm_id, $country, $language) {
        $this->load->model('Edm_model');
        $status = $this->Edm_model->getEDMDByIDStatus($edm_id, $campaign_id);
        if ($status != "1") {
            return false;
        }

        $this->load->model('Edms_saved_inputs_model');
        $this->load->model('Edms_module_elements_model');
        $this->load->model('Template_model');
        $html_str = "";
        $modules = $this->Template_model->getTemlateByID($campaign_id, $edm_id);
        //var_dump($modules); die;
        foreach ($modules as $key => $value) {
            $section_module_key =  $value['t_id'];
            $text =  $value['module_html'];
            $text = str_replace("__dynamicid__", $section_module_key. "_", $text);
            $elements = $this->Edms_module_elements_model->getModuleElementsById($value['module_id']);
            foreach ($elements as $ele => $ele_value) {
                $section_module = $section_module_key. "_" .$ele_value['elements'];
                $data = $this->Edms_saved_inputs_model->getSavedInputValuesByKey($section_module, $country, $language, $edm_id, $campaign_id);
                if (count($data) > 0) {
                    $title = $data[0]['title'];
                    $alias = $data[0]['alias'];
                    $link = $data[0]['link'];
                    $href = $data[0]['href'];

                    if ($ele_value['elements'] != "code_block") {
                        $text = str_replace($section_module. "_" ."alias", $alias, $text);
                        $text = str_replace($section_module. "_" ."title", $title, $text);
                        $text = str_replace($section_module. "_" ."link", $link, $text);
                        $text = str_replace($section_module. "_" ."href", $href, $text);
                    } else {
                        $text = "<p>".$data[0]['title']."</p>";
                    }
                }
            }

            $html_str = $html_str .$text;
        }

        $this->load->model('Html_email_template_model');
        $email_template = $this->Html_email_template_model->getByName('grab_nba');
        echo $email_template['head_tag'];
        echo $email_template['body_start_tag'];
        echo $email_template['body_content'];
        echo $html_str;
        echo $email_template['body_end_tag'];
    }

    public function preview($campaign_id, $edm_id, $country, $language) {
        $view_data['language_code'] = $language;
        $view_data['country_code'] = $country;
        $this->load->model('Edm_model');
        $edm_details = $this->Edm_model->getEmailByID($campaign_id, $edm_id);
        $setting['title'] = $edm_details[0]['email_name'] . " : " . $edm_details[0]['campaign_name'] . " : " . $edm_details[0]['category_name']  . " : ".$edm_details[0]['vertical_name'] . " : ". $edm_details[0]['market_name'] . " : " . $edm_details[0]['wheels'];
        $setting['js'] = "generatePreview";
        $data['preview_url'] = 'email/desktopPreview/'.$campaign_id."/".$edm_id."/".$country."/".$language;
        $setting['breadcrumb1'] = array(
            "Dashboard" => site_url(),
            " ".$edm_details[0]['campaign_name']." " => site_url()."edm/create/campaign/".$campaign_id,
            $edm_details[0]['email_name'] =>  site_url()."edm/edit/".$campaign_id."/".$edm_id."/".$country."/".$language,
            "preview"=>""
        );
        $this->load->view('header', $setting);
        $this->load->view('email/preview', $data);
        $this->load->view('footer', $setting);
    }

    public function preview_download($campaign_id, $edm_id, $country, $language) {
        $file_name = 'preview_'.$country.$language.date('Ymd').'.html';
        header("Content-Description: File Transfer");
        header("Content-Disposition: attachment; filename=$file_name");
        header('Content-type: text/html');
        $this->desktopPreview($campaign_id, $edm_id, $country, $language);
    }

    public function craete_thumnail() {
        //website url
        $siteURL = "http://www.codexworld.com/";

        //call Google PageSpeed Insights API
        $googlePagespeedData = file_get_contents("https://www.googleapis.com/pagespeedonline/v2/runPagespeed?url=$siteURL&screenshot=true");

        //decode json data
        $googlePagespeedData = json_decode($googlePagespeedData, true);

        //screenshot data
        $screenshot = $googlePagespeedData['screenshot']['data'];
        $screenshot = str_replace(array('_', '-'), array('/', '+'), $screenshot);

        //display screenshot image
        echo "<img src=\"data:image/jpeg;base64, ".$screenshot."\" />";
    }

    public function export_input_file($campaign_id,$edm_id,$country,$language)
    {
        $file_name = 'Translation_DE_Import_File'.date('Ymd').'.csv';
        header("Content-Description: File Transfer");
        header("Content-Disposition: attachment; filename=$file_name");
        header("Content-Type: application/csv;");
        $file = fopen('php://output', 'w');
        
        $header = array("ID", "Module - Variation - Input",  "Value");
        fputcsv($file, $header);
        
        $this->load->model('Template_model');
        $this->load->model('Edms_saved_inputs_model');
        $this->load->model('Edms_module_elements_model');
        $modules = $this->Template_model->getTemlatewithvariation($campaign_id,$edm_id);
        //var_dump($modules); die;
        foreach ($modules as $key => $value) {
                   $variation_id = $value['variation_id'];
                   $section_module_key =  $value['t_id'];
                   $text =  $value['module_html'] ;
                   $text = str_replace("__dynamicid__", $section_module_key. "_", $text);
                   $elements = $this->Edms_module_elements_model->getModuleElementsById($value['module_id']);
                   foreach ($elements as $ele => $ele_value)
                   {
                       $section_module = $section_module_key. "_" .$ele_value['elements'];
                       $data = $this->Edms_saved_inputs_model->getSavedInputValuesByVariation($variation_id,$section_module,$country, $language,$edm_id,$campaign_id);
                       if (count($data) > 0)
                       {
                          // $csv_array = array();
                           $title = $data[0]['title'];
                           $alias = $data[0]['alias'];
                           $link = $data[0]['link'];
                           $href = $data[0]['href'];
                           $key_id = $data[0]['id'];
                           
                           $module_name = $value['module_name'] ." - ". $value['variation_name']." - ". $ele_value['elements'];
                           $editable_type = $data[0]['editable_type'];
                           if ($editable_type == "paragraph")
                           {    fputcsv($file, array($key_id."_".'title', $module_name,$title));
                           }elseif ( $editable_type == 'image_withoutlink' ) {
                            fputcsv($file, array($key_id."_".'href',$module_name,$href));
                            fputcsv($file, array($key_id."_".'title',$module_name,$title));
                            fputcsv($file, array($key_id."_".'alias',$module_name,$alias));
                           }elseif ($editable_type == 'heading' ) {
                            fputcsv($file, array($key_id."_".'title',$module_name,$title));
                           }elseif ($editable_type == "cta" ) {
                            fputcsv($file, array($key_id."_".'href',$module_name,$href));
                            fputcsv($file, array($key_id."_".'title',$module_name,$title));
                            fputcsv($file, array($key_id."_".'alias',$module_name,$alias));
                           }
                           elseif ($editable_type == 'image_withlink' ) {
                            fputcsv($file, array($key_id."_".'href',$module_name,$href));
                            fputcsv($file, array($key_id."_".'title',$module_name,$title));
                            fputcsv($file, array($key_id."_".'alias',$module_name,$alias));
                            fputcsv($file, array($key_id."_".'link',$module_name,$link));
                           }
                        }
                    }
                }
           
        fclose($file);
    }

   public function do_csv_de_upload($campaign_id,$edm_id,$country_code,$language_code) {
        $this->load->helper('status');
        $config['upload_path'] = "./resources/uploads/de_upload";
        $config['allowed_types'] = 'csv';
        $this->load->library('upload',$config);
        if($this->upload->do_upload('csv_file')) {
            $this->load->model('Edms_saved_inputs_model');
            $data = $this->upload->data();
            $file_path = $data['full_path'];
            $file = fopen($file_path, 'r');
            $loop_count = 0;
            while (($line = fgetcsv($file)) !== FALSE) {
                if ($loop_count !=0)
                {
                     $key_value = $line[2];
                     
                     $key_str = $line[0];
                     $key_str = explode("_", $key_str);
                     $key_id = $key_str[0];
                     $col_name = $key_str[1];
                     //$col_name = edm_input_col_name($col_name);
                     if (!empty($key_value)) {$key_value = $this->db->escape(strip_tags($key_value));}else{$key_value = "NULL";};
                    $error = $this->Edms_saved_inputs_model->file_upload_update($campaign_id,$edm_id,$country_code,$language_code, $key_id, $col_name, $key_value);
                     echo $error;
                 }
                 $loop_count ++;
            }
            fclose($file);
            
        }
        else
        {
             echo $this->upload->display_errors();
             
        }
        
    }

    public function get_ampscript_with_content_block($campaign_id, $edm_id) {
        $this->load->model('Template_model');
        echo '%%[';
        echo '</br>';
        echo 'SET @sending_de = "sending_de";';
        echo '</br>';
        echo 'SET @translation_de = "automation_translation_de";';
        echo '</br>';
        echo 'SET @config_de = "config_de";';
        echo '</br>';
        echo 'SET @edm_id = "'.$edm_id.'";';
        echo '</br>';
        echo 'SET @country_code = AttributeValue("country_id");';
        echo '</br>';
        echo 'SET @language_code = AttributeValue("langauage_id");';
        echo '</br>';
        echo ']%%';
        echo '</br>';
        echo '</br>';
        echo '</br>';
        $key_prefix = "";
        $module_variation = "";
        $this->load->model('Template_variations_model');
        $modules = $this->Template_model->getTemlateByID($campaign_id, $edm_id);
        foreach ($modules as $key => $value) {
           $text =  $value['content_block'];
           echo $value['start_ampscript'];
           $t_id =  $value['id'];
           echo '%%[ </br> SET @t_id = "'. $t_id . '"';
           echo '</br>';
           $varations = $this->Template_variations_model->getByTemplate_id($campaign_id, $edm_id, $t_id);
           foreach ($varations as $v_key => $v_value) {
                if (strtolower($v_value['name']) == 'default') {
                    echo 'SET @module_variation = "'. $v_value['id'] . '" ';
                    echo '</br>';
                } else {
                    echo 'if AttributeValue("'.  $v_value['variable_name']. '") ' . $v_value['conditions'] . ' "' . $v_value['hide_show_value'] . '" then ';
                    echo 'SET @module_variation = "'. $v_value['id'] . '" ';
                    echo  'Endif ';
                    echo '</br>';
                }
            }
            echo "]%%";
            echo('</br>');
            echo  '%%=ContentBlockbyKey("'.$text.'")=%%';

            echo $value['end_ampscript'];
            echo('</br> </br>');
        }
    }

    public function get_ampscript($campaign_id, $edm_id) {
        $this->load->model('Edm_model');
        $campaign_id = $this->db->escape(strip_tags($campaign_id));
        $edm_id = $this->db->escape(strip_tags($edm_id));
        $edm_details = $this->Edm_model->getEmailByID($campaign_id, $edm_id);

        $this->load->model('Template_model');
        echo '%%[';
        echo '</br>';
        echo 'SET @sending_de = "sending_de";';
        echo '</br>';
        echo 'SET @translation_de = "automation_translation_de";';
        echo '</br>';
        echo 'SET @config_de = "config_de";';
        echo '</br>';
        echo 'SET @edm_id = '.$edm_id.';';
        echo '</br>';
        echo 'SET @country_code = AttributeValue("country_id");';
        echo '</br>';
        echo 'SET @language_code = AttributeValue("langauage_id");';
        echo '</br>';
        echo ']%%';
        echo '</br>';
        echo '</br>';
        echo '</br>';
        $key_prefix = "";
        $module_variation = "";
        $this->load->model('Template_variations_model');
        $modules = $this->Template_model->getTemlateByID($campaign_id, $edm_id);
        foreach ($modules as $key => $value) {
            $text =  $value['content_block'];
            echo $value['start_ampscript'];
            $t_id =  $value['id'];
            echo '%%[ </br> SET @t_id = "'. $t_id . '"';
            echo '</br>';
            $varations = $this->Template_variations_model->getByTemplate_id($campaign_id, $edm_id, $t_id);
            foreach ($varations as $v_key => $v_value) {
                if (strtolower($v_value['name']) == 'default') {
                    echo 'SET @module_variation = "' . $v_value['id'] . '" ';
                    echo '</br>';
                } else {
                    echo 'if AttributeValue("' .  $v_value['variable_name']. '") ' . $v_value['conditions'] . ' "' . $v_value['hide_show_value'] . '" then ';
                    echo 'SET @module_variation = "' . $v_value['id'] . '" ';
                    echo  'Endif ';
                    echo '</br>';
                }
            }
            echo "]%%";
            echo('</br>');
            echo '%%=ContentBlockbyKey("' . $text . '")=%%';

            echo $value['end_ampscript'];
            echo('</br> </br>');
        }
    }

    public function get_ampscript2($campaign_id,$edm_id)
    {
        $file_name = 'ampscript_'.$campaign_id.$edm_id.date('Ymd').'.html';
        header("Content-Description: File Transfer");
        header("Content-Disposition: attachment; filename=$file_name");
        header('Content-type: text/html');
        
        $this->load->model('Edm_model');
        $this->load->model('Html_email_template_model');
        $this->load->model('Template_model');

        $campaign_id = $this->db->escape(strip_tags($campaign_id));
        $edm_id = $this->db->escape(strip_tags($edm_id));
        $edm_details = $this->Edm_model->getEDMDByID($campaign_id,$edm_id);
        $email_template = $this->Html_email_template_model->getByName('grab_nba');
        
        echo '%%[';
        echo '</br>';
        echo 'SET @sending_de = "sending_de";';
        echo '</br>';
        echo 'SET @translation_de = "automation_translation_de2";';
        echo '</br>';
        echo 'SET @config_de = "config_de";';
        echo '</br>';
        echo 'SET @edm_id = '.$edm_id.';';
        echo '</br>';
        echo 'SET @campaign_id = '.$campaign_id.';';
        echo '</br>';
        echo 'SET @country_code = Uppercase(AttributeValue("country_code"));';
        echo '</br>';
        echo 'SET @language_code = AttributeValue("language_code");';
        echo '</br>';
        echo ']%%';
        echo '</br>';
        echo '</br>';
        echo '</br>';

        echo '<pre><xmp>'; 
        echo $email_template['head_tag'];
        echo $email_template['body_start_tag'];
        echo '</pre></xmp>'; 

        $key_prefix = "";
        $module_variation = "";
        $this->load->model('Edms_module_elements_model');
        $this->load->model('Template_variations_model');
        $modules = $this->Template_model->getTemlateByID($campaign_id,$edm_id);
        $module_counter = 1;
        foreach ($modules as $key => $value) {
           //$text =  $value['content_block'] ;
           //echo $value['start_ampscript'];
           $t_id =  $value['id'] ;
           $module_id = $value['module_id'];
           $key_name = $value['module_key'];
           if ($key_name == "code_block") {
                $text = "";
           }
           else
           {
              // $code_block_bool = $key_name=="code_block"?true:false;
               #echo '%%[ </br> SET @t_id = "'. $t_id . '"';
               echo '</br>';
               echo('<!-- start '.$key_name. '  : module number - '. $module_counter.' -->');
               $module_counter ++;
               echo '</br>';
               echo '%%[';
               $varations = $this->Template_variations_model->getByTemplate_id($campaign_id,$edm_id,$t_id);
               foreach ($varations as $v_key => $v_value) {
                    
                    echo 'SET @module_visibility = "true";';
                    echo '</br>';
                    if (strtolower($v_value['name']) == 'default' ) {
                        #echo 'SET @module_visibility = "true";';
                        echo 'SET @module_variation = "'. $v_value['id'] . '" ';
                        echo '</br>';
                    }
                    else
                    {
                        echo 'if AttributeValue("'.  $v_value['variable_name']. '") ' . $v_value['conditions'] . ' "' . $v_value['hide_show_value'] . '" then ' ;
                        echo '</br>';
                        #echo 'SET @module_visibility = "true";';
                        echo 'SET @module_variation = "'. $v_value['id'] . '" ';
                        echo  'Endif ';
                        echo '</br>';
                    }
                }
                echo "]%%";
                echo('</br>');
                echo('</br>');
                echo '%%[if  @module_visibility == "true" then ';
                echo '</br>';
                //echo  '%%=ContentBlockbyKey("'.$text.'")=%%' ;
                $text =  $value['module_html'] ;
                $text = str_replace("__dynamicid__", $key_name."_".$t_id."_", $text); 
                // key_name = campaign_id + edm_id + template_id + variation_id + suffix
                $module_keys = $this->Edms_module_elements_model->getModuleElementsById($module_id);
                foreach ($module_keys as $mkey => $mvalue) {
                    $module_type = $mvalue['editable_type'];
                    
                    $module_key_name = $key_name."_".$t_id."_".$mvalue["elements"];
                    $module_key_name_title =   "SET @".$module_key_name."_title = LOOKUP(@translation_de, 'value', 'key_name','".$module_key_name."_title','campaign_id', @campaign_id,'edm_id', @edm_id, 'variation_id',@module_variation, 'country_code',@country_code, 'language_code', @language_code)";
                    $module_key_name_alias =  "SET @".$module_key_name."_alias = LOOKUP(@translation_de, 'value', 'key_name','".$module_key_name."_alias','campaign_id', @campaign_id,'edm_id', @edm_id, 'variation_id',@module_variation, 'country_code',@country_code, 'language_code', @language_code)";
                    $module_key_name_link =  "SET @".$module_key_name."_link = LOOKUP(@translation_de, 'value', 'key_name','".$module_key_name."_link','campaign_id', @campaign_id,'edm_id', @edm_id, 'variation_id',@module_variation, 'country_code',@country_code, 'language_code', @language_code)";    
                    $module_key_name_href =  "SET @".$module_key_name."_href = LOOKUP(@translation_de, 'value', 'key_name','".$module_key_name."_href','campaign_id', @campaign_id,'edm_id', @edm_id, 'variation_id',@module_variation, 'country_code',@country_code, 'language_code', @language_code)";
                    $text = str_replace($module_key_name. "_" ."alias","%%=v(@".$module_key_name. "_" ."alias".")=%%", $text);
                    $text = str_replace($module_key_name. "_" ."title","%%=v(@".$module_key_name. "_" ."title".")=%%", $text);
                    $text = str_replace($module_key_name. "_" ."link","%%=v(@".$module_key_name. "_" ."link".")=%%", $text);
                    $text = str_replace($module_key_name. "_" ."href","%%=v(@".$module_key_name. "_" ."href".")=%%", $text);
                    
                        if ($module_type == "cta") {
                            echo $module_key_name_title;echo '</br>';
                            echo $module_key_name_alias;echo '</br>';
                            echo $module_key_name_href;echo '</br>';
                            
                        }
                        elseif ($module_type == "image_withoutlink") {
                            echo $module_key_name_title;echo '</br>';
                           # echo $module_key_name_alias;echo '</br>';
                            echo $module_key_name_href;echo '</br>';
                        }
                        elseif ($module_type == "image_withlink") {
                            echo $module_key_name_title;echo '</br>';
                            echo $module_key_name_alias;echo '</br>';
                            echo $module_key_name_href;echo '</br>';
                            echo $module_key_name_link;echo '</br>';
                        }
                        elseif ($module_type == "paragraph") {
                           echo $module_key_name_title;echo '</br>';
                        }
                        elseif ($module_type == "heading") {
                            echo $module_key_name_title;echo '</br>';
                        }
                        else
                        {
                            $text = "";
                        }
                    
                }

                preg_match('#\%%(.*?)\%%#', $text, $match);
                for ($dynamic_variables=0; $dynamic_variables < sizeof($match); $dynamic_variables++) { 
                    str_replace("%%".$match[$dynamic_variables]."%%",'%%=v(AttributeValue("'.$match[$dynamic_variables].'")=%%',$text);
                }
                echo ']%%';
                echo '<pre><xmp>';
                echo '<tr><td>'; 
                echo $text;
                echo '</td></tr>';
                echo '</xmp></pre>';    
                echo '</br>';
                echo '%%[ Endif ]%%';
                echo('</br>');
                //echo $value['end_ampscript'];
                echo('<!-- end '.$key_name.' -->');
                echo('</br> </br>');
            }
        }
        echo '<pre><xmp>'; 
        echo '<custom name="opencounter" type="tracking">';
        echo('<table cellpadding="2" cellspacing="0" width="600" ID="Table5" Border=0><tr><td><font face="verdana" size="1" color="#444444">%%emailaddr%% </br>This email was sent by: <b>%%Member_Busname%%</b><br>%%Member_Addr%% %%Member_City%%, %%Member_State%%, %%Member_PostalCode%%, %%Member_Country%%<br><br></font><a href="%%profile_center_url%%" alias="Update Profile">Update Profile</a></td></tr></table>');
        echo $email_template['body_end_tag'];
        echo '</xmp></pre>';  
    }

    public function getTaggedPromocode($value, $country_code, $language_code, $edm_id) {
        $this->load->model('Edms_saved_inputs_model');
        $data = $this->Edms_saved_inputs_model->getTaggedPromocode($value, $country_code, $language_code, $edm_id);
        echo json_encode($data);
    }

    public function getListOfTaggedPromocode ($country_code, $language_code, $edm_id)
    {
        $this->load->model('Edms_saved_inputs_model');
        $data = $this->Edms_saved_inputs_model->getListOfTaggedPromocode( $country_code, $language_code, $edm_id);
        $json_array["data"] = $data;
        echo json_encode($json_array);
    }
    public function setTaggedPromocode()
    {
        $json = json_decode(file_get_contents("php://input"));

        if (!isset($json->promocode) || empty($json->promocode)) {
            $promocode = "NULL";
        } else {
        $promocode = $this->db->escape(strip_tags($json->promocode));
        }
        if (!isset($json->promocode_startdate) || empty($json->promocode_startdate)) {
            $promocode_startdate = "NULL";
        } else {
            $promocode_startdate = $this->db->escape(strip_tags($json->promocode_startdate));
          //  $promocode_startdate = date('Y-m-d',strtotime($json->$promocode_startdate));
        }
       
        if (!isset($json->promocode_enddate) || empty($json->promocode_enddate)) {
            $promocode_enddate = "NULL";
        } else {
        $promocode_enddate = $this->db->escape(strip_tags($json->promocode_enddate));
        //$promocode_enddate = date('Y-m-d',strtotime($json->$promocode_enddate));
        }

        if (!isset($json->tab_id) || empty($json->tab_id)) {
            $tab_id = "NULL";
        } else {
        $tab_id = $this->db->escape(strip_tags($json->tab_id));
        }

        if (!isset($json->country_code) || empty($json->country_code)) {
            $country_code = "NULL";
        } else {
        $country_code = $this->db->escape(strip_tags($json->country_code));
        }

        if (!isset($json->language_code) || empty($json->language_code)) {
            $language_code = "NULL";
        } else {
        $language_code = $this->db->escape(strip_tags($json->language_code));
        }
            
        if (!isset($json->edm_id) || empty($json->edm_id)) {
            $edm_id = "NULL";
        } else {
        $edm_id = $this->db->escape(strip_tags($json->edm_id));
        }
            
        if (!isset($json->campaign_id) || empty($json->campaign_id)) {
            $campaign_id = "NULL";
        } else {
        $campaign_id = $this->db->escape(strip_tags($json->campaign_id));
        }

        $this->load->model('Edms_saved_inputs_model');
        $data = $this->Edms_saved_inputs_model->setTaggedPromocode($tab_id,$country_code,$language_code,$edm_id,$promocode,$promocode_startdate,$promocode_enddate);
        return 1;
    }            
}
