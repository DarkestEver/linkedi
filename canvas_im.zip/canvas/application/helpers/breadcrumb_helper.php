<?php
class crumb {
    public $label;
    public $classname;
    public $url;
}

class Breadcrumb {

    public $crumbs;

    function __construct()
    {
        $this->crumbs = array(new crumb());
    }

    public function addCrumbs($first=false, $label, $classname='', $url='') {
       if (!empty($label)) {
            $temp = new crumb();
            $temp->label = $label;
            $temp->classname = $classname;
            $temp->url = $url;

            if ($first) {
                $this->crumbs = array($temp);
            } else {
                array_push($this->crumbs, $temp);
            }
            return true;
       }
       return false;
    }

    public function setCrumbs($crumblist) {
       $this->crumbs = array(new crumb());

       if (empty($crumblist)) {
            $temp = new crumb();
            $temp->label = 'Dashboard';
            $temp->classname = 'title active';
            $temp->url = '';
            $this->crumbs = array($temp);
       } else {
            $this->crumbs = $crumblist;
       }
    }
}
?>
