<?php 

function folder_tree()
{
		$CI = get_instance();
		$CI->load->model('Campaign_model');
        $CI->load->model('Vertical_model');
        $CI->load->model('Category_model');
        $Categories = $CI->Category_model->getAll();
        echo '<ul id="tree"><li class="icon-home"> <a href="#">home</a> <ul>';
        foreach ($Categories as $key => $Category) {
           echo "<li><a class='icon-folder' href='#'>".$Category['category_name']." </a>";
           echo "<ul>";
            $verticals = $CI->Vertical_model->getByCatID($Category['id']);
            foreach ($verticals as $key => $vertical) {
                echo "<li><a class='icon-folder' href='#'>".$vertical['vertical_name']." </a>";
                echo "<ul>";
                $campaigns = $CI->Campaign_model->getAllCampaignsByVNC( $Category['category_name'], $vertical['vertical_name']);
                foreach ($campaigns as $key => $campaign) {
                    echo "<li><a class='icon-text campaign_selected' data-campaign_id = '".$campaign['id']."' href='#' > ".$campaign['campaign_name']." </a>";
                }
                echo "</ul>";
                echo "</li>";
            }
           echo "</ul>";
           echo "</li>";
        }
        echo "</li></ul></ul>";	

        
}

?>	