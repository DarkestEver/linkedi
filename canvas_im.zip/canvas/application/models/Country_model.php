<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Country_model extends CI_Model {

        public function __construct()
        {
                parent::__construct();
                // Your own constructor code
        }

        public function getCountries()
        {
            $sql = "SELECT * FROM countries where is_deleted = 0;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function getEDMCountries($edm_id='', $campaign_id='')
        {
            $sql = "SELECT * FROM edm_countries ec inner join countries c on ec.country_id = c.id where edm_id = '".$edm_id."' and  campaign_id  = ".$campaign_id.";";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function getEDMRemainingCountries($edm_id='')
        {
            $sql = "SELECT * FROM countries c  where id not in ( select country_id from  edm_countries ec where ec.edm_id = '".$edm_id."');";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function insert_countries($campaign_id="", $emailname="",$value=""){
                $sql = "insert into edm_countries (campaign_id, edm_id, country_id) values (".$campaign_id.",".$emailname.",".$value.");";
               return $this->db->query($sql);
        }

         public function updateCountry($postData=null, $action=null) {
           // var_dump($postData); die;
                if (!isset($postData["country_name"]) || empty($postData["country_name"])) { $country_name = ""; } else { $country_name = $this->db->escape(strip_tags($postData["country_name"]));}
                if (!isset($postData["country_code"]) || empty($postData["country_code"])) { $country_code = ""; } else { $country_code = $this->db->escape(strip_tags($postData["country_code"]));}
                if (!isset($postData["language_code"]) || empty($postData["language_code"])) { $language_code = ""; } else { $language_code = $this->db->escape(strip_tags($postData["language_code"]));}
               
            if ($action == "save") {
                
                $error = 0;
                
                 $sql = "SELECT * FROM countries WHERE country_name = $country_name and country_code = $country_code and language_code = $language_code"; 
                        $query = $this->db->query($sql);
                        if ($query->num_rows() > 0) {
                            return False;
                        }
                        else {
                                $sql2 = "INSERT INTO countries (country_name,country_code,language_code) VALUES ($country_name,$country_code,$language_code)";
                                $this->db->query($sql2);
                                return TRUE;   
                        }
            }
            if ($action == "edit") {
                 $error = 0;
                 $sql = "SELECT * FROM countries WHERE country_name = $country_name and country_code = $country_code and language_code = $language_code"; 
                        $query = $this->db->query($sql);
                        if ($query->num_rows() == 0) {
                            $sql2 = "update countries set language_code = $language_code  where country_name = $country_name and country_code = $country_code ";
                            $this->db->query($sql2);
                            return TRUE;   
                        }
                        else
                        {
                            return False;
                        }
                        
            }
            if ($action == "delete") {
                $error = 0;
                $sql = "update countries set is_deleted = 1  where country_name = $country_name and country_code = $country_code and language_code = $language_code ;";
                $query = $this->db->query($sql);
                return true;
            }
        }

        public function getCountriesByID($id="")
        {
            $sql = "SELECT * FROM countries where id = $id;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }
}


