<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Log_model extends CI_Model {

        public function __construct()
        {
                parent::__construct();
                // Your own constructor code
        }

        public function get_log($value='')
        {
            $sql = "SELECT * FROM  log_table ";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function set_log($id='', $message="")
        {
            $sql = "insert into log_table(user_id,log_message) values ('".$id."','".$message."')";
            $query = $this->db->query($sql);
                    
        }

}