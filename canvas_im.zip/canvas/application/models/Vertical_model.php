<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vertical_model extends CI_Model {

        public function __construct()
        {
                parent::__construct();
                // Your own constructor code
        }

        public function getAll()
        {
            $sql = "SELECT * FROM campaign_vertical where is_deleted = 0;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

      
         public function update($postData=null, $action=null) {
           // var_dump($postData); die;
            if (!isset($postData["vertical_name"]) || empty($postData["vertical_name"])) { $country_name = ""; } else { $vertical_name = $this->db->escape(strip_tags($postData["vertical_name"]));}
            if (!isset($postData["id"]) || empty($postData["id"])) { $id = ""; } else { $id = $this->db->escape(strip_tags($postData["id"]));}
            if ($action == "save") {
                
                $error = 0;
                
                 $sql = "SELECT * FROM campaign_vertical WHERE vertical_name = $vertical_name"; 
                        $query = $this->db->query($sql);
                        if ($query->num_rows() > 0) {
                            return False;
                        }
                        else {
                                $sql2 = "INSERT INTO campaign_vertical (vertical_name) VALUES ($vertical_name)";
                                $this->db->query($sql2);
                                return TRUE;   
                        }
            }
            if ($action == "edit") {
                 $error = 0;
                 $sql = "SELECT * FROM campaign_vertical WHERE vertical_name = $vertical_name "; 
                        $query = $this->db->query($sql);
                        if ($query->num_rows() == 0) {
                            $sql2 = "update campaign_vertical set vertical_name = $vertical_name  where id = $id ";
                            $this->db->query($sql2);
                            return TRUE;   
                        }
                        else
                        {
                            return False;
                        }
                        
            }
            if ($action == "delete") {
                $error = 0;
                $sql = "update campaign_vertical set is_deleted = 1  where vertical_name = $vertical_name ;";
                $query = $this->db->query($sql);
                return true;
            }
        }

        public function getByID($id="")
        {
            $sql = "SELECT * FROM campaign_vertical where id = $id;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }

        public function getByCatID($id="")
        {
            $sql = "SELECT * FROM campaign_vertical where category_id = $id;";
                    $query = $this->db->query($sql);
                    if ($query->num_rows() > 0) {
                        return $query->result_array();
                    } else {
                        return array();
                    }
        }
}


