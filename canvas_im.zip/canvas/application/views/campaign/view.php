<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
?>
                <div class='panel panel-info'>
                    <div class='panel-heading'>
                        <i class='fas fa-cubes'></i>
                        Campaign view
                        <div class='panel-tools'>
                            <div class='btn-group'>
                                <a class='btn' data-toggle='toolbar-tooltip' href="<?php echo site_url();?>edm/create/campaign/<?=$campaign_id;?>" title="New Email">
                                    <i class='fa fa-plus'></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class='panel-body'>
                        <div class='row'>
                            <div class="col-md-9">
                                <?php
                                    $edm_id = "";
                                    if (isset($campaign_details) ) {
                                ?>
                                <p><b>Campaign</b>: <?php echo $campaign_details[0]['campaign_name']; ?></p>
                                <p><b>Audience</b>: <?php echo $campaign_details[0]['category_name']; ?></p>
                                <p><b>Vertical</b>: <?php echo $campaign_details[0]['vertical_name']; ?></p>
                                <p><b>Market</b>: <?php echo $campaign_details[0]['market_name']; ?></p>
                                <p><b>Service Type</b>: <?php echo $campaign_details[0]['wheels']; ?></p>
                                <?php } ?>
                            </div>
                        </div>
                        <div class='row'>&nbsp;</div>
                    </div>
                </div>
