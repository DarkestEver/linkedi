<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
?>
                <div class='panel panel-default'>
                    <div class='panel-heading'>
                        <i class='fas fa-cubes'></i>
                        Campaign view
                        <div class='panel-tools'>
                            <div class='btn-group'>
                                <a class='btn' id="showNewEmail"  title="New Email">
                                    <i class='fa fa-plus'></i>
                                </a>
                                <a class='btn' data-toggle='toolbar-tooltip' href='#' title="Refresh Lists">
                                    <i class='fa fa-refresh'></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class='panel-body filters'>
                        <div class='row'>
                            <div class='col-md-9'>
                                <?php
                                    $edm_id = "";
                                    if (isset($campaign_details) ) {
                                ?>

                                <div id="accordion">
                                    <div class="card">
                                        <div class="card-header" id="headingOne">
                                            <h5 class="no-mb">
                                                <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                    Campaign Information
                                                </button>
                                            </h5>
                                        </div>

                                        <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                                            <div class="card-body">
                                                <p><b>Campaign</b>: <?php echo $campaign_details[0]['campaign_name']; ?></p>
                                                <p><b>Audience</b>: <?php echo $campaign_details[0]['category_name']; ?></p>
                                                <p><b>Vertical</b>: <?php echo $campaign_details[0]['vertical_name']; ?></p>
                                                <p><b>Market</b>: <?php echo $campaign_details[0]['market_name']; ?></p>
                                                <p><b>Service Type</b>: <?php echo $campaign_details[0]['wheels']; ?></p>
                                            </div>
                                            <div class="card-body">
                                                <a href="<?php echo base_url(); ?>email/create/campaign/<?php echo $campaign_id ; ?>" class="btn btn-primary">Add new email</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <!-- <center>
                                    <div class="card text-white bg-secondary mb-3" style="max-width: 300px;">
                                        <div class="card-header">Info</div>
                                        <div class="card-body">
                                            <p><b>Campaign</b>: <?php echo $campaign_details[0]['campaign_name']; ?></p>
                                            <p><b>Audience</b>: <?php echo $campaign_details[0]['category_name']; ?></p>
                                            <p><b>Vertical</b>: <?php echo $campaign_details[0]['vertical_name']; ?></p>
                                            <p><b>Market</b>: <?php echo $campaign_details[0]['market_name']; ?></p>
                                            <p><b>Service Type</b>: <?php echo $campaign_details[0]['wheels']; ?></p>
                                        </div>
                                        <ul class="list-group list-group-flush text-black">
                                            <li class="list-group-item"><b>Campaign</b>: <?php echo $campaign_details[0]['campaign_name']; ?></li>
                                            <li class="list-group-item"><b>Category</b>: <?php echo $campaign_details[0]['category_name']; ?></li>
                                            <li class="list-group-item"><b>Vetical</b>: <?php echo $campaign_details[0]['vertical_name']; ?></li>
                                            <li class="list-group-item"><b>Market</b>: <?php echo $campaign_details[0]['market_name']; ?></li>
                                            <li class="list-group-item"><b>Wheels</b>: <?php echo $campaign_details[0]['wheels']; ?></li>
                                        </ul>
                                        <div class="card-body">
                                            <a href="<?php echo base_url(); ?>email/create/campaign/<?php echo $campaign_id ; ?>" class="btn btn-primary">Add new email</a>
                                        </div>
                                    </div>
                                </center> -->
                                <?php } ?>
                            </div>
                        </div>
                        <div class='divider'></div>
                        <div class='row'>&nbsp;</div>

                       

                        <form method="POST" action="#">
                            <?php /* if (!isset($edm_action)) { ?>
                            <div class='row'>
                                <div class="col-lg-12">
                                    <div class='page-header'>
                                        <h4>Add New Email</h4>
                                    </div>
                                    <div>
                                        <input type="hidden" name="action" value="<?php  if (isset($action)) echo $action; ?>">
                                        <input type="hidden" name="campaign_id" value="<?php  echo $campaign_id; ?>">
                                        <div class="form-group row">
                                            <div class="col-sm-3">
                                                <label for="emailname" style="padding:.375rem .75rem">Email Name</label>
                                            </div>
                                            <div class="col-sm-6">
                                                <input type="text" class="form-control" name="emailname" id="emailname" placeholder="Email Name">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-3">
                                                <label for="male" style="padding:.375rem .75rem">Market Name</label>
                                            </div>
                                            <div class="col-sm-6">
                                                <select class="form-control" id="marketName" name="marketName" placeholder="marketName" multiple>
                                                    <?php foreach ($countries as $key => $country) {
                                                        echo '<option value="'.$country['id'].'">'.$country['country_code']."_".$country['language_code'].'</option>';
                                                    } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-9">
                                                <input type="submit" class="btn btn-primary" value="Save">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php } elseif (isset($edm_action) && $edm_action="add") { ?>
                            <div class='row'>
                                <div class="col-lg-12">
                                    <div class='page-header'>
                                        <h4>Add New Language</h4>
                                    </div>
                                    <div>
                                        <input type="hidden" name="action" value="<?php if (isset($action)) echo $action; ?>">
                                        <input type="hidden" name="edm_action" value="<?php if (isset($edm_action)) echo $edm_action; ?>">
                                        <input type="hidden" name="campaign_id" value="<?php echo $campaign_id; ?>">
                                        <input type="hidden" name="emailname" value="<?php echo $edm_name[0]['id']; ?>">
                                        <div class="form-group row">
                                            <div class="col-sm-3">
                                                <label for="male" style="padding:.375rem .75rem">Email Name</label>
                                            </div>
                                            <div class="col-sm-6">
                                                <label><?php echo $edm_name[0]['email_name']; ?></label>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-3">
                                                <label for="male" style="padding:.375rem .75rem">Market Name</label>
                                            </div>
                                            <div class="col-sm-6">
                                                <select class="form-control" id="marketName" name="marketName" placeholder="marketName" multiple>
                                                    <?php foreach ($countries as $key => $country) {
                                                        echo '<option value="'.$country['id'].'">'.$country['country_code']."_".$country['language_code'].'</option>';
                                                    } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-9">
                                                <input type="submit" class="btn btn-primary">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php } */ ?>
                        </form>
                        <div class='page-header'>
                            <h4>Email list</h4>
                        </div>
                        <table class='table table-bordered'>
                            <thead>
                                <tr>
                                    <th>Email Name</th>
                                    <th>Country</th>
                                    <th>Language</th>
                                    <th>Status</th>
                                    <th>Created Date</th>
                                    <th class='actions'>
                                        Actions
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($edm_details as $key => $value) { ?>
                                <tr>
                                    <td>
                                        <?php echo $value['email_name']; ?>
                                        <a class='btn btn-link' target="_blank" href='<?php echo base_url(); ?>email/template/<?php echo $campaign_id; ?>/<?php echo $value['id']; ?>' data-toggle='tooltip' title='<?php echo edm_status($value['status']); ?>'>
                                            <i class='fas fa-film'></i>
                                        </a>
                                        <a class='btn btn-link' href='<?php echo base_url(); ?>email/create/campaign/<?php echo $campaign_id.'/add/'.$value['id']; ?>' data-toggle='tooltip' title='Add Language'>
                                            <i class='fas fa-globe'></i>
                                            <!-- <svg class="bi bi-plus" width="2em" height="2em" viewBox="0 0 20 20" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd" d="M10 5.5a.5.5 0 01.5.5v4a.5.5 0 01-.5.5H6a.5.5 0 010-1h3.5V6a.5.5 0 01.5-.5z" clip-rule="evenodd"></path>
                                                <path fill-rule="evenodd" d="M9.5 10a.5.5 0 01.5-.5h4a.5.5 0 010 1h-3.5V14a.5.5 0 01-1 0v-4z" clip-rule="evenodd"></path>
                                            </svg> -->
                                        </a>
                                    </td>
                                    <td><?php echo $value['country_code']; ?></td>
                                    <td><?php echo $value['language_code']; ?></td>
                                    <td> <?php echo edm_input_status($value['localized_input_stutus']); ?> </td>
                                    <td><?php echo $value['createddate']; ?></td>
                                    <td>
                                        <?php if ($value['status'] != 0) { ?>
                                        <a class='btn btn-link' href='<?php echo base_url(); ?>email/edit/<?php echo $campaign_id; ?>/<?php echo $value['id']."/".$value['country_code']."/".$value['language_code']; ?>' data-toggle='tooltip' title='Link'>
                                            <i class='fas fa-link'></i>
                                        </a>
                                        <?php } ?>
                                        <a class='btn btn-success' href='<?php echo base_url(); ?>email/preview/<?php echo $campaign_id; ?>/<?php echo $value['id']."/".$value['country_code']."/".$value['language_code']; ?>' data-toggle='tooltip' title='Preview'>
                                            <i class='fas fa-eye'></i>
                                        </a>
                                        <a class='btn btn-warning' href='<?php echo base_url().'email/get_ampscript2/'.$campaign_id.'/'.$value['id']; ?>' data-toggle='tooltip' title='Code'>
                                            <i class='fas fa-code'></i>
                                        </a>
                                        <a class='btn btn-info' href='<?php echo base_url().'email/apicalls/'.$campaign_id.'/'.$value['id']; ?>' data-toggle='tooltip' title='API'>
                                            <i class='fas fa-upload'></i>
                                        </a>
                                        <!-- <a class='btn btn-warning' href='#' data-toggle='tooltip' title='Edit'><i class='fas fa-pencil-alt'></i></a> -->
                                        <a class='btn btn-danger' href='#' data-toggle='tooltip' title='Delete'><i class='fas fa-trash'></i></a>
                                    </td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>


 <!-- Modal -->
                        <div class="modal fade" id="newEmail" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                  <form method="POST" action="#">

                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLongTitle">Add New Email</h5>
                                    </div>
                                    <div class="modal-body">
                                        
                                        <?php if (!isset($edm_action)) { ?>
                                            <div class='row'>
                                                <div class="col-lg-12">
                                                    <div>
                                                        <input type="hidden" name="action" value="<?php  if (isset($action)) echo $action; ?>">
                                                        <input type="hidden" name="campaign_id" value="<?php  echo $campaign_id; ?>">
                                                        <div class="form-group row">
                                                            <div class="col-sm-3">
                                                                <label for="emailname" style="padding:.375rem .75rem">Email Name</label>
                                                            </div>
                                                            <div class="col-sm-6">
                                                                <input type="text" class="form-control error_message" name="emailname" id="emailname" placeholder="Email Name">
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <div class="col-sm-3">
                                                                <label for="male" style="padding:.375rem .75rem">Market Name</label>
                                                            </div>
                                                            <div class="col-sm-6">
                                                                <select class="form-control" id="marketName" name="marketName[]" placeholder="marketName" multiple>
                                                                    <?php foreach ($countries as $key => $country) {
                                                                        echo '<option value="'.$country['id'].'">'.$country['country_code']."_".$country['language_code'].'</option>';
                                                                    } ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php } ?>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        <input type="submit" class="btn btn-primary" value="Save" id="btn_save_new_email" />
                                    </div>
                                  </form>
                                </div>
                            </div>
                        </div>