<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
?>
                <div class='panel panel-default'>
                    <div class='panel-heading'>
                        <i class='fas fa-cubes'></i>
                        Emails
                        <div class='panel-tools'>
                            <div class='btn-group'>
                                <a class='btn' data-toggle='toolbar-tooltip' href='#' title="Refresh Lists">
                                    <i class='fa fa-refresh'></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class='panel-body filters'>
                        <div class='row'>
                            <div class='text-center'>
                                <form class="user">
                                    <div class="form-group">
                                        <div class="col-sm-3" >
                                            <input type="text" class="form-control" name="emailname" id="emailname" placeholder="Email Name">
                                        </div>
                                        <div class="col-sm-2" >
                                            <select class="form-control" id="categoryName" name="categoryName" placeholder="categoryName">
                                                <option value="PAX">PAX</option>
                                                <option value="DAX">DAX</option>
                                                <option value="MEX">MEXFood</option>
                                                <option value="MEX">MEXPay</option>
                                                <option value="Global">Global</option>
                                            </select>
                                        </div>
                                        <div class="col-sm-2">
                                            <select class="form-control" id="vertical" name="vertical" placeholder="vertical">
                                                <option value="PAX">PAX</option>
                                                <option value="DAX">DAX</option>
                                                <option value="MEX">MEXFood</option>
                                                <option value="MEX">MEXPay</option>
                                                <option value="Global">Global</option>
                                            </select>
                                        </div>
                                        <div class="col-sm-2">
                                            <select class="form-control" id="wheel" name="wheel" placeholder="wheel">
                                                <option value="2W">2W</option>
                                                <option value="3W">3W</option>
                                                <option value="4W">4W</option>
                                            </select>
                                        </div>
                                        <div class="col-sm-2">
                                            <a href="#" id="search" class="btn btn-primary">Search</a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class='row'>&nbsp;</div>
                        <table class='table table-bordered' id="dataTable">
                            <thead>
                                <tr>
                                    <th>Campaign</th>
                                    <th>Email Name</th>
                                    <th>Category</th>
                                    <th>Vertical</th>
                                    <th>Wheels</th>
                                    <th>Date Created</th>
                                    <th>Status</th>
                                    <th class='actions'>
                                        Actions
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
