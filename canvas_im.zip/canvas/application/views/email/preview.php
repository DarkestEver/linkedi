<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<center>
<div class="row">
<div class="col-lg-12">
<a href="#" id="mobile_view"><i class="fas fa-mobile-alt fa-2x"></i>
</a>
<a href="#" id="desktop_view"><i class="fas fa-desktop fa-2x"></i>
</a>
</div>
</div>
<iframe onload="this.style.height=this.contentDocument.body.scrollHeight +'px';" width="650px" id="ifram_preview" src="<?php echo site_url().$preview_url?>"></iframe>
<center>