<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$edm_id = $edm_details[0]['id'] ;
 $campaign_id = $edm_details[0]['campaign_id'];
  ?>
<input type="hidden" id="emd_id"  value="<?php echo $emd_id; ?>">
<input id="campaign_id" name="campaign_id" type="hidden" value="<?php echo $campaign_id; ?> ">

<div class="row">
    <!-- Draggable container -->
     <div class="col-md-4">
        <div class="admin-pro-accordion-wrap">
            <div class="panel-group edu-custon-design" id="accordion">
                <?php foreach ($modules_category as $key => $category) { ?>
                <h3><?php echo $category['mc_name']; ?></h3>
                  <div>
                    <?php foreach ($modules as $v) { if ($category['id'] == $v['module_category_id']) {
                            echo '<a href="#"> <div class="draggable" id="'
                                .$v['module_key']
                                .'" data-module="'
                                .$v['module_key']
                                .'">'
                                .'<img style="height:auto; width:100%"  data-toggle="tooltip" title="'.$v['description'].'" src="'.site_url().'resources/img/module_icon/'. $v['module_key'].'.png">'
                            .'</div></a>';
                     } } ?>
                  </div>
                <?php }    ?>
            </div>
        </div>
    </div>
    <div class="col-md-8 float-right">

        <div class="card shadow mb-9" style="min-height:400px;width:602px;">
            <div class="card-header d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Email builder</h6>
                <a href="#" id="saveTemplates" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Save Template</a>
            </div>
            <ul class="card-body" id="droppable" style="width:602px;list-style: none; min-height: 1000px;padding: 0px" width="602">
                
                <?php  foreach ($existing_modules as $key => $v) {
                    echo '<li class="'.$v['module_key'].' closeparent" id="'.strval($v['t_id']).'" style="padding: 0px 0 0px 0;">';
                    echo '<div style="right: 25px;position: absolute; color:#d43f3a" class="delete_li" data-deleteli="'.strval($v['t_id']).'"><i class="fas fa-times"></i></div>' ;
                    echo '<div class="addvariation" style="left: 0;right: auto;position: absolute;"><button type="button" class="btn btn-primary btn-sm"  data-toggle="modal" data-target="#veriationModal" data-variation="'.strval($v['t_id']).'"><i class="fab fa-buffer"></i></button></div>' ;
                    echo '<img  title="description" src="'.site_url().'resources/img/module_icon/'. $v['module_key'].'.png">';
                    echo '</li>';
                } ?>
               
            </ul>

             </div>
                <ul id="moduleshid" style="display:none">
                <?php foreach ($modules as $v) {
                    echo '<li class="'.$v['module_key'].' closeparent" style="padding: 0px 0 0px 0;">';
                    echo '<img  title="description" src="'.site_url().'resources/img/module_icon/'. $v['module_key'].'.png">';
                    echo '</li>';
                } ?>
            </ul>
        </div>
<!-- Logout Modal-->
<div class="modal fade" id="veriationModal" tabindex="-1" role="dialog" aria-labelledby="variationModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="variationModalLabel">Module Attributes</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="t_id">
                <div class="form-group">
                    <label for="message-text" class="col-form-label">Block Start Code</label>
                    <textarea class="form-control form-control-sm" id="t_start_ampscript"></textarea>
                </div>
                <div class="form-group field_wrapper" id="t_new_variation_condition">
                    <div class="row">
                        <div class="col-lg-2">
                            <div class="form-group">
                                <label for="recipient-name" class="col-form-label">Name</label>
                                <input type="text" class="form-control form-control-sm" name="t_condition_name[]">
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="form-group">
                                <label for="t_condition">Condition</label>
                                <select class="form-control form-control-sm" name="t_hide_or_show[]">
                                    <option value="hide">Hide</option>
                                    <option value="show">Show</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="form-group">
                                <label for="t_condition">DE variable</label>
                                <input type="text" class="form-control form-control-sm" name="t_sending_de_variable[]">
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="form-group">
                                <label for="t_condition">Condition</label>
                                <select class="form-control form-control-sm" name="t_condition[]">
                                    <option value=">">></option>
                                    <option value="<"><</option>
                                    <option value=">=">>=</option>
                                    <option value="<="><=</option>
                                    <option value="==">==</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <label for="recipient-name" class="col-form-label">Value</label>
                            <input type="text" class="form-control form-control-sm" name="t_hide_show_value[]">
                        </div>
                        <div class="col-lg-1">
                            <label for="recipient-name" class="col-form-label"></label>
                            <a type="button" class="btn btn-primary" id="btn_savevaraitionscondition">Save</a>
                        </div>
                    </div>
                    <div id="variation_display_model" class="form-control" style="height:auto">
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-lg-6">
                        <label for="recipient-name" class="col-form-label">Background Color</label>
                        <input type="text" class="form-control form-control-sm" id="t_background_color">
                    </div>
                    <div class="col-lg-6">
                        <label for="recipient-name" class="col-form-label">Background Image Link</label>
                        <input type="text" class="form-control form-control-sm" id="t_background_image_link">
                    </div>
                </div>
                <div class="form-group">
                    <label for="message-text" class="col-form-label">Block End Code</label>
                    <textarea class="form-control form-control-sm" id="t_end_ampscript"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<div id="hidden_variation_block" style="display: none;">
    <div class="row shadow" >
        <div class="col-lg-2">
            <label for="recipient-name"  class="hidden_variation_block_name" style="margin-bottom:0px">Name</label>
        </div>
        <div class="col-lg-2" >
            <label for="t_hide_show_value" class="hidden_variation_block_show_hide" style="margin-bottom:0px">Hide/Show</label>
        </div>
        <div class="col-lg-2">
            <label for="t_condition" class="hidden_variation_block_de_variable" style="margin-bottom:0px">DE variable</label>
        </div>
        <div class="col-lg-2">
            <label for="t_condition" class="hidden_variation_block_condition" style="margin-bottom:0px">Condition</label>
        </div>
        <div class="col-lg-2">
            <label for="recipient-name" class="hidden_variation_block_value" style="margin-bottom:0px">Value</label>
        </div>
        <div class="col-lg-1">
            <a  class="remove_variation" ><i class="fas fa-minus-square"></i></a>
        </div>
    </div>
</div>

<style type="text/css">
    .ui-widget-content {
    background: #ececec;
}

.ui-accordion .ui-accordion-content {
padding: 0px;
}
</style>