<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
?>
                <div class='panel panel-info'>
                    <div class='panel-heading'>
                        <i class='fas fa-cubes'></i>
                        <?php echo $edm_details[0]['email_name']; ?>
                    </div>
                    <div class='panel-body'>
                        <div class='row'>
                            <div class="col-md-9">
                                <?php
                                    $edm_id = "";
                                    if (isset($edm_details) ) {
                                ?>
                                <p><b>Campaign</b>: <?php echo $edm_details[0]['campaign_name']; ?></p>
                                <p><b>Audience</b>: <?php echo $edm_details[0]['category_name']; ?></p>
                                <p><b>Vertical</b>: <?php echo $edm_details[0]['vertical_name']; ?></p>
                                <p><b>Market</b>: <?php echo $edm_details[0]['market_name']; ?></p>
                                <p><b>Service Type</b>: <?php echo $edm_details[0]['wheels']; ?></p>
                                <?php } ?>
                            </div>
                        </div>
                        <div class='row'>&nbsp;</div>
                    </div>
                </div>
