<?php
defined('BASEPATH') OR exit('No direct script access allowed');

if (!isset($sidebar)) {
	$sidebar = '';
}

if (!isset($breadcrumb)) {
	$temp = new crumb();
    $temp->label = 'Dashboard';
    $temp->classname = 'title active';
    $temp->url = '';
	$breadcrumb = new Breadcrumb();
    $breadcrumb->setCrumbs(array($temp));
}
?>

<!DOCTYPE html>
<html lang='en'>
  	<head>
    	<meta charset='utf-8'>
    	<meta content='IE=edge,chrome=1' http-equiv='X-UA-Compatible'>
    	<title>Canvas<?php if (isset($title) && (!empty($title)))
		{
			echo ' - ' . $title;
		}?></title>
    	<meta content='' name='author'>
    	<meta content='' name='description'>

    	<!-- Custom fonts for this template-->
		<link href="<?=base_url()?>resources/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
		<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
		<!-- Custom styles for this page -->
		<link href="<?=base_url()?>resources/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
				<!-- Tree Folder Structure -->
		<link href="<?=base_url()?>resources/vendor/folderstructure/css/jquery-explr-1.4.css" rel="stylesheet" type="text/css" />
		<!-- context menu -->
		<link href="<?=base_url()?>resources/vendor/contextMenu/dist/jquery.contextMenu.css" rel="stylesheet" type="text/css" />
		<!-- Custom styles for this template-->
		<link href="<?=base_url()?>resources/css/application.css" rel="stylesheet" type="text/css" />

		<script src="<?=base_url()?>resources/vendor/jquery/jquery.min.js"></script>
		<link href="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.1/themes/south-street/jquery-ui.min.css" rel="stylesheet" type="text/css" />
   
		<style type="text/css">
			.nav-tabs .nav-link:not(.active) {
				border-color: transparent !important;
			}
		</style>
		<style>
			.closeparent{position:relative;overflow:hidden;}
			.close{position:absolute;right:0;}
		</style>
		
  	</head>
	<body class='main page'>
    	<!-- Navbar -->
    	<div class='navbar navbar-default' id='navbar'>
      		<a class='navbar-brand' href='<?=base_url()?>'>
            	<img src="<?=base_url()?>resources/img/module_icon/canvas.png" alt="Canvas Logo" width="30" height="30">
        		Canvas
      		</a>
      		<ul class='nav navbar-nav pull-right'>
      			<li>
      				<div class="spinner-border text-primary" role="status">
					  <span class="sr-only">Loading...</span>
					</div>
					<div class="spinner-border text-secondary" role="status">
					  <span class="sr-only">Loading...</span>
					</div>
      			</li>
        		<li>
		          	<a class='dropdown-toggle' data-toggle='dropdown' href='#'>
		            	<i class='fas fa-cog'></i>
		            	Settings
		            	<b class='caret'></b>
		          	</a>
          			<ul class='dropdown-menu'>
			          	<li>
							<a href="<?php echo site_url();?>settings/apis">API List</a>
						</li>
						<li>
							<a href="<?php echo site_url();?>settings/countries">Country List</a>
						</li>
			            <li class='divider'></li>
						<li>
							<a href="<?php echo site_url();?>settings/admins">User List</a>
						</li>
						<li>
							<a href="<?php echo site_url();?>settings/admins/add">Add User</a>
						</li>
          			</ul>
		        </li>
		        <li class='dropdown user'>
		          	<a class='dropdown-toggle' data-toggle='dropdown' href='#'>
		            	<i class='fas fa-user'></i>
		            	<strong><?php echo $this->session->userdata("username"); ?></strong>
		            	<b class='caret'></b>
		          	</a>
          			<ul class='dropdown-menu'>
			            <li>
			              	<a href='#'>Profile</a>
			            </li>
			            <li class='divider'></li>
			            <li>
			              	<a href="<?php echo site_url();?>login">Logout</a>
			            </li>
          			</ul>
        		</li>
      		</ul>
    	</div>
    	<div id='wrapper'>
      		<!-- Sidebar -->
      		<section id='sidebar'>
        		<i class='fas fa-align-justify fa-large' id='toggle'></i>
        		<ul id='dock'>
          			<li class='<?php echo ($sidebar == "Dashboard") ? "active " : ""; ?>launcher'>
            			<i class='fas fa-tachometer-alt'></i>
            			<a href="<?php echo site_url();?>start/">Dashboard</a>
          			</li>
          			<li class='<?php echo ($sidebar == "Campaign") ? "active " : ""; ?>launcher'>
						<i class="fas fa-cubes"></i>
						<a href="<?php echo site_url();?>campaign/">Campaign</a>
					</li>
					<li class='<?php echo ($sidebar == "Email") ? "active " : ""; ?>launcher'>
						<i class="fas fa-envelope"></i>
						<a href="<?php echo site_url();?>email/">Email</a>
					</li>
					<li class='<?php echo ($sidebar == "keywordsearch") ? "active " : ""; ?>launcher'>
						<i class="fab fa-searchengin"></i>
						<a href="<?php echo site_url();?>keywordsearch/">Promo Code</a>
					</li>
        		</ul>
      		</section>
      		<!-- Tools -->
      		<section id='tools'>
      			<ul class='breadcrumb' id='breadcrumb'>
                <?php
                    foreach($breadcrumb->crumbs as $crumb) {
                        echo (!empty($crumb->classname)) ? "<li class='" . $crumb->classname . "'>" : "<li>";
                        echo (!empty($crumb->url)) ? "<a href='" . $crumb->url . "'>" . $crumb->label . "</a></li>" : $crumb->label . "</li>";
                    }
                ?>
                </ul>
      		</section>
      		<!-- Content -->
      		<div id='content'>

