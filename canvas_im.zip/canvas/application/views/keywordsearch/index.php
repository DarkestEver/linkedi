<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
?>
                <div class='panel panel-default'>
                    <div class='panel-heading'>
                        <i class="fab fa-searchengin"></i>
                        Search Promo Code
                    </div>
                    <div class='panel-body filters'>
                        <div class='row'>
                            <div class='text-center'>
                                <form class="user">
                                    <div class="form-group">
                                        <div class="col-sm-3" >
                                            <input type="text" class="form-control" name="keyword" id="keyword" placeholder="Promo Code">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-3" >
                                           <label class="radio-inline">
                                              <input type="radio" value="p" ="radio_prmocode" name="search_radio" checked>Tagged Promo Code
                                            </label>
                                            <label class="radio-inline">
                                              <input type="radio" value="s" id="radio_keyword" name="search_radio" >Keyword
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-sm-2">
                                            <a href="#" id="search" class="btn btn-primary">Search</a>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class='row'>&nbsp;</div>
                        <div id="div_dataTable" >
                            <table class='table table-bordered' id="dataTable">
                                <thead>
                                    <tr>
                                        <th>Campaign</th>
                                        <th>Email Name</th>
                                        <th>Category</th>
                                        <th>Vertical</th>
                                        <th>Country</th>
                                        <th>Language</th>
                                        <th>Status</th>
                                        <th>Link</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                        <div id="div_dataTable_promo">
                            <table class='table table-bordered' id="dataTable_promo">
                                <thead>
                                    <tr>
                                        <th>Campaign</th>
                                        <th>Email Name</th>
                                        <th>Category</th>
                                        <th>Vertical</th>
                                        <th>Country</th>
                                        <th>Language</th>
                                        <th>Promo</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Status</th>
                                        <th>Link</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
