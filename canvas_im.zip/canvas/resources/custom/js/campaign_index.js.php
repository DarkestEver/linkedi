<script type="text/javascript">
    $(document).ready(function() {
      

    });

    jQuery.browser = {};
    (function () {
        jQuery.browser.msie = false;
        jQuery.browser.version = 0;
        if (navigator.userAgent.match(/MSIE ([0-9]+)\./)) {
            jQuery.browser.msie = true;
            jQuery.browser.version = RegExp.$1;
        }
    })();
    $(document).ready(function(){
        $("#tree").explr();
    });


    var selected_campaign ="";
    $('.campaign_selected').click(function(){
        selected_campaign = $(this).data("campaign_id");
       get_campaign_list(selected_campaign);
    });


function get_campaign_list(campaign_id)
{
    var dataTable = $('#dataTable').DataTable({
          
            'processing': true,
            'serverSide': true,
            'serverMethod': 'post',
            'searching': false, // Remove default Search Control
            searching: false, paging: false, info: false, "destroy": true,"bJQueryUI": true,
            'ajax': {
                'url':'<?php echo base_url()?>Campaign/ajax_campaign_selected/' + campaign_id  ,
                "type": "POST",
                'data': function(data){
                }
            },
            'columns': [
                { data: 'email_name' },
                { data: 'country_code' },
                { data: 'language_code' },
                { data: 'createddate' },
                { data: 'status' }
            ],
            'columnDefs': [
                {
                    'targets': 0,
                    render: function (data, type, row, meta) {
                        return  "<input class='hidden_row_id' type='hidden'   data-campaign_id='" + row['campaign_id'] + "' data-edm_id ='" + row['id'] + "' data-language_code='" + row['language_code'] + "' data-country_code ='" + row['country_code'] + "'  data-email_name = '" + row['email_name']+"'   /> " +  row['email_name'];
                    }
                },
                {
                    'targets': 4,
                    render: function (data, type, row, meta) {
                        return 'TBD';
                    }
                }
            ],

            "order": [[ 0, 'asc' ]],
            "drawCallback": function ( settings ) {
                var api = this.api();
                var rows = api.rows( {page:'current'} ).nodes();
                var last=null;
     
                api.column(0, {page:'current'} ).data().each( function ( group, i ) {
                    if ( last !== group ) {
                        $(rows).eq( i ).before(
                            '<tr class="group context-menu-active"><td colspan="5">'+group+'</td></tr>'
                        );
     
                        last = group;
                    }
                } );
            }
            });
}

$(function() {
    $.contextMenu({
            selector: '#dataTable tr.odd, #dataTable tr.even', 
            callback: function(key, options) {
                var td = options.$trigger;
                var tr = td.parent("tr")
                var dd = tr.find("td:first-child").find( ".hidden_row_id");
                var edm_id = dd.data('edm_id');
                var campaign_id = dd.data('campaign_id');
                var edm_id = dd.data('edm_id');
                var country_code = dd.data('country_code');
                var language_code = dd.data('language_code');

                switch(key) {
                  case "edit":
                    break;
                  case "copy":
                    break;
                  case "delete":
                    break;
                  case "input":
                    window.open('<?php echo site_url() ;?>' + 'email/edit/'+ campaign_id + "/" + edm_id  +"/" + country_code + "/" + language_code , '_blank'); 
                    break;
                  case "download_input_csv":
                    window.open('<?php echo site_url() ;?>' + 'email/export_input_file/'+ campaign_id + "/" + edm_id  +"/" + country_code + "/" + language_code , '_blank'); 
                    break;
                  case "upload_input_csv":
                    break;
                  case "preview_desktop":
                    window.open('<?php echo site_url() ;?>' + 'email/desktopPreview/'+ campaign_id + "/" + edm_id  +"/" + country_code + "/" + language_code , '_blank'); 
                    break;
                  case "preview_mobile":
                    window.open('<?php echo site_url() ;?>' + 'email/preview/'+ campaign_id + "/" + edm_id  +"/" + country_code + "/" + language_code , '_blank'); 
                    break;
                  case "download_de":
                    window.open('<?php echo site_url() ;?>' + 'email/export_translation_de/'+ campaign_id + "/" + edm_id  +"/" + country_code + "/" + language_code , '_blank'); 
                    break;
                  case "download_ampscript":
                    window.open('<?php echo site_url() ;?>' + 'email/get_ampscript2/'+ campaign_id + "/" + edm_id  +"/" + country_code + "/" + language_code , '_blank'); 
                    break;
                  case "download_html":
                    window.open('<?php echo site_url() ;?>' + 'email/preview_download/'+ campaign_id + "/" + edm_id  +"/" + country_code + "/" + language_code , '_blank'); 
                    break;
                }
                
            },
            items: {
                "edit": {name: "Edit", icon: "edit"},
                "copy": {name: "Copy", icon: "copy"},
                "delete": {name: "Delete", icon: "delete"},
                "input": {name: "Visual Input", icon: "delete"},
                "sep1": "---------",
                "download_input_csv": {name: "Download Input CSV", icon: "delete"},
                "upload_input_csv": {name: "Upload Input CSV", icon: "delete"},
                "sep2": "---------",
                "preview_desktop": {name: "Preview Desktop", icon: "edit"},
                "preview_mobile": {name: "Preview Mobile", icon: "copy"},
                "download_de": {name: "Download Translation DE", icon: "delete"},
                "download_ampscript": {name: "Download Ampscript", icon: "delete"},
                "download_html": {name: "Download HTML", icon: "delete"},
                
            }
        });

        
});
</script>

