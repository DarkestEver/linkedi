<script type="text/javascript">
$(document).ready(function() {

    $('#showNewEmail').click(function() {
        $('#newEmail').modal();
    })

    var groupColumn = 0;
    var table = $('#dataTable').DataTable({
    	"ordering": false,
        "columnDefs": [
            { "visible": false, "targets": groupColumn }
        ],
        "order": [[ groupColumn, 'asc' ]],
        "displayLength": 25,
        "drawCallback": function ( settings ) {
            var api = this.api();
            var rows = api.rows( {page:'current'} ).nodes();
            var last=null;

            api.column(groupColumn, {page:'current'} ).data().each( function ( group, i ) {
                if ( last !== group ) {
                    $(rows).eq( i ).before(
                        '<tr class="group"><td colspan="10">'+group+'</td></tr>'
                    );

                    last = group;
                }
            } );
        }
    } );

    // Order by the grouping
    $('#dataTable tbody').on( 'click', 'tr.group', function () {
        var currentOrder = table.order()[0];
        if ( currentOrder[0] === groupColumn && currentOrder[1] === 'asc' ) {
            table.order( [ groupColumn, 'desc' ] ).draw();
        }
        else {
            table.order( [ groupColumn, 'asc' ] ).draw();
        }
    } );


    $('#btn_save_new_email').click(function(e){
        if ($('#emailname').val()=="") {
            alert_message('Please enter email name.','warning');
            //e.preventDefault();
            return false;
        }
        else{
            var options = $('#marketName > option:selected');
             if(options.length == 0){
                 alert_message('Please select countries','warning');
                // e.preventDefault();
                 return false;
             }
        }
        return true;
    });
    
} );
</script>