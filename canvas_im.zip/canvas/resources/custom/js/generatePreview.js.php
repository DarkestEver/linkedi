<script type="text/javascript">
    $(document).ready(function () {

    	$('#mobile_view').on('click', function(event){
	        $("iframe").width(300);
	        $("iframe").height(500);
	     });

    	$('#desktop_view').on('click', function(event){
	        $("iframe").width(600);
	        $("iframe").height(600);
	     });
    });
</script>