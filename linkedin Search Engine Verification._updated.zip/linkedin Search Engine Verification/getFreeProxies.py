from urllib.request import Request, urlopen
from bs4 import BeautifulSoup
import chrome_user_agents as cua
import random

ua = cua.random_chrome_user_agent() # From here we generate a random user agent
proxies = [] # Will contain proxies [ip, port]

# Main function
def getFreeProxies():
  global proxies
  # Retrieve latest proxies
  proxies_req = Request('https://www.sslproxies.org/')
  proxies_req.add_header('User-Agent', ua)
  proxies_doc = urlopen(proxies_req).read().decode('utf8')
  soup = BeautifulSoup(proxies_doc, 'html.parser')
  proxies_table = soup.find(id='proxylisttable')
  # Save proxies in the array
  for row in proxies_table.tbody.find_all('tr'):
    if row.find_all('td')[6].string == 'yes':
        proxies.append({
           'ip':   row.find_all('td')[0].string,
              'port': row.find_all('td')[1].string,
              'country': row.find_all('td')[3].string,
              'anonymity': row.find_all('td')[4].string,
              'https': row.find_all('td')[6].string,
              'lascheck': row.find_all('td')[7].string
        })

def getRandomProxy():
    global proxies
    if countProxies()==0:
        proxies = getFreeProxies()
    proxy_index = random_proxy()
    proxy = proxies[proxy_index]
    return proxy_index, proxy

def checkIfProxyWorking():    
    index, proxy = getRandomProxy()
    req = Request('http://icanhazip.com')
    req.set_proxy(proxy['ip'] + ':' + proxy['port'], 'http')
    try:
      i = urlopen(req).read().decode('utf8')
      return proxy
    except: # If error, delete this proxy and find another one
      deleteProxyFromList(index)
      return False

def deleteProxyFromList(proxy_index):
    del proxies[proxy_index]


def random_proxy():
  return random.randint(0, len(proxies) - 1)

def countProxies():
    return len(proxies) 

