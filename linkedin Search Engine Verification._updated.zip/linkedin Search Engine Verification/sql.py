-- Table: public.linkedin_verify

-- DROP TABLE public.linkedin_verify;

CREATE TABLE public.linkedin_verify
(
    id integer NOT NULL DEFAULT nextval('linkedin_verify_id_seq'::regclass),
    first_name character varying(100) COLLATE pg_catalog."default",
    last_name character varying(100) COLLATE pg_catalog."default",
    company_name character varying(255) COLLATE pg_catalog."default",
    job_title character varying(255) COLLATE pg_catalog."default",
    searched_name character varying(100) COLLATE pg_catalog."default",
    searched_job_title character varying(255) COLLATE pg_catalog."default",
    searched_company character varying(255) COLLATE pg_catalog."default",
    is_verified integer DEFAULT 0,
    verification_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status integer DEFAULT 0,
    linkedin_url character varying(500) COLLATE pg_catalog."default",
    searched_linkedin_url character varying(500) COLLATE pg_catalog."default",
    CONSTRAINT linkedin_verify_pkey PRIMARY KEY (id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.linkedin_verify
    OWNER to postgres;
    
    
-- Table: public.prospect_search_engine

-- DROP TABLE public.prospect_search_engine;

CREATE TABLE public.prospect_search_engine
(
    id integer NOT NULL DEFAULT nextval('prospect_search_engine_id_seq'::regclass),
    user_name character varying(100) COLLATE pg_catalog."default",
    company_name character varying(255) COLLATE pg_catalog."default",
    job_title character varying(255) COLLATE pg_catalog."default",
    linkedin_url character varying(500) COLLATE pg_catalog."default",
    CONSTRAINT prospect_search_engine_pkey PRIMARY KEY (id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.prospect_search_engine
    OWNER to postgres;    