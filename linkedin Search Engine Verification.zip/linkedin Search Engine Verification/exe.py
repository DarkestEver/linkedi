# -*- coding: utf-8 -*-
"""
Created on Sun Jun 10 21:56:30 2018

@author: keshav
"""


import os
import mainlib as run
import getFreeProxies as frp

frp.getFreeProxies()

while True:   
    try:
        proxy = frp.checkIfProxyWorking()
        if proxy != False:
            instant_id = 0
            url_table = 'linkedin_verify'
            dir_path = os.path.dirname(os.path.realpath(__file__))
            try:
                driver = run.get_driver('D:\onedrive\Projects\linkedinextract.in\driver\chromedriver.exe',
                                        browser = 'chrome',
                                        _PROXY_HOST= proxy['ip'] ,
                                        _PROXY_PORT=int(proxy['port']),
                                        _USERNAME='',
                                        _PASSWORD='',
                                        _url_table = url_table,
                                        _instant_id = instant_id,
                                        _search_limit_url = 10000,
                                        _dir_path = dir_path,
                                        db=False)  
                run.linkedin_verification(driver,'bing')
                driver.quit()
                break
            except Exception as e:
                print("type error: " + str(e))
                if type(None) != type(driver):
                    driver.quit()
                    break
    except:
        pass