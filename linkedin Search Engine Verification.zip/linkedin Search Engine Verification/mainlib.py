# -*- coding: utf-8 -*-
"""
Created on Wed Mar 21 01:44:56 2018

@author: ksingh
"""


from time import sleep
import random as rn
import re
import json 
import math
import pandas as pd
from random import randint
from datetime import datetime
import time
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.firefox.firefox_profile import FirefoxProfile
from selenium import webdriver
from selenium.webdriver.common.proxy import Proxy
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import chromewithproxy
from PIL import Image
import re
import util
import os
import connection as connect
import urllib






def create_date_folder(path):
    datetoday =path  + datetime.now().strftime('%Y/%m/%d')
    if not os.path.exists(datetoday):
        os.makedirs(datetoday)
    return datetoday
        
def savehtml(filename, html):
    time = datetime.today().strftime('%Y\\%m\\%d')
    folder =dir_path + '\\html\\' + time 
    if not os.path.exists(folder):
        os.makedirs(folder)
    file = filename + '.html'
    f = open(folder + file, 'w')
    f.write(html.encode('utf-8'))
    f.close()

def check_more_pagination(driver):
    try:
        el3 = driver.find_element_by_xpath("//*[@class='next-pagination page-link disabled']") 
        return False
    except:
        return True

   
def usernames(name):
    zen_first_name = zen_last_name = zen_mid_name = ""
    user_name = name.split(' ')
    if len(user_name) == 1:
        zen_first_name = user_name[0]
        zen_last_name = ''
        zen_mid_name = ''
    elif len(user_name) == 2:
        zen_first_name = user_name[0]
        zen_mid_name = ''
        zen_last_name = user_name[1]
    elif len(user_name) > 2:
        zen_first_name = user_name[0]
        zen_last_name = user_name[-1]
        zen_mid_name = ' '.join(user_name[1:len(user_name)-1]).strip()
    return zen_first_name ,  zen_mid_name, zen_last_name

def jobinfo_split(jobinfo):
    jobtitle = rolein = address = ""
    job = jobinfo.split('\n')
    if len(job) == 1:
        jobtitle = ''
        rolein = ''
        address = ''
    elif len(job) == 2:
        if 'role' in job[1] :
            rolein = job[1]
            jobtitle = job[0]
        if 'role' in job[0] :
            rolein = job[0]
            address = job[1]
    elif len(job) == 3:
        jobtitle = job[0]
        rolein = job[1]
        address = job[2]
    return jobtitle , rolein , address


def getDataByClass(driver_object, classname, _type="text"):
    try:
        if _type == "text":
            return driver_object.find_element_by_class_name(classname).text.strip()
        if _type == "click":
            return driver_object.find_element_by_class_name(classname).click()
        if _type == "href":
            return driver_object.find_element_by_css_selector(classname).get_attribute('href').strip()
        if _type == "sel_text":
            return driver_object.find_element_by_css_selector(classname).text.strip()
    except:
        return ''

def profile_count(count):
    cal_count = 0
    if count == '':
        cal_count = 0
    elif 'K' in str(count):
       cal_count =  float(count.replace('K',''))*1000
    elif 'M' in str(count):
       cal_count = float(count.replace('M',''))*1000000
    else:
        cal_count =  int(count)
    return int(round(cal_count))

use_database = False
def get_driver(executable_path,_PROXY_HOST='',_PROXY_PORT='',_USERNAME='',_PASSWORD='',  browser = 'firefox' ,
               db = False , _url_table ="", _instant_id=0,_search_limit_url=100,_dir_path=''):
    global use_database,url_table,instant_id,search_limit_url, dir_path
    use_database  = db
    PROXY_HOST  = _PROXY_HOST
    PROXY_PORT = _PROXY_PORT
    USERNAME = _USERNAME
    PASSWORD = _PASSWORD
    search_limit_url = _search_limit_url
    connect.set_url_table(_url_table)
    connect.set_instant_id(_instant_id)
    if _dir_path != '':
        dir_path = _dir_path
    if use_database == True:
        print('use data base')
        row = connect.get_account_details()
        if type(None) != type(row):
            PROXY_HOST=row[6]
            PROXY_PORT=int(row[7])
            USERNAME=row[8]
            PASSWORD=row[9]
            print(PROXY_HOST)
            #connect.set_db_account_const(row)
        else:
            log_mesage('no available account')
            return False
    else:
        connect.set_db_account_const([])
        
    if browser == 'chrome':
        if PROXY_HOST != "":
            chrome = chromewithproxy.main_chrome(PROXY_HOST,PROXY_PORT,USERNAME,PASSWORD)
            return chrome
        else:
            chrome_options = webdriver.ChromeOptions()
            chrome_options.add_argument('start-maximized')
            chrome_options.add_argument('allow-running-insecure-content')
            chrome_options.add_argument("test-type")
            chrome = webdriver.Chrome(executable_path=executable_path,chrome_options=chrome_options)
            return chrome
    if browser == 'firefox':
        if PROXY_HOST != "":
            print('pp')
            profile = webdriver.FirefoxProfile()
            profile.set_preference("network.proxy.type", 1)
            profile.set_preference("network.proxy.http", PROXY_HOST)
            profile.set_preference("network.proxy.http_port", PROXY_PORT)
            profile.set_preference("network.proxy.socks_username", USERNAME)
            profile.set_preference("network.proxy.socks_password", PASSWORD)
            profile.set_preference("network.proxy.ssl", PROXY_HOST)
            profile.set_preference("network.proxy.ssl_port", PROXY_PORT)
            chrome = webdriver.Firefox(executable_path=executable_path, firefox_profile=profile)
            return chrome
        else:
            chrome = webdriver.Firefox(executable_path=executable_path)
            return chrome

def is_logged_in(driver):
    try:
        driver.find_element_by_id("nav-settings__dropdown-options").text
        return True
    except:
        return False
    
        
def action_linkedin_login(driver, _username, _password):
    global use_database
    username= _username
    password = _password 
    log_mesage('credentials set')
    try:
        if use_database == True:
            db_account = connect.get_db_account_const()
            print(db_account)
            username = db_account[1]
            password = db_account[2]
            print(username )
        log_mesage('loggin')
        time.sleep(2)
        driver.get('https://www.linkedin.com/uas/login?fromSignIn=true&trk=uno-reg-join-sign-in')
        sleep(5)
        driver.find_element_by_name("session_key").send_keys(username)
        sleep(1)
        password = driver.find_element_by_id("session_password-login").send_keys(password)
        sleep(1)
        sndbutton = driver.find_element_by_id("btn-primary")
        sndbutton.submit()
        time.sleep(60)
        if is_logged_in(driver):
            log_mesage('logged in')
        else:
            log_mesage('unable to login- username password missmatch')
            connect.set_account_notrunning()
            driver.quit()
    except Exception as e:
        log_mesage('unable to login' + str(e))
        connect.set_account_notrunning()
        driver.quit()

def imageCrop(full_image_path, ele, profile_file_name):
    try:
        image2 = Image.open(full_image_path)
        loc1= ele.location
        size1= ele.size
        left = loc1['x']
        top = loc1['y']
        right = loc1['x'] + size1['width']
        bottom1 = loc1['y'] + size1['height']  
        image2 = image2.crop((left,top,right,bottom1))
        image2.save(profile_file_name)
    except:
        print('image error profile')
        
def if_empty_search(driver):
    try:
        txt = driver.find_element_by_id('results-list').text
        if 'no results containing' in txt:
            return False
        else:
            return True
    except:
        return False
    
def if_account_blocked(driver):
    try:
        txt = driver.find_element_by_id('stream-container').text
        if 'limit exceed' in txt:
            return False
        else:
            return True
    except:
        return False    
    
def scarp(driver):
    try:
      
        log_mesage('navigating sales ')
        driver.get("https://www.linkedin.com/sales/search")
        
        sleep(10)
        #get_search_id
        log_mesage('excludes-suggestion 1')
        driver.find_element_by_class_name('excludes-suggestion-link').click()
        sleep(2)
        log_mesage('excludes-suggestion 2')
        driver.find_element_by_class_name('excludes-suggestion-link').click()
        sleep(2)
        log_mesage('current url - set up')
        url = driver.current_url
        query_param = url.split('?')[-1]
        params = dict(x.split('=') for x in query_param.split('&'))
        trackingInfoJson = params['trackingInfoJson.contextId']
        searchHistoryId = params['searchHistoryId']
        updateHistory = params['updateHistory']
        log_mesage('current url - set up done')
        search_count = 0        
        while connect.num_of_url() != 0 and search_limit_url > search_count:
            log_mesage('search count ' + str(search_count))
            search_count = search_count + 1
            row = connect.read_url()
            url = row[16]
            url = url + '&updateHistory=' + updateHistory + '&=searchHistoryId=' + searchHistoryId + '&trackingInfoJson.contextId=' + trackingInfoJson
            rowid = row[0]
            profile_country = row[2]
            employee_size = row[4]
            industry_type = row[7]
            job_function = row[10]
            seniority = row[13]
            companytype = row[15]
            driver.get(url)
            log_mesage('new url ')
            connect.set_account_urlcount()
            time.sleep(1)
            if if_empty_search(driver):
                count_profile = getDataByClass(driver,'spotlight-result-count')
                count_profile = profile_count(count_profile)
                count_next_click = 0
                scrap = True
                pagination = 0 
                while scrap:
                    if if_account_blocked(driver):
                        pagination = pagination + 1
                        full_img = create_date_folder(dir_path + '\\img\\fullpage\\') + '\\' + str(rowid)+ '_' + str(pagination) + '.png'
                        try:
                            util.fullpage_screenshot(driver,full_img)
                        except:
                            log_mesage('full page image error')
                        count_p = 0
                        result_container = driver.find_elements_by_css_selector('#results-list > li')
                        for profile in result_container:
                            count_p = count_p + 1
                            profile_name = getDataByClass( profile,'name')
                            profile_link = getDataByClass( profile,'.name > a','href')
                            company_link = getDataByClass( profile,'.company-name','href')
                            company_name = getDataByClass( profile,'company-name')
                            job_info = ""
                            try:
                                job_info =  profile.find_element_by_css_selector('.info').text.strip()
                            except:
                                job_info = ""
                            address = job_title = rolein = ''
                            l_first_name = l_last_name = l_mid_name = "" 
                            
                            job_title , rolein , address =jobinfo_split(job_info)
                            
                            if profile_name != '' and  (re.match('^[\s\w-]+$', profile_name) is not None):
                                l_first_name , l_mid_name ,l_last_name  = usernames(profile_name)
                            
                            profile_pic_proof = re.sub("[^a-zA-Z0-9]+", "", profile_link[:52]) + '.png'
                            profile_img_path =  create_date_folder(dir_path + '\\img\\profile\\') + '\\' + profile_pic_proof
                            imageCrop(full_img, profile, profile_img_path)
                            log_mesage('image create')
                            profile_info = {
                            'search_url':url,
                            'url':profile_link,
                            'first_name':l_first_name,
                            'last_name':l_last_name,
                            'mid_name':l_mid_name,
                            'user_name':profile_name,
                            'company_name':company_name,
                            'company_link':company_link,
                            'job_title':job_title,
                            'address':address,
                            'country':profile_country,
                            'employee_size':employee_size,
                            'industry':industry_type,
                            'job_function':job_function,
                            'seniority':seniority,
                            'job_info':job_info,
                            'url_pro_count':count_profile,
                            'company_type': companytype,
                            'rolein' :rolein,
                            'profile_proof' :profile_pic_proof
                            } 
                            connect.insert_prospect(profile_info)
                            log_mesage('insert into ')
                            #print(profile_info)
                    else:
                        log_mesage('account blocked')
                        connect.set_account_block()
                        return 
        
                    if count_p == 0:
                        scrap = False
                        driver.quit()
                        log_mesage('crossed limit URL')
                        connect.set_account_overlimit()
                        return 'over limit'
                    
                    if check_more_pagination(driver):
                        try:
                            driver.find_element_by_css_selector('//*[@id="pagination"]/a[2]').click()
                        except:
                            sleep(2)
                            driver.find_element_by_xpath("//*[@class='next-pagination page-link']").click()
                        scrap = True
                        count_next_click = count_next_click + 1
                        sleep(randint(4, 6))
                        log_mesage('clicking next pagination - wait 4-6')
                    else:
                        scrap = False     
                connect.update_url(rowid)
                log_mesage('url done')
            else:
                log_mesage('empty page')
                connect.update_url(rowid)
        connect.set_account_notrunning()
    except Exception as e:
        connect.set_account_notrunning()
        driver.quit()
        log_mesage(str(e))
        
        
search_limit_url = 100
dir_path = os.path.dirname(os.path.realpath(__file__))

def log_mesage(message):
    print(message)

def linkedin_verification(driver, search_engine = 'bing'):
    driver.get('https://www.'+search_engine+'.com/')
    time.sleep(5)
    while connect.num_of_url() != 0:
        valid = 0
        row = connect.read_url()
        first_name = row[1].lower()
        last_name =row[2].lower()
        company_name = row[3].lower()
        job_title = row[4].lower()
        id = row[0]
        linkedin_url = row[11]
        search_text =''
        linkedin_url_p = re.compile('com/in/(.*)/')
        if first_name != '' and last_name != '' and company_name != '' and job_title != '':
            try:
                linkedin_url = linkedin_url_p.search(linkedin_url).group()
                search_text = 'site:linkedin.com ' +  linkedin_url[3:]
            except:
                search_text = 'site:linkedin.com ' + '"'+first_name+'" + ' + '"'+last_name+'" + ' + '"'+company_name+'"' 
    
            if search_engine == 'bing':
                bing_search(driver,search_text)
            elif search_engine == 'google':
                google_search(driver,search_text)
                
            time.sleep(2)
            all_anchor_tags = driver.find_elements_by_xpath("//a")
            for a in all_anchor_tags:
                ori_title = a.get_attribute('text').lower()
                new_linkedin_url = a.get_attribute('href')
                if type(None) != type(new_linkedin_url) and 'linkedin.com/in/' in new_linkedin_url:
                    title = ori_title.replace('| linkedin', '').replace('…','').replace(' ...','').replace('- linkedin','').replace('| ...','').strip().split('|')[0].strip()
                    split_title = title.split(' - ')
                    title = alphanumeric(title)
                    if len(split_title) >= 3:
                        searched_company_name = split_title[-1]
                        len_searched_company_name = len(searched_company_name) - 1
                        searching_company_name = company_name[:len_searched_company_name].strip()
                        new_user_name = split_title[0]
                        new_job_title = '-'.join( split_title[1:-1])
                        new_company_name = split_title[-1] 
                        if alphanumeric(first_name) in alphanumeric(new_user_name) and alphanumeric(last_name) in alphanumeric(new_user_name) and alphanumeric(job_title) in alphanumeric(new_job_title) and alphanumeric(searching_company_name) in alphanumeric(new_company_name):
                            valid = 1
                            connect.linkedin_verified(id,new_user_name,new_job_title,new_company_name,new_linkedin_url )
                            print('valid')    
                        elif ' |' in ori_title:
                            profile_info = {
                                    'user_name':new_user_name,
                                    'company_name':new_company_name,
                                    'job_title':new_job_title,
                                    'linkedin_url':new_linkedin_url
                                    }
                            connect.insert_prospect_searched(profile_info)
                            print('inserted new')
        if  valid == 0:
            connect.linkedin_not_verified(id)
            print('invalid')
                
def alphanumeric(string):
    return re.sub(r'([^\s\w]|_)+', '', string)

def bing_search(driver,search_text):
    driver.find_element_by_id('sb_form_q').clear()
    for alphabets in search_text:
        driver.find_element_by_id('sb_form_q').send_keys(alphabets)
    time.sleep(rn.randint(2,20)*0.100)
    sndbutton = driver.find_element_by_id("sb_form_go")
    sndbutton.submit()

def google_search(driver,search_text):
    inputElement = driver.find_element_by_name("q")
    inputElement.clear()
    for alphabets in search_text:
        inputElement.send_keys(alphabets)
    time.sleep(rn.randint(2,20)*0.100)
    inputElement.submit()   


            