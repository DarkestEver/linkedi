create table linkedin_verify
(
id serial not null primary key,
first_name varchar(100),
last_name varchar(100),
company_name varchar(255),	
job_title varchar(255),	
searched_name  varchar(100),	
searched_job_title  varchar(255),	
searched_company  varchar(255),		
is_verified int,
verification_time timestamp default current_timestamp,
is_processed int
)